# Load necessary libraries
library(dplyr)
library(ggplot2)
library(haven)
library(tidyr)
library(lme4)
library(lmerTest)
library(forcats)
library(glmnet)
library(tidyverse)
library(caret)
library(randomForest)
library(gbm)
library(mgcv)
library(labelled)
library(purrr)
library(broom)
library(corrplot)
library(coin)
library(pheatmap)
library(GGally)
library(cluster)
library(factoextra)
library(gridExtra)
library(nlme)
library(broom.mixed)
library(tidyverse)
library(lme4)
library(ggplot2)
library(patchwork)
library(scales)
library(tidyverse)
library(caret)
library(randomForest)
library(xgboost)
library(pROC)
library(e1071)
library(nnet)
library(ggplot2)
library(reshape2)
library(ranger)
library(car)
library(dplyr)
library(ggplot2)
library(tidyr)
library(forcats)
library(purrr)
library(broom)
library(corrplot)
library(cluster)
library(coin)
library(pheatmap)
library(GGally)
library(cluster)
library(factoextra)
library(gridExtra)

# Create a directory for thesis plots if it doesn't exist
dir.create("thesis_plots", showWarnings = FALSE)

# Function to analyze differences between quartiles
analyze_quartile_differences <- function(variable, quartile_variable) {
  q1_mean <- mean(w2_sub[[variable]][w2_sub[[quartile_variable]] == "Q1"], na.rm = TRUE)
  q4_mean <- mean(w2_sub[[variable]][w2_sub[[quartile_variable]] == "Q4"], na.rm = TRUE)
  difference <- q4_mean - q1_mean
  
  print(paste("Analysis for", variable))
  print(paste("Mean for Q1:", round(q1_mean, 2)))
  print(paste("Mean for Q4:", round(q4_mean, 2)))
  print(paste("Difference between Q4 and Q1 means:", round(difference, 2)))
}

# Analyze differences for cognitive and language outcomes
#analyze_quartile_differences("b2_psabscore", "picture_similarities_quartiles")
#analyze_quartile_differences("b2_nvabscore", "naming_vocabulary_quartiles")

# Function to calculate quartiles
calculate_quartiles <- function(x) {
  cut(x, breaks = quantile(x, probs = 0:4/4, na.rm = TRUE), 
      labels = c("Q1", "Q2", "Q3", "Q4"), include.lowest = TRUE)}

# Set the working directory to the Downloads folder
setwd(file.path(Sys.getenv("USERPROFILE"), "Downloads"))



########################====  WAVE 1 =======#########################################
df <- read.csv("GUI Data_9MonthCohort(2).csv")

# Select the specified columns
selected_columns_w1 <- c(
  "ID", "Partner", "MMA4", "MMG2", "MMG11a", "MMH13", "MMH15b", "MMH20a", "MMH20b", 
  "MMCX2a", "MMCX2bcode", "MMH5b", "MMD1", "MMJ1", "MMJ2", "MMJ6", "MMJ9", "MMJ10", 
  "MMJ11", "MMJ12", "MMJ13", "MMJ14a", "MMJ14b", "MMJ14c", "MMK2", "MMK3", "MMK4a", 
  "MMK4b", "MMK4c", "MMM5", "MME1", "MML34", "MML41", "srPCGBMI_rec", "srSCGBMI_rec", 
  "Babymeascms", "Babymeaskgs", "fussy", "unadapt", "dull", "unpredict", "totstress", 
  "rewards", "stressors", "lackcontr", "parsatis", "CES_TOT_PCG", "hhtype4", 
  "hsdclass", "Equivinc", "EIncQuin", "MMH6gms", "QoAscore")
w1_sub <- df[, selected_columns_w1]

####### General
w1_sub$household_id <- w1_sub$ID
w1_sub$has_partner <- as.factor(w1_sub$Partner) #1 = yes, 0 = no
w1_sub$household_size <- w1_sub$MMA4 #numeric

########### Intention to get pregnant , <=6 wks is intention
w1_sub$pregnancy_awareness <- ifelse(w1_sub$MMG2 <= 6, 1, 0)
w1_sub$pregnancy_awareness <- factor(w1_sub$pregnancy_awareness) #as.factor

############## birthweight (quartiles)
w1_sub$birth_weight_quartile <- cut(w1_sub$MMH6gms, breaks = c(-Inf, 1499, 2499, 4599, Inf),
                                    labels = c("Q1: 1499 or less", "Q2: 1500-2499", "Q3: 2500-4599", "Q4: 4600 or more"),right = TRUE)

############# BREASTFEEDING
# Breastfeeding Ever BreastFed
w1_sub$breastfeeding_status <- case_when(
  w1_sub$MMH13 == 1 ~ "Ever breastfed",
  w1_sub$MMH13 == 2 ~ "Never breastfed",
  w1_sub$MMH13 %in% c(8, 9) ~ NA_character_)
w1_sub$breastfeeding_status <- factor(w1_sub$breastfeeding_status)

# Breastfeeding Duration
w1_sub$breastfeeding_duration <- case_when(w1_sub$MMH13 == 2 ~ "Never breastfed", w1_sub$MMH13 == 1 & w1_sub$MMH15b <= 90 ~ "Short duration (≤3 months)"
                                           , w1_sub$MMH13 == 1 & w1_sub$MMH15b <= 180 ~ "Medium duration (3-6 months)"
                                           , w1_sub$MMH13 == 1 & w1_sub$MMH15b > 180 ~ "Long duration (>6 months)"
                                           , is.na(w1_sub$MMH13) | is.na(w1_sub$MMH15b) ~ "Never breastfed", TRUE ~ NA_character_)
# Convert to factor
w1_sub$breastfeeding_duration <- factor(w1_sub$breastfeeding_duration, levels = c("Never breastfed", "Short duration (≤3 months)", 
                                                                                  "Medium duration (3-6 months)","Long duration (>6 months)"))

############ SMOKING
# Current smoking status
w1_sub$current_smoking <- case_when(w1_sub$MMJ9 == 1 ~ "Daily",w1_sub$MMJ9 == 2 ~ "Occasional",w1_sub$MMJ9 == 3 ~ "Never",TRUE ~ NA_character_)
w1_sub$current_smoking <- factor(w1_sub$current_smoking, levels = c("Daily", "Occasional", "Never"))
# Historical smoking
w1_sub$ever_smoked <- case_when(w1_sub$MMJ10 == 1 ~ "Yes",w1_sub$MMJ10 == 2 ~ "No",w1_sub$MMJ10 == 3 ~ "No",is.na(w1_sub$MMJ10) ~ "No",TRUE ~ NA_character_)
w1_sub$ever_smoked <- factor(w1_sub$ever_smoked) #No is the baseline
# Binary indicator for presence of smoking in household
w1_sub$smoking_in_household <- ifelse(w1_sub$MMJ12 > 0, 1, 0)

############## Alcohol consumption frequency
w1_sub$alcohol_frequency <- case_when(w1_sub$MMJ13 == 1 ~ "Never", w1_sub$MMJ13 == 2 ~ "Less than once a month",w1_sub$MMJ13 == 3 ~ "1-2 times a month",
                                      w1_sub$MMJ13 == 4 ~ "1-2 times a week",w1_sub$MMJ13 == 5 ~ "3-4 times a week",w1_sub$MMJ13 == 6 ~ "5-6 times a week",
                                      w1_sub$MMJ13 == 7 ~ "Every day",TRUE ~ NA_character_)
w1_sub$alcohol_frequency <- factor(w1_sub$alcohol_frequency, 
                                   levels = c("Never", "Less than once a month", "1-2 times a month", 
                                              "1-2 times a week", "3-4 times a week", "5-6 times a week", "Every day"))
# Heavy drinking binary variable
w1_sub$heavy_drinking <- ifelse(w1_sub$MMJ13 %in% c(5, 6, 7), 1, 0)

########### SUPPORT
# Support received
w1_sub$support_level <- factor(w1_sub$MMK2, levels = 1:4, labels = c("Enough help", "Not enough help", "No help at all", "Don't need help"))



# Regular contact with grandparents
w1_sub$grandparent_contact <- factor(w1_sub$MMK3, levels = 1:2, labels = c("Yes", "No"))
w1_sub$grandparent_contact[is.na(w1_sub$grandparent_contact)] <- "Yes"

############## Infant Temperament (Higher scores = more difficult temperament)
# List of temperament measures
temperament_measures <- c("fussy", "unadapt", "dull", "unpredict")
# Calculate quartiles for individual measures
for (measure in temperament_measures) {
  w1_sub[[paste0(measure, "_quartiles")]] <- calculate_quartiles(w1_sub[[measure]])}
# Calculate composite temperament score
w1_sub$composite_temperament <- rowMeans(w1_sub[, temperament_measures], na.rm = TRUE)

# Calculate quartiles for composite score (lower quartile = easier temperament)
w1_sub$composite_temperament_quartiles <- calculate_quartiles(w1_sub$composite_temperament)

########## Parental Stress Quartiles (lower totstress = lower stress)
w1_sub$totstress_quartiles <- calculate_quartiles(w1_sub$totstress)

########## Family charateristics
# mother's education
w1_sub$mother_education <- case_when(w1_sub$MML34 %in% 1:4 ~ "Secondary or below",w1_sub$MML34 %in% 5:7 ~ "Vocational/Non-degree",w1_sub$MML34 %in% 8:10 ~ "Degree level",
                                     w1_sub$MML34 %in% 11:13 ~ "Postgraduate",w1_sub$MML34 %in% c(98, 99) ~ NA_character_,TRUE ~ NA_character_)
w1_sub$mother_education <- factor(w1_sub$mother_education, levels = c("Secondary or below", "Vocational/Non-degree","Degree level", "Postgraduate"))

# Family structure 
w1_sub$family_structure <- factor(w1_sub$hhtype4, levels = 1:4, labels = c("One parent, 1 child",  "One parent, 2+ children","Two parents, 1 child","Two parents, 2+ children"))

# Family social class (already categorized, just convert to factor)
w1_sub <- w1_sub %>% mutate(family_social_class = case_when(hsdclass %in% c(1, 2) ~ "Professional/Managerial",hsdclass %in% c(3, 4) ~ "Non-Manual/Skilled",hsdclass %in% c(5, 6, 7) ~ "Semi-Skilled/Unskilled",
                                                            hsdclass == 8 ~ "Never Worked", TRUE ~ NA_character_))  # To handle any unexpected values))
w1_sub$family_social_class <- factor(w1_sub$family_social_class, levels = c("Professional/Managerial", "Non-Manual/Skilled",  "Semi-Skilled/Unskilled","Never Worked"))

# family income quintile (1 = lowest, 5 = highest)
w1_sub$income_quintile <- factor(w1_sub$EIncQuin, levels = 1:5, ordered = TRUE)

########################====  WAVE 2 =======#########################################
wave2 = read.csv("wave2.csv")
# Select the specified columns
selected_columns_w2 <- c(
  "id", "b2_partner", "bpc2A4", "bpc2C1", "bpc2C2", "bpc2E3a", "bpc2E3b", "bpc2E3c", 
  "bpc2E3e", "bpc2E3f", "bpc2E3g", "bpc2E5", "bpc2H5", "bpc2H6", "bpc2H7", "bpc2H8", 
  "bpc2H9a", "bpc2H9b", "bpc2H9c", "bpc2K1", "bpc2K2", "bpc2BMI_CAT", "bsc2BMI_CAT", 
  "b2kidcms", "b2kidkgs", "b2_SDQemotional", "b2_SDQconduct", "b2_SDQhyper", 
  "b2_SDQpeerprobs", "b2_SDQprosocial", "b2_SDQtotaldiffs", "bpc2_stress", 
  "bpc2_warmth", "bpc2_hostility", "bpc2_consistency", "bpc2_positive", "bpc2_conflict", 
  "b2_psraw", "b2_psabscore", "b2_pspercentile", "b2_nvrawscore", "b2_nvabscore", 
  "b2_nvpercentile", "b2_hhtype4", "b2_hsdclass", "b2_EIncQuin")
# Create a new dataframe with only the selected columns
w2_sub <- wave2[, selected_columns_w2]

############# General / Family Structure
w2_sub$household_id <- w2_sub$id
w2_sub$has_partner <- as.factor(w2_sub$b2_partner) #1 = yes, 0 = no
w2_sub$household_size <- w2_sub$bpc2A4

# Household type
w2_sub$family_structure <- factor(w2_sub$b2_hhtype4,  levels = 1:4, labels = c("One parent, 1 child",  "One parent, 2+ children", "Two parents, 1 child", "Two parents, 2+ children"))

# Social Class
w2_sub <- w2_sub %>% mutate(family_social_class = case_when( b2_hsdclass %in% c(1, 2) ~ "Professional/Managerial",b2_hsdclass %in% c(3, 4) ~ "Non-Manual/Skilled",
                                                             b2_hsdclass %in% c(5, 6, 7) ~ "Semi-Skilled/Unskilled",b2_hsdclass == 8 ~ "Never Worked",TRUE ~ NA_character_ ))
w2_sub$family_social_class <- factor(w2_sub$family_social_class, levels = c("Professional/Managerial", "Non-Manual/Skilled", "Semi-Skilled/Unskilled","Never Worked"))

# income quintiles
w2_sub$income_quintile <- factor(w2_sub$b2_EIncQuin, levels = 1:5, ordered = TRUE)

# educ
w2_sub$mother_education <- case_when(w2_sub$bpc2K1 %in% 2:4 ~ "Secondary or below",w2_sub$bpc2K1 %in% 5:7 ~ "Vocational/Non-degree",w2_sub$bpc2K1 %in% 8:10 ~ "Degree level",
                                     w2_sub$bpc2K1 %in% 11:13 ~ "Postgraduate",w2_sub$bpc2K1 %in% c(98, 99) ~ NA_character_,TRUE ~ NA_character_)
w2_sub$mother_education <- factor(w2_sub$mother_education, levels = c("Secondary or below", "Vocational/Non-degree", "Degree level", "Postgraduate"))

############# # Support
w2_sub$support_level <- factor(w2_sub$bpc2H5,levels = 1:4,labels = c("Enough help", "Not enough help", "No help at all", "Don't need help"))

############### Parent-Child Activities count (days of week)
columns_to_modify <- c("bpc2E3a", "bpc2E3b", "bpc2E3c", "bpc2E3e", "bpc2E3f", "bpc2E3g")
# Set 8 and 9 to NA for all relevant columns
for (col in columns_to_modify) {
  w2_sub[[col]][w2_sub[[col]] %in% c(8, 9)] <- NA}

# Calculate sum for educational activities
w2_sub$educational_sum <- rowSums(w2_sub[, c("bpc2E3a", "bpc2E3b", "bpc2E3c")], na.rm = TRUE)
# Calculate sum for creative activities
w2_sub$creative_sum <- rowSums(w2_sub[, c("bpc2E3e", "bpc2E3f", "bpc2E3g")], na.rm = TRUE)
# Calculate quartiles for educational activities sum
w2_sub$educational_quartiles <- calculate_quartiles(w2_sub$educational_sum)
# Calculate quartiles for creative activities sum
w2_sub$creative_quartiles <- calculate_quartiles(w2_sub$creative_sum)

############## Parental Stress Quartiles
w2_sub$parental_stress_quartiles <- calculate_quartiles(w2_sub$bpc2_stress)

############# SDQ (SOCIO-EMOTIONAL AND BEHAVIOURAL DEVELOPMENT)
w2_sub$SDQ_prosocial_quartiles <- calculate_quartiles(w2_sub$b2_SDQprosocial) #higher values = more social
w2_sub$SDQ_total_difficulties_quartiles <- calculate_quartiles(w2_sub$b2_SDQtotaldiffs) # HIGHER Values == more problems

############## Parenting style
w2_sub$parenting_hostility_quartiles <- calculate_quartiles(w2_sub$bpc2_hostility) #higher values = more hostile style
w2_sub$parenting_consistency_quartiles <-  calculate_quartiles(w2_sub$bpc2_consistency) #higher values = more consistnet style

############ Parent-child relationship
w2_sub$positive_conflict_diff <- w2_sub$bpc2_positive - w2_sub$bpc2_conflict # higher = more positive relationship
w2_sub$positive_conflict_quartiles <- calculate_quartiles(w2_sub$positive_conflict_diff)

############# Cognitive and language outcomes (higher = better performing)
w2_sub$picture_similarities_quartiles <- calculate_quartiles(w2_sub$b2_psabscore)
w2_sub$naming_vocabulary_quartiles <- calculate_quartiles(w2_sub$b2_nvabscore)


###########################========= WAVE 3 =========################
#read data
wave3 = read.csv("wave3.csv")
# Define the columns you want to select
selected_columns_w3 <- c(
  "id", "b3_partner", "bpc3A4", "bpc3E2", "bpc3E3aa", 
  "bpc3E3ab", "bpc3E3ac", "bpc3E3ad", "bpc3E3ae", "bpc3E3af", "bpc3E3ah", "bpc3E3ba", 
  "bpc3E3bb", "bpc3E3bc", "bpc3E3bd", "bpc3E4e", "bpc3E5", "bpc3E4c", "bpc3E8a", 
  "bpc3G1", "bpc3K1a_ed", "bpc3G46a", "bpc3G46b", "bpc3G46c", "bpc3G46d", "bpc3G46e", 
  "bpc3G46f", "bpc3G46g", "bpc3bmi_cat", "bsc3bmi_cat", "b3_kidbmi", "b3_kidbmi_cat", 
  "b3_psabscore", "b3_pspercentile", "b3_nvabscore", "b3_nvpercentile", "b3_sdqemotional", 
  "b3_sdqconduct", "b3_sdqhyper", "b3_sdqpeerprobs", "b3_sdqprosocial", "b3_sdqtotaldiffs", 
  "bpc3_positive", "bpc3_conflict", "bpc3_warmth", "bpc3_hostility", "bpc3_consistency", 
  "bpc3_stress", "b3_EIncQuin", "b3_hhtype4", "b3_hsdclass", "b3_assertion", "b3_responsibility", 
  "b3_empathy", "b3_selfcontrol", "b3_P4a", "b3_P35b", "b3_P5total")
# Create a new dataframe with only the selected columns
w3_sub <- wave3[, selected_columns_w3]

############ Family Structure/Charateristics
w3_sub$household_id <- w3_sub$id
w3_sub$has_partner <- as.factor(w3_sub$b3_partner) #1 = yes, 0 = no
w3_sub$household_size <- w3_sub$bpc3A4

##### mothers education
# Create the new factor variable with education categories
w3_sub <- w3_sub %>% mutate(mother_education = case_when(bpc3K1a_ed %in% 2:4 ~ "Secondary or below",bpc3K1a_ed %in% 5:7 ~ "Vocational/Non-degree",
                                                         bpc3K1a_ed %in% 8:10 ~ "Degree level", bpc3K1a_ed %in% 11 ~ "Postgraduate",TRUE ~ NA_character_ ))

# Convert the new variable to a factor with specified levels
w3_sub$mother_education <- factor(w3_sub$mother_education,levels = c("Secondary or below", "Vocational/Non-degree","Degree level","Postgraduate"))
# income quintile
w3_sub$income_quintile <- factor(w3_sub$b3_EIncQuin, levels = 1:5, ordered = TRUE)

### houshold type/ social class
w3_sub <- w3_sub %>%
  mutate( household_type = factor(b3_hhtype4, levels = 1:4, labels = c("One parent, 1 child",   "One parent, 2+ children", "Two parents, 1 child",
                                                                       "Two parents, 2+ children")),
          
          family_social_class = case_when(
            b3_hsdclass %in% c(1, 2) ~ "Professional/Managerial",
            b3_hsdclass %in% c(3, 4) ~ "Non-Manual/Skilled",
            b3_hsdclass %in% c(5, 6, 7) ~ "Semi-Skilled/Unskilled",
            b3_hsdclass == 666 ~ NA_character_,
            TRUE ~ NA_character_  # To handle any unexpected values
          )
  )

######## Activities
######## Educational activities
# List of educational activity columns
educational_cols <- c("bpc3E3ac", "bpc3E3ad", "bpc3E3ae", "bpc3E3af", "bpc3E3ah")

# Recode values for educational activities
w3_sub <- w3_sub %>%
  mutate(across(all_of(educational_cols), 
                ~case_when(
                  . == 1 ~ 1,  # Never
                  . == 2 ~ 2,  # Hardly ever
                  . == 3 ~ 3,  # Occasionally
                  . == 4 ~ 4,  # One or two times a week
                  . == 5 ~ 5,  # Every day
                  . %in% c(6, 8, 9) ~ NA_real_,  # Not applicable or Not answered
                  TRUE ~ NA_real_
                )))

# Create labels for the frequency values
frequency_labels <- c("Never", "Hardly ever", "Occasionally", "One or two times a week", "Every day")
# Apply labels to recoded columns
w3_sub <- w3_sub %>%  mutate(across(all_of(educational_cols), ~factor(., levels = 1:5, labels = frequency_labels)))
# Create composite score (higher score means more frequent activities)
w3_sub <- w3_sub %>% mutate(educational_composite = rowMeans(select(., all_of(educational_cols)) %>% 
                                                               mutate(across(everything(), as.numeric)),  na.rm = TRUE))
# Calculate quartiles for educational activities composite
w3_sub <- w3_sub %>% mutate(educational_quartiles = calculate_quartiles(educational_composite))

##### Creative activities
# List of creative activity columns
creative_cols <- c("bpc3E3aa", "bpc3E3ab", "bpc3E3ba", "bpc3E3bb", "bpc3E3bc", "bpc3E3bd", "bpc3E5")
# Recode values for creative activities
w3_sub <- w3_sub %>%
  mutate(across(all_of(creative_cols), 
                ~case_when(
                  . == 1 ~ 1,  # Never
                  . == 2 ~ 2,  # Hardly ever
                  . == 3 ~ 3,  # Occasionally
                  . == 4 ~ 4,  # One or two times a week
                  . == 5 ~ 5,  # Every day
                  . %in% c(6, 8, 9) ~ NA_real_,  # Not applicable or Not answered
                  TRUE ~ NA_real_
                )))
# Apply labels to recoded columns
w3_sub <- w3_sub %>% mutate(across(all_of(creative_cols), ~factor(., levels = 1:5, labels = frequency_labels)))
# Create composite score for creative activities
w3_sub <- w3_sub %>% mutate(creative_composite = rowMeans(select(., all_of(creative_cols)) %>% 
                                                            mutate(across(everything(), as.numeric)),na.rm = TRUE))
# Calculate quartiles for creative activities composite
w3_sub <- w3_sub %>%  mutate(creative_quartiles = calculate_quartiles(creative_composite))

######## Screen time (factor and numeric variable created)
w3_sub <- w3_sub %>%
  mutate(screen_time = case_when(
    bpc3E8a == 1 ~ "1 hour",
    bpc3E8a == 2 ~ "2 hours",
    bpc3E8a == 3 ~ "3 hours",
    bpc3E8a == 4 ~ "4 or more hours",
    bpc3E8a == 9 ~ NA_character_,
    TRUE ~ NA_character_
  )) %>%
  mutate(screen_time = factor(screen_time, levels = c("1 hour", "2 hours", "3 hours", "4 or more hours")))

# Create a numeric version of screen time for potential use in modeling
w3_sub <- w3_sub %>%
  mutate(screen_time_numeric = case_when(
    bpc3E8a == 1 ~ 1,
    bpc3E8a == 2 ~ 2,
    bpc3E8a == 3 ~ 3,
    bpc3E8a == 4 ~ 4,
    bpc3E8a == 9 ~ NA_real_,
    TRUE ~ NA_real_
  ))

########### Cognitive and language outcomes  (higher = better performing)
w3_sub$picture_similarities_quartiles <- calculate_quartiles(w3_sub$b3_psabscore)
w3_sub$naming_vocabulary_quartiles <- calculate_quartiles(w3_sub$b3_nvabscore)

######### SDQ (SOCIO-EMOTIONAL AND BEHAVIOURAL DEVELOPMENT)
w3_sub$SDQ_total_difficulties_quartiles <- calculate_quartiles(w3_sub$b3_sdqtotaldiffs) # HIGHER Values == more problems

############## Parenting style
w3_sub$parenting_hostility_quartiles <- calculate_quartiles(w3_sub$bpc3_hostility)
w3_sub$parenting_consistency_quartiles <- calculate_quartiles(w3_sub$bpc3_consistency)

######### Parent-child relationship
w3_sub$positive_conflict_diff <- w3_sub$bpc3_positive - w3_sub$bpc3_conflict
w3_sub$positive_conflict_quartiles <- calculate_quartiles(w3_sub$positive_conflict_diff)

########## Parental Stress
w3_sub$parental_stress_quartiles <- calculate_quartiles(w3_sub$bpc3_stress)

######### Social Skills Improvement System (SSIS) (higher score = higher social skills)
w3_sub$SSIS_composite <- rowMeans(w3_sub[, c("b3_assertion", "b3_responsibility", "b3_empathy", "b3_selfcontrol")], na.rm = TRUE)
w3_sub$SSIS_composite_quartiles <- calculate_quartiles(w3_sub$SSIS_composite)

############ Teacher reports/school type
# School DEIS status (DEIS = disadvantaged school)
w3_sub$school_DEIS_status <- factor(w3_sub$b3_P4a, levels = c(1, 4, 9), labels = c("Non-DEIS", "DEIS", "Unknown"))
# School size
w3_sub$school_size <- case_when( w3_sub$b3_P5total == 150 ~ "Small", w3_sub$b3_P5total == 300 ~ "Medium", w3_sub$b3_P5total == 500 ~ "Large", w3_sub$b3_P5total == 9999 ~ NA_character_,
                                 TRUE ~ NA_character_)
w3_sub$school_size <- factor(w3_sub$school_size, levels = c("Small", "Medium", "Large"))

# Parent-teacher meeting attendance
w3_sub$PT_meeting_attendance <- case_when( w3_sub$b3_P35b %in% c(70, 80) ~ "Low",  w3_sub$b3_P35b %in% c(90, 100) ~ "High", w3_sub$b3_P35b == 999 ~ NA_character_,
                                           TRUE ~ NA_character_ )
w3_sub$PT_meeting_attendance <- factor(w3_sub$PT_meeting_attendance, levels = c("Low", "High"))


##########################========== WAVE 4 ==========###############
# load
wave4 = read.csv("wave4.csv")
# Define the columns you want to select
selected_columns_w4 <- c(
  "id","xxwave1", "xxwave2", "xxwave3", "xxwave4", "b4_hhtype4","b4_partner",
  "b4_PEDSdevelopmental", "b4_PEDSmental",
  "bpc4q20", "bpc4q23a", "bpc4q23b", "bpc4q23c", "bpc4q23d", "bpc4q24",
  "bpc4q25", "bpc4q27a", "bpc4q27b", "bpc4q27c",
  "bpc4q33a", "bpc4q33c", "bpc4q33e", "bpc4q33f", "bpc4q33g", "bpc4q33h",
  "bpc4q34a", "bpc4q34b", "bpc4q36b", "bpc4q36c", "bpc4q36d", "bpc4q36e",
  "bpc4q36f", "bpc4q36g", "bpc4q36h",
  "b4_assertion", "b4_responsibility", "b4_empathy", "b4_selfcontrol",
  "b4_chdBMI_cat",
  "b4_SDQemotional", "b4_SDQconduct", "b4_SDQhyper", "b4_SDQpeerprobs",
  "b4_SDQprosocial", "b4_SDQtotaldiffs",
  "b4_PIANTApositive", "b4_PIANTAconflict")
# Create a new dataframe with only the selected columns
w4_sub <- wave4[, selected_columns_w4]


#######general charateristics
w4_sub$household_id <- w4_sub$id
w4_sub$has_partner <- as.factor(w4_sub$b4_partner)
w4_sub <- w4_sub %>%
  mutate(
    has_partner = factor(case_when(
      has_partner == 1 ~ 1,
      has_partner %in% c(2, 9) ~ 0
    ), levels = c(0, 1))
  )
# family type
w4_sub$family_structure <- factor(w4_sub$b4_hhtype4,levels = 1:4,labels = c("One parent, 1 child", "One parent, 2+ children", "Two parents, 1 child", "Two parents, 2+ children"))

########## Activities
# Educational activities columns
educational_cols <- c("bpc4q33h", "bpc4q36c", "bpc4q36d", "bpc4q36e", "bpc4q36f", "bpc4q36h")
# Creative activities columns
creative_cols <- c("bpc4q33a", "bpc4q33c", "bpc4q33e", "bpc4q33f", "bpc4q33g", "bpc4q36b", "bpc4q36g")

# Recode values for educational and creative activities
w4_sub <- w4_sub %>%
  mutate(across(c(all_of(educational_cols), all_of(creative_cols)), 
                ~case_when(
                  . == 1 ~ 1,  # Never
                  . == 2 ~ 2,  # Hardly ever
                  . == 3 ~ 3,  # Occasionally
                  . == 4 ~ 4,  # One or two times a week
                  . == 5 ~ 5,  # Every day
                  . == 6 ~ NA_real_,  # Not applicable
                  TRUE ~ NA_real_  # Any other value (like 8 or 9 for Not answered)
                )))
# Create labels for the frequency values
frequency_labels <- c("Never", "Hardly ever", "Occasionally", "One or two times a week", "Every day")
# Apply labels to recoded columns
w4_sub <- w4_sub %>%
  mutate(across(c(all_of(educational_cols), all_of(creative_cols)), 
                ~factor(., levels = 1:5, labels = frequency_labels)))
# Create composite scores (higher score means more frequent activities)
w4_sub <- w4_sub %>%
  mutate(
    educational_composite = rowMeans(select(., all_of(educational_cols)) %>% 
                                       mutate(across(everything(), as.numeric)), 
                                     na.rm = TRUE),
    creative_composite = rowMeans(select(., all_of(creative_cols)) %>% 
                                    mutate(across(everything(), as.numeric)), 
                                  na.rm = TRUE))
# Calculate quartiles
w4_sub <- w4_sub %>%mutate(educational_quartiles = calculate_quartiles(educational_composite),creative_quartiles = calculate_quartiles(creative_composite))

####### screen time (higher = more screen time)
w4_sub <- w4_sub %>%
  mutate(screen_time = case_when(
    bpc4q34a >= 0 & bpc4q34a <= 4 ~ bpc4q34a,
    bpc4q34a > 4 & bpc4q34a < 999 ~ 4,
    bpc4q34a == 999 ~ NA_real_,TRUE ~ NA_real_ ))

##### Parents perception of child's school willingness (higher score = more willing)
willingness_cols <- c("bpc4q23a", "bpc4q23b", "bpc4q23c", "bpc4q23d", "bpc4q24")

w4_sub <- w4_sub %>%
  mutate(across(all_of(willingness_cols), 
                ~if_else(. %in% 1:3, as.numeric(.), NA_real_))) %>%
  rowwise() %>%
  mutate(
    school_willingness_score = mean(
      c(bpc4q23a, 4 - bpc4q23b, 4 - bpc4q23c, bpc4q23d, bpc4q24),
      na.rm = TRUE
    )
  ) %>%
  ungroup()

##### parents perception of childs schoolwork performance
w4_sub$bpc4q27a[w4_sub$bpc4q27a == 9] <- NA
w4_sub$bpc4q27b[w4_sub$bpc4q27b == 9] <- NA
w4_sub$bpc4q27c[w4_sub$bpc4q27c == 9] <- NA
# Calculate the composite score
w4_sub$composite_schoolwork <- rowMeans(w4_sub[, c("bpc4q27a", "bpc4q27b", "bpc4q27c")], na.rm = TRUE)
# Apply the quartile function to the composite score #q1 = lowest perception of performance
w4_sub$schoolwork_quartile <- calculate_quartiles(w4_sub$composite_schoolwork)
table(w4_sub$schoolwork_quartile)

###### measurements
# Calculate composite and quartiles for Social Skills Improvement System (SSIS)
w4_sub$SSIS_composite <- rowMeans(w4_sub[, c("b4_assertion", "b4_responsibility", "b4_empathy", "b4_selfcontrol")], na.rm = TRUE)
w4_sub$SSIS_composite_quartiles <- calculate_quartiles(w4_sub$SSIS_composite)

# Calculate the difference and quartiles for parent-child relationship
w4_sub$positive_conflict_diff <- w4_sub$b4_PIANTApositive - w4_sub$b4_PIANTAconflict
w4_sub$positive_conflict_quartiles <- calculate_quartiles(w4_sub$positive_conflict_diff)

# Calculate quartiles for SDQ Total Difficulties score
w4_sub$SDQ_total_difficulties_quartiles <- calculate_quartiles(w4_sub$b4_SDQtotaldiffs)


##########################========== WAVE 5 ==========###############
# load
wave5 <- read_stata("0019-05_GUI_InfantCohort_Wave5_v1.2(2).dta")
# Subset the wave5 dataframe with the specified columns
w5_sub <- wave5 %>%
  select(
    id, xxwave1, xxwave2, xxwave3, xxwave4, xxwave5, b5pcm1_ed,
    b5_partner, b5pcA4,
    b5pcf1a, b5pcf1b, b5pcf1c, b5pcf1d, b5pcf1e, b5pcf1f, b5pcf1g,
    b5pcf2c, b5pcf2e, b5pcf2f, b5pcf2g, b5pcf3, b5pcf4,
    b5pci2a, b5pci2b, b5pci2c, b5pci3, b5pci4,
    b5pcj6a1, b5pcj6a2,
    b5pcj7, b5pcj11, b5pcj12, b5pcj13, b5pcj14, b5pcj15, b5pcj16, b5pcj18, b5pcj19,
    b5pck1, b5pck2, b5pck3, b5pck4b, b5pck4d, b5pck4e,
    bcq5q1, bcq5q2, bcq5q3a, bcq5q3b, bcq5q3c,
    bcq5q13, bcq5q14, bcs5q2, bcs5q15, bcs5q16a, bcs5q16b, bcs5q16c, bcs5q16d, bcs5q16e, bcs5q17,
    bpc5bmi_cat, b5kidbmi_cat,
    b5pc_positive, b5pc_conflict,
    b5_SDQemotional, b5_SDQconduct, b5_SDQhyper, b5_SDQpeerprobs, b5_SDQprosocial, b5_SDQtotaldiffs,
    b5pc_warmth, b5pc_hostility, b5pc_consistency,
    b5pc_stress,
    b5_hsdclass, b5_Eincquin, b5_hhtype4,
    b5_attentiontest, b5_attention,
    b5_drum, b5_readclass, b5_readatt, b5_readcorr, b5_readpct, b5_readingls, b5_readinglsse)



######## general/family charateristics
w5_sub$household_id <- w5_sub$id
w5_sub$has_partner <- as.factor(w5_sub$b5_partner)
w5_sub$household_size <- w5_sub$b5pcA4

# Mother's education
w5_sub <- w5_sub %>% mutate(mother_education = case_when( b5pcm1_ed %in% 2:4 ~ "Secondary or below", b5pcm1_ed %in% 5:7 ~ "Vocational/Non-degree",
                                                          b5pcm1_ed %in% 8:9 ~ "Degree level", b5pcm1_ed %in% 10:11 ~ "Postgraduate",b5pcm1_ed %in% c(98, 99) ~ NA_character_,TRUE ~ NA_character_))

w5_sub$mother_education <- factor(w5_sub$mother_education, levels = c("Secondary or below", "Vocational/Non-degree","Degree level", "Postgraduate"))

# Family social class
w5_sub <- w5_sub %>% mutate(family_social_class = case_when(b5_hsdclass %in% c(1, 2) ~ "Professional/Managerial", b5_hsdclass %in% c(3, 4) ~ "Non-Manual/Skilled",
                                                            b5_hsdclass %in% c(5, 6, 7) ~ "Semi-Skilled/Unskilled",b5_hsdclass == 666 ~ "Validly no social class",b5_hsdclass == 9 ~ "Employment status unknown",
                                                            TRUE ~ NA_character_))

w5_sub$family_social_class <- factor(w5_sub$family_social_class,levels = c("Professional/Managerial","Non-Manual/Skilled","Semi-Skilled/Unskilled", "Validly no social class",
                                                                           "Employment status unknown"))

# Family structure
w5_sub$family_structure <- factor(w5_sub$b5_hhtype4, levels = 1:4,labels = c("One parent, 1 child", "One parent, 2+ children","Two parents, 1 child","Two parents, 2+ children"))

# income quintile
w5_sub$income_quintile <- factor(w5_sub$b5_Eincquin, levels = 1:5, ordered = TRUE)


############ Activities
# Educational activities columns
edu_cols <- c("b5pcf1c", "b5pcf1d", "b5pcf1e", "b5pcf1g", "b5pcf2e")

# Recode values for educational activities
w5_sub <- w5_sub %>%
  mutate(across(all_of(edu_cols), 
                ~case_when(
                  . == 1 ~ 1,  # Never
                  . == 2 ~ 2,  # Hardly ever
                  . == 3 ~ 3,  # Occasionally
                  . == 4 ~ 4,  # One or two times a week
                  . == 5 ~ 5,  # Every day
                  . %in% c(6, 8, 9) ~ NA_real_,  # Not applicable or Not answered
                  TRUE ~ NA_real_
                )))

# Create labels for the frequency values
frequency_labels <- c("Never", "Hardly ever", "Occasionally", "One or two times a week", "Every day")

# Apply labels to recoded columns
w5_sub <- w5_sub %>% mutate(across(all_of(edu_cols), ~factor(., levels = 1:5, labels = frequency_labels)))
# Create composite score (higher score means more frequent activities)
w5_sub <- w5_sub %>% mutate(edu_composite = rowMeans(select(., all_of(edu_cols)) %>%  mutate(across(everything(), as.numeric)),na.rm = TRUE))
# Calculate quartiles for educational activities composite
w5_sub <- w5_sub %>% mutate(edu_quartiles = calculate_quartiles(edu_composite))


########### Reading for pleasure
reading_cols <- c("b5pcf3", "b5pcf4")

w5_sub <- w5_sub %>%
  mutate(across(all_of(reading_cols), 
                ~case_when(
                  . == 1 ~ 0,
                  . == 2 ~ 0.25,
                  . == 3 ~ 0.75,
                  . == 4 ~ 1.5,
                  . == 5 ~ 2.5,
                  . == 6 ~ 3.5,
                  . == 7 ~ 4,
                  . %in% c(8, 9) ~ NA_real_,
                  TRUE ~ NA_real_
                ))) 

w5_sub <- w5_sub %>% mutate(reading_composite = rowMeans(select(., all_of(reading_cols)), na.rm = TRUE), reading_quartiles = calculate_quartiles(reading_composite))
# Q1 = low reading, Q4 = high reading

######### Creative activities
creative_cols <- c("b5pcf1a", "b5pcf1b", "b5pcf1f")

w5_sub <- w5_sub %>% mutate(across(all_of(creative_cols), 
                                   ~case_when(
                                     . == 1 ~ 1,
                                     . == 2 ~ 2,
                                     . == 3 ~ 3,
                                     . == 4 ~ 4,
                                     . == 5 ~ 5,
                                     . %in% c(8, 9) ~ NA_real_,
                                     TRUE ~ NA_real_ )))

w5_sub <- w5_sub %>% mutate(creative_composite = rowMeans(select(., all_of(creative_cols)), na.rm = TRUE), creative_quartiles = calculate_quartiles(creative_composite))
# Q1 = low creative activity, Q4 = high creative activity

########## Team activities (binary)
w5_sub <- w5_sub %>% mutate(team_sports = factor(case_when(  b5pcj6a1 == 1 ~ "Yes", b5pcj6a1 == 2 ~ "No", TRUE ~ NA_character_ )))

####### Parents' upkeep with school-related activity/perception
w5_sub <- w5_sub %>%
  mutate(
    parent_teacher_meeting = factor(case_when(
      b5pcj7 == 1 ~ "Yes",
      b5pcj7 == 2 ~ "No",
      TRUE ~ NA_character_
    )),
    homework_time = case_when(
      b5pcj11 == 1 ~ 0.25,
      b5pcj11 == 2 ~ 0.5,
      b5pcj11 == 3 ~ 0.75,
      b5pcj11 == 4 ~ 1.25,
      b5pcj11 == 5 ~ 1.75,
      b5pcj11 == 6 ~ 2,
      b5pcj11 %in% c(98, 99) ~ NA_real_,
      TRUE ~ NA_real_
    ),
    homework_help = case_when(
      b5pcj12 %in% c(1, 2) ~ 2,  # Frequently
      b5pcj12 == 3 ~ 1,          # Sometimes
      b5pcj12 %in% c(4, 5) ~ 0,  # Rarely/Never
      TRUE ~ NA_real_
    )
  )
# Create a composite score using only the numeric variables
w5_sub <- w5_sub %>% mutate( school_engagement_composite = rowMeans(select(., homework_time, homework_help), na.rm = TRUE),
                             school_engagement_quartiles = calculate_quartiles(school_engagement_composite) )
# Q1 = low school engagement, Q4 = high school engagement

####### Edu perception
edu_perception_cols <- c("b5pcj13", "b5pcj14")

w5_sub <- w5_sub %>%
  mutate(across(all_of(edu_perception_cols), 
                ~case_when(
                  . %in% 1:5 ~ .,
                  . %in% c(8, 9) ~ NA_real_,
                  TRUE ~ NA_real_
                )))

w5_sub <- w5_sub %>%  mutate(edu_perception_composite = rowMeans(select(., all_of(edu_perception_cols)), na.rm = TRUE),edu_perception_quartiles = calculate_quartiles(edu_perception_composite))
# Q1 = low perceived performance, Q4 = high perceived performance


######## Edu Future Progression perception
w5_sub <- w5_sub %>%  mutate(expected_education = case_when( b5pcj18 %in% 1:3 ~ "Secondary/Vocational", b5pcj18 == 4 ~ "Diploma/Certificate",  b5pcj18 %in% 5:6 ~ "Degree or higher",
                                                             b5pcj18 == 7 ~ "Don't know", TRUE ~ NA_character_ ))

##### Child perception of school
school_perception_cols <- c("bcq5q3a", "bcq5q3b", "bcq5q3c")

w5_sub <- w5_sub %>%
  mutate(across(all_of(school_perception_cols), 
                ~case_when(
                  . == 1 ~ 3,  # Always like it
                  . == 2 ~ 2,  # Sometimes like it
                  . == 3 ~ 1,  # Never like it
                  . %in% c(8, 9) ~ NA_real_,
                  TRUE ~ NA_real_ )))

w5_sub <- w5_sub %>%  mutate(school_perception_composite = rowMeans(select(., all_of(school_perception_cols)), na.rm = TRUE), school_perception_quartiles = calculate_quartiles(school_perception_composite))
# Q1 = low school liking, Q4 = high school liking


####### Bullying
w5_sub <- w5_sub %>%
  mutate(
    bullying_experience = factor(case_when(
      bcs5q15 == 1 ~ "Yes",
      bcs5q15 == 2 ~ "No",
      TRUE ~ NA_character_
    )),
    bullying_frequency = case_when(
      bcs5q17 == 1 ~ "Infrequently",  # Once or twice
      bcs5q17 == 2 ~ "Infrequently",  # Now and again
      bcs5q17 == 3 ~ "Frequently",    # Almost every week
      bcs5q17 == 4 ~ "Frequently",    # Almost every day
      TRUE ~ NA_character_
    )
  )

# Create a combined bullying variable
w5_sub <- w5_sub %>%
  mutate(
    bullying_status = case_when(
      bullying_experience == "No" ~ "No bullying",
      bullying_experience == "Yes" & bullying_frequency == "Infrequently" ~ "Infrequent bullying",
      bullying_experience == "Yes" & bullying_frequency == "Frequently" ~ "Frequent bullying",
      is.na(bullying_experience) | is.na(bullying_frequency) ~ "No bullying",
      TRUE ~ NA_character_
    ),
    bullying_status = factor(bullying_status)
  )
########## measurements
# SDQ (SOCIO-EMOTIONAL AND BEHAVIOURAL DEVELOPMENT)
w5_sub$SDQ_total_difficulties_quartiles <- calculate_quartiles(w5_sub$b5_SDQtotaldiffs)
############ Parenting style
w5_sub$parenting_hostility_quartiles <- calculate_quartiles(w5_sub$b5pc_hostility)
w5_sub$parenting_consistency_quartiles <- calculate_quartiles(w5_sub$b5pc_consistency)
########## # Parent-child relationship
w5_sub$positive_conflict_diff <- w5_sub$b5pc_positive - w5_sub$b5pc_conflict
w5_sub$positive_conflict_quartiles <- calculate_quartiles(w5_sub$positive_conflict_diff)
############# Parental Stress
w5_sub$parental_stress_quartiles <- calculate_quartiles(w5_sub$b5pc_stress)

##########################################################
###############      Regression Variable     ##############
##########################################################

w5_sub$drum_score = w5_sub$b5_readingls #### Drumcondra Reading test - Logit score
sum(is.na(w5_sub$drum_score)) #281 of a possible 4792








##########################################################
###############      DATA MANIPULATION + CHECK  ##############
##########################################################

# Step 1: Identify households present in all waves
consistent_households <- w1_sub %>%
  semi_join(w2_sub, by = "household_id") %>%
  semi_join(w3_sub, by = "household_id") %>%
  semi_join(w4_sub, by = "household_id") %>%
  semi_join(w5_sub, by = "household_id") %>%
  pull(household_id)

# Step 2: Prepare each wave's data by applying prefix
prepare_wave <- function(data, wave_num) {
  data %>%
    filter(household_id %in% consistent_households) %>%
    rename_with(~paste0("w", wave_num, "_", .), -household_id)
}

w1_prepared <- prepare_wave(w1_sub, 1)
w2_prepared <- prepare_wave(w2_sub, 2)
w3_prepared <- prepare_wave(w3_sub, 3)
w4_prepared <- prepare_wave(w4_sub, 4)
w5_prepared <- prepare_wave(w5_sub, 5)

# Step 3: Combine all waves
long_data <- w1_prepared %>%
  full_join(w2_prepared, by = "household_id") %>%
  full_join(w3_prepared, by = "household_id") %>%
  full_join(w4_prepared, by = "household_id") %>%
  full_join(w5_prepared, by = "household_id")

long_data

#long_data_selected <- long_data %>% select(all_of(columns_to_keep))


columns_to_keep <- c(
  "household_id",
  "w1_has_partner", "w1_household_size","w1_mother_education", "w1_family_structure",
  "w1_family_social_class", "w1_income_quintile", "w1_pregnancy_awareness", "w1_birth_weight_quartile", "w1_breastfeeding_status",
  "w1_breastfeeding_duration", "w1_current_smoking", "w1_ever_smoked", "w1_smoking_in_household",
  "w1_alcohol_frequency", "w1_heavy_drinking", "w1_support_level", "w1_grandparent_contact",
  "w1_fussy_quartiles", "w1_unadapt_quartiles", "w1_dull_quartiles", "w1_unpredict_quartiles",
  "w1_composite_temperament_quartiles", "w1_totstress_quartiles",
  
  "w2_has_partner", "w2_household_size", "w2_family_structure",
  "w2_family_social_class", "w2_income_quintile", "w2_mother_education", "w2_support_level",
  "w2_educational_quartiles", "w2_creative_quartiles",
  "w2_parental_stress_quartiles", "w2_SDQ_prosocial_quartiles", "w2_SDQ_total_difficulties_quartiles",
  "w2_parenting_hostility_quartiles", "w2_parenting_consistency_quartiles", "w2_positive_conflict_diff",
  "w2_positive_conflict_quartiles", "w2_picture_similarities_quartiles", "w2_naming_vocabulary_quartiles",
  
  "w3_has_partner", "w3_household_size", "w3_mother_education", "w3_income_quintile",
  "w3_household_type", "w3_family_social_class", "w3_educational_composite",
  "w3_educational_quartiles", "w3_creative_composite", "w3_creative_quartiles", "w3_screen_time",
  "w3_screen_time_numeric", "w3_picture_similarities_quartiles", "w3_naming_vocabulary_quartiles",
  "w3_SDQ_total_difficulties_quartiles", "w3_parenting_hostility_quartiles", "w3_parenting_consistency_quartiles",
  "w3_positive_conflict_diff", "w3_positive_conflict_quartiles", "w3_parental_stress_quartiles",
  "w3_SSIS_composite", "w3_SSIS_composite_quartiles", "w3_school_DEIS_status", "w3_school_size",
  "w3_PT_meeting_attendance", 
  
  "w4_family_structure","w4_has_partner", "w4_educational_composite", "w4_creative_composite",
  "w4_educational_quartiles", "w4_creative_quartiles", "w4_screen_time", "w4_school_willingness_score",
  "w4_composite_schoolwork", "w4_schoolwork_quartile", "w4_SSIS_composite", "w4_SSIS_composite_quartiles",
  "w4_positive_conflict_diff", "w4_positive_conflict_quartiles", "w4_SDQ_total_difficulties_quartiles",
  
  "w5_mother_education","w5_has_partner", "w5_family_social_class", "w5_family_structure","w5_household_size",
  "w5_income_quintile", "w5_edu_composite", "w5_edu_quartiles", "w5_reading_composite",
  "w5_reading_quartiles", "w5_creative_composite", "w5_creative_quartiles", "w5_team_sports",
  "w5_parent_teacher_meeting", "w5_homework_time", "w5_homework_help", "w5_school_engagement_composite",
  "w5_school_engagement_quartiles", "w5_edu_perception_composite", "w5_edu_perception_quartiles",
  "w5_expected_education", "w5_school_perception_composite", "w5_school_perception_quartiles",
  "w5_bullying_status", "w5_SDQ_total_difficulties_quartiles",
  "w5_parenting_hostility_quartiles", "w5_parenting_consistency_quartiles", "w5_positive_conflict_diff",
  "w5_positive_conflict_quartiles", "w5_parental_stress_quartiles", "w5_drum_score"
)

long_data_selected <- long_data %>%
  select(all_of(columns_to_keep))
colnames(long_data_selected)


##########################################################
###############      imputations   ##############
##########################################################

data_imputed <- long_data_selected

#NA stats
# Calculate the number of NA's in each column
na_counts <- colSums(is.na(data_imputed))
# Calculate the percentage of NA's in each column
na_percentage <- round((na_counts / nrow(data_imputed)) * 100, 2)
# Combine the results into a data frame for easy viewing
na_summary <- data.frame(
  Column = names(na_counts),
  NA_Count = na_counts,
  NA_Percentage = na_percentage,
  row.names = NULL  # Ensure no duplicate column names
)

# Filter out columns with no NA's and sort by NA_Percentage (highest to lowest)
na_summary <- na_summary[na_summary$NA_Count > 0, ]
na_summary <- na_summary[order(-na_summary$NA_Percentage), ]
# Print the sorted summary
print(na_summary)
# Number of variables with missing data
num_with_missing <- nrow(na_summary)
# Number of variables with more than 1% missing data
num_above_1_percent <- sum(na_summary$NA_Percentage > 1)
# Print the counts
cat("Number of variables with missing data:", num_with_missing, "\n")
cat("Number of variables with more than 1% missing data:", num_above_1_percent, "\n")

##########################################################
# Function to impute by mode
impute_mode <- function(column) {
  mode_value <- as.numeric(names(sort(table(column), decreasing = TRUE)[1]))
  column[is.na(column)] <- mode_value
  return(column)
}


##########################################################
####1. family social class
# Impute w3_family_social_class using the value from w2_family_social_class
data_imputed$w3_family_social_class[is.na(data_imputed$w3_family_social_class)] <- data_imputed$w2_family_social_class[is.na(data_imputed$w3_family_social_class)]

# Function to check for NA values in specified columns
check_missing_values <- function(df, columns) {
  sapply(columns, function(col) sum(is.na(df[[col]])))
}

# List of family social class columns to check
social_class_columns <- c("w1_family_social_class", "w2_family_social_class", "w3_family_social_class", "w5_family_social_class")

# Check for remaining missing values in the family social class columns
missing_values_summary <- check_missing_values(data_imputed, social_class_columns)

# Print the summary of missing values
print(missing_values_summary)





# Convert numerical codes to categorical labels
data_imputed <- data_imputed %>%
  mutate(w3_family_social_class = case_when(
    w3_family_social_class %in% c("1", "2") ~ "Professional/Managerial",
    w3_family_social_class %in% c("3", "4") ~ "Non-Manual/Skilled",
    TRUE ~ as.character(w3_family_social_class)  # Keep other values unchanged
  ))

# Convert to factor with levels
data_imputed$w3_family_social_class <- factor(data_imputed$w3_family_social_class,
                                              levels = c("Professional/Managerial", 
                                                         "Non-Manual/Skilled", 
                                                         "Semi-Skilled/Unskilled", 
                                                         "Never Worked"))

##########################################################

# Step 1: Create a temporary copy of the data
temp_data <- data_imputed %>% 
  select(w1_family_social_class, w1_income_quintile)  # Select only relevant columns
# Step 2: Convert social class to numeric values in the temporary dataframe
temp_data <- temp_data %>%
  mutate(w1_family_social_class_numeric = case_when(
    w1_family_social_class == "Never Worked" ~ 1,
    w1_family_social_class == "Semi-Skilled/Unskilled" ~ 2,
    w1_family_social_class == "Non-Manual/Skilled" ~ 3,
    w1_family_social_class == "Professional/Managerial" ~ 4,
    TRUE ~ NA_real_  # Handle any unexpected values
  ))
# Convert w1_income_quintile from ordered factor to numeric
temp_data <- temp_data %>%
  mutate(w1_income_quintile_numeric = as.numeric(as.character(w1_income_quintile)))
# Step 3: Filter out rows with missing values
temp_data_complete <- temp_data %>%
  filter(!is.na(w1_family_social_class_numeric) & !is.na(w1_income_quintile_numeric))
# Step 4: Calculate the correlation
correlation <- cor(temp_data_complete$w1_family_social_class_numeric, temp_data_complete$w1_income_quintile_numeric)
print(correlation)


# Step 1: Create a temporary dataframe with relevant columns
temp_data <- data_imputed %>%
  select(w1_family_social_class, w2_family_social_class)
# Step 2: Identify changes in social class
temp_data <- temp_data %>%
  mutate(
    change_in_social_class = case_when(
      w1_family_social_class != w2_family_social_class ~ 1,  # Changed
      TRUE ~ 0  # No change
    )
  )
# Step 3: Count the number of people who changed social class
change_summary <- temp_data %>%
  summarise(
    total_changes = sum(change_in_social_class, na.rm = TRUE),
    total_no_changes = sum(change_in_social_class == 0, na.rm = TRUE)
  )
# Print the results
print(change_summary)
# Optional: To see the percentage of people who changed their social class
percentage_changes <- (change_summary$total_changes / (change_summary$total_changes + change_summary$total_no_changes)) * 100
print(paste("Percentage of people who changed social class:", round(percentage_changes, 2), "%"))




##########################################################
####2. income quintiles

# Function to calculate the mode of a vector
calculate_mode <- function(x) {
  tbl <- table(x)
  mode_value <- as.numeric(names(tbl[tbl == max(tbl)]))
  return(mode_value)
}

# Function to impute income quintile by mode within family social class for each wave
impute_by_family_social_class <- function(data, income_quintile_col, family_social_class_col) {
  data %>%
    group_by(.data[[family_social_class_col]]) %>%
    mutate(!!income_quintile_col := ifelse(
      is.na(.data[[income_quintile_col]]),
      calculate_mode(.data[[income_quintile_col]]),
      .data[[income_quintile_col]]
    )) %>%
    ungroup()
}

# List of income quintile columns for each wave
income_quintile_columns <- c("w1_income_quintile", "w2_income_quintile", "w3_income_quintile", "w5_income_quintile")

# List of corresponding family social class columns for each wave
family_social_class_columns <- c("w1_family_social_class", "w2_family_social_class", "w3_family_social_class", "w5_family_social_class")

# Apply the imputation function to each wave's income quintile column
for (i in seq_along(income_quintile_columns)) {
  data_imputed <- impute_by_family_social_class(
    data_imputed, 
    income_quintile_columns[i], 
    family_social_class_columns[i]
  )
}

# Check for remaining missing values to ensure imputation was successful
check_missing_values <- function(df, columns) {
  sapply(columns, function(col) sum(is.na(df[[col]])))
}

missing_values_after_imputation <- check_missing_values(data_imputed, income_quintile_columns)
print(missing_values_after_imputation)


##########################################################
####3. w3_school_size

# Function to calculate the mode of a vector
calculate_mode <- function(x) {
  tbl <- table(x)
  mode_value <- as.numeric(names(tbl[tbl == max(tbl)]))
  return(mode_value)
}

# Function to impute school size by mode within income quintile
impute_school_size_by_income_quintile <- function(data, school_size_col, income_quintile_col) {
  data %>%
    group_by(.data[[income_quintile_col]]) %>%
    mutate(!!school_size_col := ifelse(
      is.na(.data[[school_size_col]]),
      calculate_mode(.data[[school_size_col]]),
      .data[[school_size_col]]
    )) %>%
    ungroup()
}

# Apply the imputation function to w3_school_size based on w3_income_quintile
data_imputed <- impute_school_size_by_income_quintile(
  data_imputed,
  "w3_school_size",
  "w3_income_quintile"
)

# Check for remaining missing values to ensure imputation was successful
check_missing_values <- function(df, columns) {
  sapply(columns, function(col) sum(is.na(df[[col]])))
}

# Checking missing values in the w3_school_size column after imputation
missing_values_after_imputation <- check_missing_values(data_imputed, c("w3_school_size"))
print(missing_values_after_imputation)


# Function to calculate the mode of a vector
calculate_mode <- function(x) {
  tbl <- table(x)
  mode_value <- as.numeric(names(tbl[tbl == max(tbl)]))
  return(mode_value)
}

# Function to impute school size by mode within income quintile
impute_school_size_by_income_quintile <- function(data, school_size_col, income_quintile_col) {
  data %>%
    group_by(.data[[income_quintile_col]]) %>%
    mutate(!!school_size_col := ifelse(
      is.na(.data[[school_size_col]]),
      calculate_mode(.data[[school_size_col]]),
      .data[[school_size_col]]
    )) %>%
    ungroup()
}

# Apply the imputation function to w3_school_size based on w3_income_quintile
data_imputed <- impute_school_size_by_income_quintile(
  data_imputed,
  "w3_school_size",
  "w3_income_quintile"
)

# Check for remaining missing values to ensure imputation was successful
check_missing_values <- function(df, columns) {
  sapply(columns, function(col) sum(is.na(df[[col]])))
}

# Checking missing values in the w3_school_size column after imputation
missing_values_after_imputation <- check_missing_values(data_imputed, c("w3_school_size"))
print(missing_values_after_imputation)


##########################################################
####4. w3_school DEIS status

# Function to calculate the mode of a vector
calculate_mode <- function(x) {
  tbl <- table(x)
  mode_value <- as.numeric(names(tbl[tbl == max(tbl)]))
  return(mode_value)
}

# Function to impute school DEIS status by mode within family social class
impute_school_DEIS_status_by_family_social_class <- function(data, school_DEIS_col, family_social_class_col) {
  data %>%
    group_by(.data[[family_social_class_col]]) %>%
    mutate(!!school_DEIS_col := ifelse(
      is.na(.data[[school_DEIS_col]]),
      calculate_mode(.data[[school_DEIS_col]]),
      .data[[school_DEIS_col]]
    )) %>%
    ungroup()
}
# Apply the imputation function to w3_school_DEIS_status based on w3_family_social_class
data_imputed <- impute_school_DEIS_status_by_family_social_class(
  data_imputed,
  "w3_school_DEIS_status",
  "w3_family_social_class"
)
# Check for remaining missing values to ensure imputation was successful
check_missing_values <- function(df, columns) {
  sapply(columns, function(col) sum(is.na(df[[col]])))
}
# Checking missing values in the w3_school_DEIS_status column after imputation
missing_values_after_imputation <- check_missing_values(data_imputed, c("w3_school_DEIS_status"))
print(missing_values_after_imputation)

# Function to calculate the mode of a vector
calculate_mode <- function(x) {
  tbl <- table(x)
  mode_value <- as.numeric(names(tbl[tbl == max(tbl)]))
  return(mode_value)
}

# Function to impute school DEIS status by mode within family social class
impute_school_DEIS_status_by_family_social_class <- function(data, school_DEIS_col, family_social_class_col) {
  data %>%
    group_by(.data[[family_social_class_col]]) %>%
    mutate(!!school_DEIS_col := ifelse(
      is.na(.data[[school_DEIS_col]]),
      calculate_mode(.data[[school_DEIS_col]]),
      .data[[school_DEIS_col]]
    )) %>%
    ungroup()
}
# Apply the imputation function to w3_school_DEIS_status based on w3_family_social_class
data_imputed <- impute_school_DEIS_status_by_family_social_class(
  data_imputed,
  "w3_school_DEIS_status",
  "w3_family_social_class"
)
# Check for remaining missing values to ensure imputation was successful
check_missing_values <- function(df, columns) {
  sapply(columns, function(col) sum(is.na(df[[col]])))
}
# Checking missing values in the w3_school_DEIS_status column after imputation
missing_values_after_imputation <- check_missing_values(data_imputed, c("w3_school_DEIS_status"))
print(missing_values_after_imputation)



##########################################################
####5. w4_positive_conflict_diff

# Impute w4_positive_conflict_diff using w3_positive_conflict_diff
data_imputed <- data_imputed %>%
  mutate(w4_positive_conflict_diff = ifelse(
    is.na(w4_positive_conflict_diff),
    w3_positive_conflict_diff,
    w4_positive_conflict_diff
  ))

# Check for remaining missing values in w4_positive_conflict_diff after imputation
missing_values_after_imputation <- sum(is.na(data_imputed$w4_positive_conflict_diff))
print(missing_values_after_imputation)


##########################################################
####5. w4_positive_conflict_quartiles and w4_screen_time

# Impute w4_positive_conflict_quartiles using w3_positive_conflict_quartiles
data_imputed <- data_imputed %>%
  mutate(w4_positive_conflict_quartiles = ifelse(
    is.na(w4_positive_conflict_quartiles),
    w3_positive_conflict_quartiles,
    w4_positive_conflict_quartiles
  ))

# Function to calculate the mode of a vector
calculate_mode <- function(x) {
  tbl <- table(x)
  mode_value <- as.numeric(names(tbl[tbl == max(tbl)]))
  return(mode_value)
}

# Impute w4_screen_time using the mode of w4_screen_time
mode_screen_time <- calculate_mode(data_imputed$w4_screen_time)
data_imputed <- data_imputed %>%
  mutate(w4_screen_time = ifelse(
    is.na(w4_screen_time),
    mode_screen_time,
    w4_screen_time
  ))

# Check for remaining missing values in w4_positive_conflict_quartiles and w4_screen_time after imputation
missing_values_after_imputation <- data_imputed %>%
  summarise(
    w4_positive_conflict_quartiles = sum(is.na(w4_positive_conflict_quartiles)),
    w4_screen_time = sum(is.na(w4_screen_time))
  )
print(missing_values_after_imputation)


##########################################################
####6. w1_support_level

# Function to impute support level using the mode of income quintile
impute_w1_support_level <- function(data) {
  data %>%
    group_by(w1_income_quintile) %>%
    mutate(w1_support_level = ifelse(
      is.na(w1_support_level),
      calculate_mode(w1_support_level),
      w1_support_level
    )) %>%
    ungroup()
}

# Apply the imputation function
data_imputed <- impute_w1_support_level(data_imputed)

# Check for remaining missing values
missing_values_after_imputation_w1_support_level <- sum(is.na(data_imputed$w1_support_level))
print(missing_values_after_imputation_w1_support_level)
w1_sub$support_level <- factor(w1_sub$MMK2, levels = 1:4, labels = c("Enough help", "Not enough help", "No help at all", "Don't need help"))

# Function to impute support level using the mode of income quintile
impute_w1_support_level <- function(data) {
  data %>%
    group_by(w1_income_quintile) %>%
    mutate(w1_support_level = ifelse(
      is.na(w1_support_level),
      calculate_mode(w1_support_level),
      w1_support_level
    )) %>%
    ungroup()
}

# Apply the imputation function
data_imputed <- impute_w1_support_level(data_imputed)

# Check for remaining missing values
missing_values_after_imputation_w1_support_level <- sum(is.na(data_imputed$w1_support_level))
print(missing_values_after_imputation_w1_support_level)


##########################################################
####7. w3_PT_meeting_attendance

# Function to impute PT meeting attendance using the mode of income quintile
impute_w3_PT_meeting_attendance <- function(data) {
  data %>%
    group_by(w3_income_quintile) %>%
    mutate(w3_PT_meeting_attendance = ifelse(
      is.na(w3_PT_meeting_attendance),
      calculate_mode(w3_PT_meeting_attendance),
      w3_PT_meeting_attendance
    )) %>%
    ungroup()
}

# Apply the imputation function
data_imputed <- impute_w3_PT_meeting_attendance(data_imputed)

# Check for remaining missing values
missing_values_after_imputation_w3_PT <- sum(is.na(data_imputed$w3_PT_meeting_attendance))
print(missing_values_after_imputation_w3_PT)

# Function to impute PT meeting attendance using the mode of income quintile
impute_w3_PT_meeting_attendance <- function(data) {
  data %>%
    group_by(w3_income_quintile) %>%
    mutate(w3_PT_meeting_attendance = ifelse(
      is.na(w3_PT_meeting_attendance),
      calculate_mode(w3_PT_meeting_attendance),
      w3_PT_meeting_attendance
    )) %>%
    ungroup()
}

# Apply the imputation function
data_imputed <- impute_w3_PT_meeting_attendance(data_imputed)

# Check for remaining missing values
missing_values_after_imputation_w3_PT <- sum(is.na(data_imputed$w3_PT_meeting_attendance))
print(missing_values_after_imputation_w3_PT)




##########################################################
####8. w2_naming_vocabulary_quartiles and w2_picture_similarities_quartiles

# Function to impute quartiles using the mode of educational quartiles
impute_w2_quartiles <- function(data) {
  data %>%
    group_by(w2_educational_quartiles) %>%
    mutate(
      w2_naming_vocabulary_quartiles = ifelse(
        is.na(w2_naming_vocabulary_quartiles),
        calculate_mode(w2_naming_vocabulary_quartiles),
        w2_naming_vocabulary_quartiles
      ),
      w2_picture_similarities_quartiles = ifelse(
        is.na(w2_picture_similarities_quartiles),
        calculate_mode(w2_picture_similarities_quartiles),
        w2_picture_similarities_quartiles
      )
    ) %>%
    ungroup()
}

# Apply the imputation function
data_imputed <- impute_w2_quartiles(data_imputed)

# Check for remaining missing values
missing_values_after_imputation_w2_quartiles <- data_imputed %>%
  summarise(
    w2_naming_vocabulary_quartiles = sum(is.na(w2_naming_vocabulary_quartiles)),
    w2_picture_similarities_quartiles = sum(is.na(w2_picture_similarities_quartiles))
  )
print(missing_values_after_imputation_w2_quartiles)

# Function to impute quartiles using the mode of educational quartiles
impute_w2_quartiles <- function(data) {
  data %>%
    group_by(w2_educational_quartiles) %>%
    mutate(
      w2_naming_vocabulary_quartiles = ifelse(
        is.na(w2_naming_vocabulary_quartiles),
        calculate_mode(w2_naming_vocabulary_quartiles),
        w2_naming_vocabulary_quartiles
      ),
      w2_picture_similarities_quartiles = ifelse(
        is.na(w2_picture_similarities_quartiles),
        calculate_mode(w2_picture_similarities_quartiles),
        w2_picture_similarities_quartiles
      )
    ) %>%
    ungroup()
}

# Apply the imputation function
data_imputed <- impute_w2_quartiles(data_imputed)

# Check for remaining missing values
missing_values_after_imputation_w2_quartiles <- data_imputed %>%
  summarise(
    w2_naming_vocabulary_quartiles = sum(is.na(w2_naming_vocabulary_quartiles)),
    w2_picture_similarities_quartiles = sum(is.na(w2_picture_similarities_quartiles))
  )
print(missing_values_after_imputation_w2_quartiles)




##########################################################
####9. Everything below 2% = imputed by mode

# Function to impute missing values with the most common value (mode)
impute_by_mode <- function(column) {
  mode_value <- as.character(column) %>% 
    table() %>% 
    sort(decreasing = TRUE) %>% 
    names() %>% 
    .[1]
  column[is.na(column)] <- mode_value
  return(column)
}

# List of columns to impute
columns_to_impute <- c(
  "w1_birth_weight_quartile", "w4_SDQ_total_difficulties_quartiles", "w3_parental_stress_quartiles",
  "w5_school_perception_composite", "w5_school_perception_quartiles", "w5_parenting_consistency_quartiles",
  "w4_composite_schoolwork", "w4_schoolwork_quartile", "w5_parenting_hostility_quartiles",
  "w5_parental_stress_quartiles", "w2_parental_stress_quartiles", "w4_SSIS_composite",
  "w4_SSIS_composite_quartiles", "w4_school_willingness_score", "w4_family_structure",
  "w3_naming_vocabulary_quartiles", "w3_picture_similarities_quartiles", "w5_homework_help",
  "w5_homework_time", "w5_school_engagement_composite", "w5_school_engagement_quartiles",
  "w1_totstress_quartiles", "w1_pregnancy_awareness", "w2_positive_conflict_diff",
  "w2_positive_conflict_quartiles", "w5_mother_education", "w5_expected_education",
  "w3_SSIS_composite", "w3_SSIS_composite_quartiles", "w5_parent_teacher_meeting",
  "w1_unadapt_quartiles", "w5_positive_conflict_diff", "w5_positive_conflict_quartiles",
  "w1_fussy_quartiles", "w5_edu_perception_composite", "w5_edu_perception_quartiles",
  "w5_team_sports", "w2_mother_education", "w1_dull_quartiles", "w1_unpredict_quartiles",
  "w2_support_level", "w2_SDQ_prosocial_quartiles", "w5_SDQ_total_difficulties_quartiles",
  "w1_ever_smoked", "w1_composite_temperament_quartiles", "w2_SDQ_total_difficulties_quartiles",
  "w2_parenting_consistency_quartiles", "w3_parenting_hostility_quartiles", "w3_positive_conflict_diff",
  "w3_positive_conflict_quartiles", "w5_reading_composite", "w5_reading_quartiles",
  "w1_breastfeeding_status", "w2_parenting_hostility_quartiles", "w3_parenting_consistency_quartiles",
  "w1_mother_education", "w3_mother_education", "w3_SDQ_total_difficulties_quartiles",
  "w4_educational_composite", "w4_educational_quartiles", "w5_family_social_class",
  "w5_edu_composite", "w5_edu_quartiles", "w5_creative_composite", "w5_creative_quartiles"
)

# Apply mode imputation to specified columns
data_imputed <- data_imputed %>%
  mutate(across(all_of(columns_to_impute), impute_by_mode))


# Function to check for missing values in each column
check_na <- function(df, column_name) {
  sum(is.na(df[[column_name]]))
}

# Check each column and print the number of NAs
for (col in columns_to_impute) {
  na_count <- check_na(data_imputed, col)
  if (na_count > 0) {
    cat(paste(col, "still has", na_count, "missing values.\n"))
  } else {
    cat(paste(col, "has been successfully imputed with no missing values.\n"))
  }
}


####CHECK

#NA stats
# Calculate the number of NA's in each column
na_counts <- colSums(is.na(data_imputed))
# Calculate the percentage of NA's in each column
na_percentage <- round((na_counts / nrow(data_imputed)) * 100, 2)
# Combine the results into a data frame for easy viewing
na_summary <- data.frame(
  Column = names(na_counts),
  NA_Count = na_counts,
  NA_Percentage = na_percentage,
  row.names = NULL  # Ensure no duplicate column names
)

# Filter out columns with no NA's and sort by NA_Percentage (highest to lowest)
na_summary <- na_summary[na_summary$NA_Count > 0, ]
na_summary <- na_summary[order(-na_summary$NA_Percentage), ]
# Print the sorted summary
print(na_summary)


#JUST DRUM_SCORE








##########################################################
################# END OF METHOD 1 - ROBUST ########################
##########################################################

##########################################################
################# METHOD 2 - ALL BY MODE - SIMPLISTIC #################
##########################################################



data_imputed_method2 <- long_data_selected

#NA stats
# Calculate the number of NA's in each column
na_counts <- colSums(is.na(data_imputed_method2))
# Calculate the percentage of NA's in each column
na_percentage <- round((na_counts / nrow(data_imputed_method2)) * 100, 2)
# Combine the results into a data frame for easy viewing
na_summary <- data.frame(
  Column = names(na_counts),
  NA_Count = na_counts,
  NA_Percentage = na_percentage,
  row.names = NULL  # Ensure no duplicate column names
)

# Filter out columns with no NA's and sort by NA_Percentage (highest to lowest)
na_summary <- na_summary[na_summary$NA_Count > 0, ]
na_summary <- na_summary[order(-na_summary$NA_Percentage), ]
# Print the sorted summary
print(na_summary)
# Number of variables with missing data
num_with_missing <- nrow(na_summary)
# Number of variables with more than 1% missing data
num_above_1_percent <- sum(na_summary$NA_Percentage > 1)
# Print the counts
cat("Number of variables with missing data:", num_with_missing, "\n")
cat("Number of variables with more than 1% missing data:", num_above_1_percent, "\n")


# Create a list of columns to impute, excluding 'w5_drum_score'
impute_columns_method2 <- c("w3_school_size", "w5_income_quintile", "w4_positive_conflict_diff",
                            "w4_positive_conflict_quartiles", "w1_income_quintile", "w1_support_level",
                            "w3_family_social_class", "w2_income_quintile", "w3_income_quintile",
                            "w3_PT_meeting_attendance", "w4_screen_time", "w2_naming_vocabulary_quartiles",
                            "w3_school_DEIS_status", "w2_picture_similarities_quartiles",
                            "w1_birth_weight_quartile", "w4_SDQ_total_difficulties_quartiles",
                            "w3_parental_stress_quartiles", "w5_school_perception_composite",
                            "w5_school_perception_quartiles", "w5_parenting_consistency_quartiles",
                            "w4_composite_schoolwork", "w4_schoolwork_quartile", "w5_parenting_hostility_quartiles",
                            "w5_parental_stress_quartiles", "w2_parental_stress_quartiles", "w4_SSIS_composite",
                            "w4_SSIS_composite_quartiles", "w4_school_willingness_score", "w4_family_structure",
                            "w3_naming_vocabulary_quartiles", "w3_picture_similarities_quartiles",
                            "w5_homework_help", "w5_homework_time", "w5_school_engagement_composite",
                            "w5_school_engagement_quartiles", "w1_totstress_quartiles", "w1_pregnancy_awareness",
                            "w2_positive_conflict_diff", "w2_positive_conflict_quartiles", "w5_mother_education",
                            "w5_expected_education", "w3_SSIS_composite", "w3_SSIS_composite_quartiles",
                            "w5_parent_teacher_meeting", "w1_unadapt_quartiles", "w5_positive_conflict_diff",
                            "w5_positive_conflict_quartiles", "w1_fussy_quartiles", "w5_edu_perception_composite",
                            "w5_edu_perception_quartiles", "w5_team_sports", "w2_mother_education",
                            "w1_dull_quartiles", "w1_unpredict_quartiles", "w2_support_level",
                            "w2_SDQ_prosocial_quartiles", "w5_SDQ_total_difficulties_quartiles",
                            "w1_ever_smoked", "w1_composite_temperament_quartiles", "w2_SDQ_total_difficulties_quartiles",
                            "w2_parenting_consistency_quartiles", "w3_parenting_hostility_quartiles",
                            "w3_positive_conflict_diff", "w3_positive_conflict_quartiles",
                            "w5_reading_composite", "w5_reading_quartiles", "w1_breastfeeding_status",
                            "w2_parenting_hostility_quartiles", "w3_parenting_consistency_quartiles",
                            "w1_mother_education", "w3_mother_education", "w3_SDQ_total_difficulties_quartiles",
                            "w4_educational_composite", "w4_educational_quartiles", "w5_family_social_class",
                            "w5_edu_composite", "w5_edu_quartiles", "w5_creative_composite",
                            "w5_creative_quartiles")





# Apply mode imputation to specified columns
data_imputed_method2 <- data_imputed_method2 %>%
  mutate(across(all_of(impute_columns_method2), impute_by_mode))


# Function to check for missing values in each column
check_na <- function(df, column_name) {
  sum(is.na(df[[column_name]]))
}

# Check each column and print the number of NAs
for (col in impute_columns_method2) {
  na_count <- check_na(data_imputed_method2, col)
  if (na_count > 0) {
    cat(paste(col, "still has", na_count, "missing values.\n"))
  } else {
    cat(paste(col, "has been successfully imputed with no missing values.\n"))
  }
}



#NA stats
# Calculate the number of NA's in each column
na_counts <- colSums(is.na(data_imputed_method2))
# Calculate the percentage of NA's in each column
na_percentage <- round((na_counts / nrow(data_imputed_method2)) * 100, 2)
# Combine the results into a data frame for easy viewing
na_summary <- data.frame(
  Column = names(na_counts),
  NA_Count = na_counts,
  NA_Percentage = na_percentage,
  row.names = NULL  # Ensure no duplicate column names
)

# Filter out columns with no NA's and sort by NA_Percentage (highest to lowest)
na_summary <- na_summary[na_summary$NA_Count > 0, ]
na_summary <- na_summary[order(-na_summary$NA_Percentage), ]
# Print the sorted summary
print(na_summary)


##########################################################
################# END OF METHOD 2 ########################
##########################################################

# Remove all rows with NA values
df_clean <- na.omit(data_imputed)
df_clean_2 <- na.omit(data_imputed_method2)



columns_to_keep2 <- c(
  "household_id",
  
  "w1_has_partner","w1_household_size", "w1_family_structure","w1_family_social_class",
  "w1_income_quintile", "w1_mother_education",
  "w1_pregnancy_awareness", "w1_birth_weight_quartile", "w1_breastfeeding_status",
  "w1_breastfeeding_duration", "w1_current_smoking", "w1_ever_smoked", "w1_smoking_in_household",
  "w1_alcohol_frequency", "w1_heavy_drinking", "w1_support_level", "w1_grandparent_contact",
  "w1_fussy_quartiles", "w1_unadapt_quartiles", "w1_dull_quartiles", "w1_unpredict_quartiles",
  "w1_composite_temperament_quartiles", "w1_totstress_quartiles"
  , 
  
  "w2_has_partner", "w2_household_size", "w2_family_structure",
  "w2_family_social_class", "w2_income_quintile", "w2_mother_education", "w2_support_level",
  "w2_educational_quartiles", "w2_creative_quartiles",
  "w2_parental_stress_quartiles", "w2_SDQ_prosocial_quartiles", "w2_SDQ_total_difficulties_quartiles",
  "w2_parenting_hostility_quartiles", "w2_parenting_consistency_quartiles",
  "w2_positive_conflict_quartiles", "w2_picture_similarities_quartiles", "w2_naming_vocabulary_quartiles",
  
  "w3_has_partner", "w3_household_size", "w3_mother_education", "w3_income_quintile",
  "w3_household_type", "w3_family_social_class",
  "w3_educational_quartiles", "w3_creative_quartiles", "w3_screen_time",
  "w3_screen_time_numeric", "w3_picture_similarities_quartiles", "w3_naming_vocabulary_quartiles",
  "w3_SDQ_total_difficulties_quartiles", "w3_parenting_hostility_quartiles", "w3_parenting_consistency_quartiles",
  "w3_positive_conflict_quartiles", "w3_parental_stress_quartiles",
  "w3_SSIS_composite_quartiles", "w3_school_DEIS_status", "w3_school_size",
  "w3_PT_meeting_attendance", 
  
  "w4_family_structure","w4_has_partner", "w4_educational_composite", "w4_creative_composite",
  "w4_educational_quartiles", "w4_creative_quartiles", "w4_screen_time", "w4_school_willingness_score",
  "w4_composite_schoolwork", "w4_schoolwork_quartile", "w4_SSIS_composite_quartiles",
  "w4_positive_conflict_diff", "w4_positive_conflict_quartiles", "w4_SDQ_total_difficulties_quartiles",
  
  "w5_mother_education","w5_has_partner", "w5_family_social_class", "w5_family_structure","w5_household_size",
  "w5_income_quintile", "w5_edu_quartiles", "w5_reading_quartiles", "w5_creative_quartiles", "w5_team_sports",
  "w5_parent_teacher_meeting","w5_school_engagement_quartiles", "w5_edu_perception_quartiles",
  "w5_expected_education", "w5_school_perception_quartiles","w5_bullying_status", "w5_SDQ_total_difficulties_quartiles",
  "w5_parenting_hostility_quartiles", "w5_parenting_consistency_quartiles",
  "w5_positive_conflict_quartiles", "w5_parental_stress_quartiles",
  
  "w5_drum_score"
)


# Subset df_clean
df_clean<- df_clean[, columns_to_keep2]
# Subset df_clean2
df_clean_2 <- df_clean_2[, columns_to_keep2]




##################################################################################
###################### RE-FACTORISE AND SET TYPE ######################
##################################################################################

df_clean <- df_clean %>%
  mutate(
    # Binary factors
    w1_has_partner = factor(w1_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
    w1_smoking_in_household = factor(w1_smoking_in_household, levels = c(0, 1), labels = c("No", "Yes")),
    w1_heavy_drinking = factor(w1_heavy_drinking, levels = c(0, 1), labels = c("No", "Yes")),
    
    # Numeric
    w1_household_size = as.numeric(w1_household_size),
    
    # Categorical factors
    w1_family_structure = factor(w1_family_structure, 
                                 levels = c("One parent, 1 child", "One parent, 2+ children", 
                                            "Two parents, 1 child", "Two parents, 2+ children")),
    w1_family_social_class = factor(w1_family_social_class, 
                                    levels = c("Professional/Managerial", "Non-Manual/Skilled", 
                                               "Semi-Skilled/Unskilled", "Never Worked")),
    w1_mother_education = factor(w1_mother_education, 
                                 levels = c("Secondary or below", "Vocational/Non-degree", 
                                            "Degree level", "Postgraduate")),
    w1_pregnancy_awareness = factor(w1_pregnancy_awareness, levels = c(0, 1), 
                                    labels = c("unplanned", "planned")),
    w1_breastfeeding_status = factor(w1_breastfeeding_status, 
                                     levels = c("Never breastfed", "Ever breastfed")),
    w1_breastfeeding_duration = factor(w1_breastfeeding_duration, 
                                       levels = c("Never breastfed", "Short duration (≤3 months)", 
                                                  "Medium duration (3-6 months)", "Long duration (>6 months)")),
    w1_current_smoking = factor(w1_current_smoking, levels = c("Never", "Occasional", "Daily")),
    w1_ever_smoked = factor(w1_ever_smoked, levels = c("No", "Yes")),
    w1_support_level = factor(w1_support_level, levels = 1:4, labels = c("Enough help", "Not enough help", "No help at all", "Don't need help")),
    
    
    
    # Ordinal factors
    w1_income_quintile = factor(w1_income_quintile, levels = 1:5, ordered = TRUE),
    across(c(w1_fussy_quartiles, w1_unadapt_quartiles, w1_dull_quartiles, 
             w1_unpredict_quartiles, w1_composite_temperament_quartiles, 
             w1_totstress_quartiles),
           ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
    
    # Corrected variables
    w1_birth_weight_quartile = factor(w1_birth_weight_quartile,
                                      levels = c("Q1: 1499 or less", "Q2: 1500-2499",
                                                 "Q3: 2500-4599", "Q4: 4600 or more"),
                                      ordered = TRUE),
    w1_alcohol_frequency = factor(w1_alcohol_frequency,
                                  levels = c("Never", "Less than once a month", "1-2 times a month",
                                             "1-2 times a week", "3-4 times a week", "5-6 times a week",
                                             "Every day"),
                                  ordered = TRUE),
    w1_grandparent_contact = factor(w1_grandparent_contact, levels = c("Yes", "No"))
  )


# Check for NA values in Wave 1 variables
na_counts <- colSums(is.na(select(df_clean, starts_with("w1_"))))
print(na_counts[na_counts > 0])
df_clean <- na.omit(df_clean)


####################################

# First, preprocess the two variables
df_clean <- df_clean %>%
  mutate(
    w2_picture_similarities_quartiles = case_when(
      w2_picture_similarities_quartiles == 1 ~ "Q1",
      w2_picture_similarities_quartiles == 2 ~ "Q2",
      w2_picture_similarities_quartiles == 3 ~ "Q3",
      w2_picture_similarities_quartiles == 4 ~ "Q4",
      TRUE ~ as.character(w2_picture_similarities_quartiles)  # Keep any existing "Q" values
    ),
    w2_naming_vocabulary_quartiles = case_when(
      w2_naming_vocabulary_quartiles == 1 ~ "Q1",
      w2_naming_vocabulary_quartiles == 2 ~ "Q2",
      w2_naming_vocabulary_quartiles == 3 ~ "Q3",
      w2_naming_vocabulary_quartiles == 4 ~ "Q4",
      TRUE ~ as.character(w2_naming_vocabulary_quartiles)  # Keep any existing "Q" values
    )
  )


df_clean <- df_clean %>%
  mutate(
    # Binary factors
    w2_has_partner = factor(w2_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
    
    # Numeric
    w2_household_size = as.numeric(w2_household_size),
    
    # Categorical factors
    w2_family_structure = factor(w2_family_structure, 
                                 levels = c("One parent, 1 child", "One parent, 2+ children", 
                                            "Two parents, 1 child", "Two parents, 2+ children")),
    w2_family_social_class = factor(w2_family_social_class, 
                                    levels = c("Professional/Managerial", "Non-Manual/Skilled", 
                                               "Semi-Skilled/Unskilled", "Never Worked")),
    w2_mother_education = factor(w2_mother_education, 
                                 levels = c("Secondary or below", "Vocational/Non-degree", 
                                            "Degree level", "Postgraduate")),
    w2_support_level = factor(w2_support_level, 
                              levels = c("No help at all", "Not enough help", 
                                         "Enough help", "Don't need help")),
    
    # Ordinal factors
    w2_income_quintile = factor(w2_income_quintile, levels = 1:5, ordered = TRUE),
    
    # Quartile factors
    across(c(w2_educational_quartiles, w2_creative_quartiles,
             w2_parental_stress_quartiles, w2_SDQ_prosocial_quartiles, 
             w2_SDQ_total_difficulties_quartiles, w2_positive_conflict_quartiles,
             w2_picture_similarities_quartiles, w2_naming_vocabulary_quartiles),
           ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
    
    # Quintile factors
    across(c(w2_parenting_hostility_quartiles, w2_parenting_consistency_quartiles),
           ~factor(., levels = c("Q1", "Q2", "Q3", "Q4", "Q5"), ordered = TRUE))
  )

# Check for NA values in Wave 2 variables
na_counts <- colSums(is.na(select(df_clean, starts_with("w2_"))))
print(na_counts[na_counts > 0])
df_clean <- na.omit(df_clean)




###################################################################

df_clean <- df_clean %>% mutate(
  # Binary factors
  w3_has_partner = factor(w3_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
  
  # Numeric
  w3_household_size = as.numeric(w3_household_size),
  
  # Categorical factors
  w3_mother_education = factor(w3_mother_education, levels = c("Secondary or below", "Vocational/Non-degree", "Degree level", "Postgraduate")),
  w3_family_social_class = factor(w3_family_social_class, levels = c("Professional/Managerial", "Non-Manual/Skilled", "Semi-Skilled/Unskilled")),
  w3_school_DEIS_status = factor(w3_school_DEIS_status, levels = c(1, 2, 3), labels = c("DEIS", "Non-DEIS", "Unknown")),
  w3_school_size = factor(w3_school_size, levels = c(1, 2, 3), labels = c("Small", "Medium", "Large")),
  w3_PT_meeting_attendance = factor(w3_PT_meeting_attendance, levels = c(1, 2), labels = c("Low", "High")),
  
  # Ordinal factors
  w3_income_quintile = factor(w3_income_quintile, levels = 1:5, ordered = TRUE),
  
  # Quartile factors
  across(c(w3_educational_quartiles, w3_creative_quartiles, w3_picture_similarities_quartiles, 
           w3_naming_vocabulary_quartiles, w3_SDQ_total_difficulties_quartiles, 
           w3_parenting_hostility_quartiles, w3_parenting_consistency_quartiles, 
           w3_positive_conflict_quartiles, w3_parental_stress_quartiles, 
           w3_SSIS_composite_quartiles),
         ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
  
  # Numeric version of screen time
  w3_screen_time_numeric = case_when(
    w3_screen_time == "1 hour" ~ 1,
    w3_screen_time == "2 hours" ~ 2,
    w3_screen_time == "3 hours" ~ 3,
    w3_screen_time == "4 or more hours" ~ 4,
    TRUE ~ NA_real_
  )
)
# Check for NA values in Wave 3 variables
na_counts <- colSums(is.na(select(df_clean, starts_with("w3_"))))
print(na_counts[na_counts > 0])
df_clean <- na.omit(df_clean)


########################################


# Preprocessing step for w4_positive_conflict_quartiles
df_clean <- df_clean %>%
  mutate(
    w4_positive_conflict_quartiles = case_when(
      w4_positive_conflict_quartiles == 1 ~ "Q1",
      w4_positive_conflict_quartiles == 2 ~ "Q2",
      w4_positive_conflict_quartiles == 3 ~ "Q3",
      w4_positive_conflict_quartiles == 4 ~ "Q4",
      TRUE ~ as.character(w4_positive_conflict_quartiles)  # This handles any unexpected values
    )
  )




df_clean <- df_clean %>% mutate(
  # Categorical factors
  w4_family_structure = factor(w4_family_structure, levels = c("One parent, 1 child", "One parent, 2+ children", "Two parents, 1 child", "Two parents, 2+ children")),
  
  # Binary factors
  w4_has_partner = factor(case_when(
    w4_has_partner == 1 ~ 1,
    w4_has_partner %in% c(2, 9) ~ 0,
    TRUE ~ as.numeric(w4_has_partner)
  ), levels = c(0, 1)),
  
  # Numeric variables
  across(c(w4_educational_composite, w4_creative_composite, w4_school_willingness_score,
           w4_composite_schoolwork, w4_positive_conflict_diff), as.numeric),
  
  # Quartile factors
  across(c(w4_educational_quartiles, w4_creative_quartiles, w4_schoolwork_quartile, 
           w4_SSIS_composite_quartiles, w4_positive_conflict_quartiles, 
           w4_SDQ_total_difficulties_quartiles),
         ~factor(case_when(
           . == 1 ~ "Q1",
           . == 2 ~ "Q2",
           . == 3 ~ "Q3",
           . == 4 ~ "Q4",
           TRUE ~ as.character(.)
         ), levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
  
  # Screen time
  w4_screen_time = factor(case_when(
    w4_screen_time == 0 ~ "0",
    w4_screen_time %in% c(1, 2, 3, 4) ~ as.character(w4_screen_time),
    TRUE ~ NA_character_
  ), levels = c("0", "1", "2", "3", "4"), 
  labels = c("0 hours", "1 hour", "2 hours", "3 hours", "4 or more hours"), 
  ordered = TRUE)
)

# Check for NA values in Wave 4 variables
na_counts <- colSums(is.na(select(df_clean, starts_with("w4_"))))
print(na_counts[na_counts > 0])






########################################################

df_clean <- df_clean %>% mutate(
  # Categorical factors
  w5_mother_education = factor(w5_mother_education, levels = c("Secondary or below", "Vocational/Non-degree", "Degree level", "Postgraduate")),
  w5_has_partner = factor(w5_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
  w5_family_social_class = factor(w5_family_social_class, levels = c("Professional/Managerial", "Non-Manual/Skilled", "Semi-Skilled/Unskilled", "Validly no social class", "Employment status unknown")),
  w5_family_structure = factor(w5_family_structure, levels = c("One parent, 1 child", "One parent, 2+ children", "Two parents, 1 child", "Two parents, 2+ children")),
  
  # Numeric variables
  w5_household_size = as.numeric(w5_household_size),
  w5_drum_score = as.numeric(w5_drum_score),
  
  # Ordinal factors
  w5_income_quintile = factor(w5_income_quintile, levels = 1:5, ordered = TRUE),
  
  # Quartile factors
  across(c(w5_edu_quartiles, w5_reading_quartiles, w5_creative_quartiles, 
           w5_school_engagement_quartiles, w5_edu_perception_quartiles, 
           w5_school_perception_quartiles, w5_SDQ_total_difficulties_quartiles,
           w5_parenting_hostility_quartiles, w5_parenting_consistency_quartiles,
           w5_positive_conflict_quartiles, w5_parental_stress_quartiles),
         ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
  
  # Binary factors
  w5_team_sports = factor(w5_team_sports, levels = c("No", "Yes")),
  w5_parent_teacher_meeting = factor(w5_parent_teacher_meeting, levels = c("No", "Yes")),
  
  # Other categorical factors
  w5_expected_education = factor(w5_expected_education, levels = c("Secondary/Vocational", "Diploma/Certificate", "Degree or higher", "Don't know")),
  w5_bullying_status = factor(w5_bullying_status, levels = c("No bullying", "Infrequent bullying", "Frequent bullying"))
)

# Check for NA values in Wave 5 variables
na_counts <- colSums(is.na(select(df_clean, starts_with("w5_"))))
print(na_counts[na_counts > 0])
df_clean <- na.omit(df_clean)


#####################################################################

# Convert numeric values to factor with "No" and "Yes" labels
df_clean$w4_has_partner <- factor(df_clean$w4_has_partner,
                                  levels = c(0, 1),
                                  labels = c("No", "Yes"))


#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################


# Subset df_clean2
df_clean2 <- df_clean_2[, columns_to_keep2]



df_clean2 <- df_clean2 %>%
  mutate(
    # Binary factors
    w1_has_partner = factor(w1_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
    w1_smoking_in_household = factor(w1_smoking_in_household, levels = c(0, 1), labels = c("No", "Yes")),
    w1_heavy_drinking = factor(w1_heavy_drinking, levels = c(0, 1), labels = c("No", "Yes")),
    
    # Numeric
    w1_household_size = as.numeric(w1_household_size),
    
    # Categorical factors
    w1_family_structure = factor(w1_family_structure, 
                                 levels = c("One parent, 1 child", "One parent, 2+ children", 
                                            "Two parents, 1 child", "Two parents, 2+ children")),
    w1_family_social_class = factor(w1_family_social_class, 
                                    levels = c("Professional/Managerial", "Non-Manual/Skilled", 
                                               "Semi-Skilled/Unskilled", "Never Worked")),
    w1_mother_education = factor(w1_mother_education, 
                                 levels = c("Secondary or below", "Vocational/Non-degree", 
                                            "Degree level", "Postgraduate")),
    w1_pregnancy_awareness = factor(w1_pregnancy_awareness, levels = c(0, 1), 
                                    labels = c("unplanned", "planned")),
    w1_breastfeeding_status = factor(w1_breastfeeding_status, 
                                     levels = c("Never breastfed", "Ever breastfed")),
    w1_breastfeeding_duration = factor(w1_breastfeeding_duration, 
                                       levels = c("Never breastfed", "Short duration (≤3 months)", 
                                                  "Medium duration (3-6 months)", "Long duration (>6 months)")),
    w1_current_smoking = factor(w1_current_smoking, levels = c("Never", "Occasional", "Daily")),
    w1_ever_smoked = factor(w1_ever_smoked, levels = c("No", "Yes")),
    w1_support_level = factor(w1_support_level, 
                              levels = c("Enough help", "Not enough help", "No help at all", "Don't need help"),
                              ordered = TRUE),    
    
    
    # Ordinal factors
    w1_income_quintile = factor(w1_income_quintile, levels = 1:5, ordered = TRUE),
    across(c(w1_fussy_quartiles, w1_unadapt_quartiles, w1_dull_quartiles, 
             w1_unpredict_quartiles, w1_composite_temperament_quartiles, 
             w1_totstress_quartiles),
           ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
    
    # Corrected variables
    w1_birth_weight_quartile = factor(w1_birth_weight_quartile,
                                      levels = c("Q1: 1499 or less", "Q2: 1500-2499",
                                                 "Q3: 2500-4599", "Q4: 4600 or more"),
                                      ordered = TRUE),
    w1_alcohol_frequency = factor(w1_alcohol_frequency,
                                  levels = c("Never", "Less than once a month", "1-2 times a month",
                                             "1-2 times a week", "3-4 times a week", "5-6 times a week",
                                             "Every day"),
                                  ordered = TRUE),
    w1_grandparent_contact = factor(w1_grandparent_contact, levels = c("Yes", "No"))
  )


# Check for NA values in Wave 1 variables
na_counts <- colSums(is.na(select(df_clean2, starts_with("w1_"))))
print(na_counts[na_counts > 0])
df_clean2 <- na.omit(df_clean2)



####################################


df_clean2 <- df_clean2 %>%
  mutate(
    # Binary factors
    w2_has_partner = factor(w2_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
    
    # Numeric
    w2_household_size = as.numeric(w2_household_size),
    
    # Categorical factors
    w2_family_structure = factor(w2_family_structure, 
                                 levels = c("One parent, 1 child", "One parent, 2+ children", 
                                            "Two parents, 1 child", "Two parents, 2+ children")),
    w2_family_social_class = factor(w2_family_social_class, 
                                    levels = c("Professional/Managerial", "Non-Manual/Skilled", 
                                               "Semi-Skilled/Unskilled", "Never Worked")),
    w2_mother_education = factor(w2_mother_education, 
                                 levels = c("Secondary or below", "Vocational/Non-degree", 
                                            "Degree level", "Postgraduate")),
    w2_support_level = factor(w2_support_level, 
                              levels = c("No help at all", "Not enough help", 
                                         "Enough help", "Don't need help")),
    
    # Ordinal factors
    w2_income_quintile = factor(w2_income_quintile, levels = 1:5, ordered = TRUE),
    
    # Quartile factors
    across(c(w2_educational_quartiles, w2_creative_quartiles,
             w2_parental_stress_quartiles, w2_SDQ_prosocial_quartiles, 
             w2_SDQ_total_difficulties_quartiles, w2_positive_conflict_quartiles,
             w2_picture_similarities_quartiles, w2_naming_vocabulary_quartiles),
           ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
    
    # Quintile factors
    across(c(w2_parenting_hostility_quartiles, w2_parenting_consistency_quartiles),
           ~factor(., levels = c("Q1", "Q2", "Q3", "Q4", "Q5"), ordered = TRUE))
  )

# Check for NA values in Wave 2 variables
na_counts <- colSums(is.na(select(df_clean2, starts_with("w2_"))))
print(na_counts[na_counts > 0])
df_clean2 <- na.omit(df_clean2)




###################################################################

df_clean2 <- df_clean2 %>% mutate(
  # Binary factors
  w3_has_partner = factor(w3_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
  
  # Numeric
  w3_household_size = as.numeric(w3_household_size),
  
  # Categorical factors
  w3_mother_education = factor(w3_mother_education, levels = c("Secondary or below", "Vocational/Non-degree", "Degree level", "Postgraduate")),
  w3_family_social_class = factor(w3_family_social_class, levels = c("Professional/Managerial", "Non-Manual/Skilled", "Semi-Skilled/Unskilled")),
  w3_school_DEIS_status = factor(w3_school_DEIS_status, levels = c("DEIS", "Non-DEIS", "Unknown")),
  w3_school_size = factor(w3_school_size, levels = c("Small", "Medium", "Large")),
  w3_PT_meeting_attendance = factor(w3_PT_meeting_attendance, levels = c("Low", "High")),  
  # Ordinal factors
  w3_income_quintile = factor(w3_income_quintile, levels = 1:5, ordered = TRUE),
  
  # Quartile factors
  across(c(w3_educational_quartiles, w3_creative_quartiles, w3_picture_similarities_quartiles, 
           w3_naming_vocabulary_quartiles, w3_SDQ_total_difficulties_quartiles, 
           w3_parenting_hostility_quartiles, w3_parenting_consistency_quartiles, 
           w3_positive_conflict_quartiles, w3_parental_stress_quartiles, 
           w3_SSIS_composite_quartiles),
         ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
  
  # Numeric version of screen time
  w3_screen_time_numeric = case_when(
    w3_screen_time == "1 hour" ~ 1,
    w3_screen_time == "2 hours" ~ 2,
    w3_screen_time == "3 hours" ~ 3,
    w3_screen_time == "4 or more hours" ~ 4,
    TRUE ~ NA_real_
  )
)
# Check for NA values in Wave 3 variables
na_counts <- colSums(is.na(select(df_clean2, starts_with("w3_"))))
print(na_counts[na_counts > 0])
df_clean2 <- na.omit(df_clean2)





########################################

df_clean2 <- df_clean2 %>% mutate(
  # Categorical factors
  w4_family_structure = factor(w4_family_structure, levels = c("One parent, 1 child", "One parent, 2+ children", "Two parents, 1 child", "Two parents, 2+ children")),
  
  # Binary factors
  w4_has_partner = factor(case_when(
    w4_has_partner == 1 ~ 1,
    w4_has_partner %in% c(2, 9) ~ 0,
    TRUE ~ as.numeric(w4_has_partner)
  ), levels = c(0, 1)),
  
  # Numeric variables
  across(c(w4_educational_composite, w4_creative_composite, w4_school_willingness_score,
           w4_composite_schoolwork, w4_positive_conflict_diff), as.numeric),
  
  # Quartile factors
  across(c(w4_educational_quartiles, w4_creative_quartiles, w4_schoolwork_quartile, 
           w4_SSIS_composite_quartiles, w4_positive_conflict_quartiles, 
           w4_SDQ_total_difficulties_quartiles),
         ~factor(case_when(
           . == 1 ~ "Q1",
           . == 2 ~ "Q2",
           . == 3 ~ "Q3",
           . == 4 ~ "Q4",
           TRUE ~ as.character(.)
         ), levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
  
  # Screen time
  w4_screen_time = factor(case_when(
    w4_screen_time == 0 ~ "0",
    w4_screen_time %in% c(1, 2, 3, 4) ~ as.character(w4_screen_time),
    TRUE ~ NA_character_
  ), levels = c("0", "1", "2", "3", "4"), 
  labels = c("0 hours", "1 hour", "2 hours", "3 hours", "4 or more hours"), 
  ordered = TRUE)
)

# Check for NA values in Wave 4 variables
na_counts <- colSums(is.na(select(df_clean2, starts_with("w4_"))))
print(na_counts[na_counts > 0])





########################################################

df_clean2 <- df_clean2 %>% mutate(
  # Categorical factors
  w5_mother_education = factor(w5_mother_education, levels = c("Secondary or below", "Vocational/Non-degree", "Degree level", "Postgraduate")),
  w5_has_partner = factor(w5_has_partner, levels = c(0, 1), labels = c("No", "Yes")),
  w5_family_social_class = factor(w5_family_social_class, levels = c("Professional/Managerial", "Non-Manual/Skilled", "Semi-Skilled/Unskilled", "Validly no social class", "Employment status unknown")),
  w5_family_structure = factor(w5_family_structure, levels = c("One parent, 1 child", "One parent, 2+ children", "Two parents, 1 child", "Two parents, 2+ children")),
  
  # Numeric variables
  w5_household_size = as.numeric(w5_household_size),
  w5_drum_score = as.numeric(w5_drum_score),
  
  # Ordinal factors
  w5_income_quintile = factor(w5_income_quintile, levels = 1:5, ordered = TRUE),
  
  # Quartile factors
  across(c(w5_edu_quartiles, w5_reading_quartiles, w5_creative_quartiles, 
           w5_school_engagement_quartiles, w5_edu_perception_quartiles, 
           w5_school_perception_quartiles, w5_SDQ_total_difficulties_quartiles,
           w5_parenting_hostility_quartiles, w5_parenting_consistency_quartiles,
           w5_positive_conflict_quartiles, w5_parental_stress_quartiles),
         ~factor(., levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)),
  
  # Binary factors
  w5_team_sports = factor(w5_team_sports, levels = c("No", "Yes")),
  w5_parent_teacher_meeting = factor(w5_parent_teacher_meeting, levels = c("No", "Yes")),
  
  # Other categorical factors
  w5_expected_education = factor(w5_expected_education, levels = c("Secondary/Vocational", "Diploma/Certificate", "Degree or higher", "Don't know")),
  w5_bullying_status = factor(w5_bullying_status, levels = c("No bullying", "Infrequent bullying", "Frequent bullying"))
)

# Check for NA values in Wave 5 variables
na_counts <- colSums(is.na(select(df_clean2, starts_with("w5_"))))
print(na_counts[na_counts > 0])
df_clean2 <- na.omit(df_clean2)



#####################################################
#CHECK FOR BOTH DATAFRAME SAME TYPE ETC








#################################################################################
#################################################################################
#################################################################################
#####################################################################################
#################################################################################

#wide format for long. analysis

df_clean #preferred method
df_clean2 #all impute by mode

str(df_clean)

### using df_clean ##
################################
#wide format for long. analysis
################################

process_data <- function(df) {
  df %>%
    mutate(across(starts_with(c("w1_", "w2_", "w3_", "w4_", "w5_")), as.character)) %>%
    pivot_longer(
      cols = starts_with(c("w1_", "w2_", "w3_", "w4_", "w5_")),
      names_to = c("wave", "variable"),
      names_pattern = "(w[0-9]+)_(.*)",
      values_to = "value"
    ) %>%
    mutate(wave = as.numeric(str_extract(wave, "[0-9]+"))) %>%
    select(household_id, wave, variable, value) %>%
    pivot_wider(
      id_cols = c(household_id, wave),
      names_from = variable,
      values_from = value
    )
}
### using df_clean ROBUST
# Usage:
df_wide_by_wave <- process_data(df_clean)
### using df_clean ROBUST


##########################################################
#convert variables back to correct format
##########################################################

df_wide_by_wave <- df_wide_by_wave %>%
  # Convert numeric variables
  mutate(
    across(c(household_size, income_quintile, educational_composite, creative_composite, 
             school_willingness_score, composite_schoolwork, positive_conflict_diff, 
             drum_score), as.numeric)
  ) %>%
  # Convert factor variables
  mutate(
    across(c(has_partner, family_structure, family_social_class, mother_education, 
             pregnancy_awareness, breastfeeding_status, breastfeeding_duration,
             current_smoking, ever_smoked, smoking_in_household, heavy_drinking,
             support_level, grandparent_contact, household_type, screen_time,
             school_DEIS_status, school_size, PT_meeting_attendance, team_sports,
             parent_teacher_meeting, expected_education, bullying_status), as.factor)
  ) %>%
  # Convert ordinal factor variables
  mutate(
    across(c(income_quintile, birth_weight_quartile, alcohol_frequency,
             fussy_quartiles, unadapt_quartiles, dull_quartiles, unpredict_quartiles,
             composite_temperament_quartiles, totstress_quartiles, educational_quartiles,
             creative_quartiles, parental_stress_quartiles, SDQ_prosocial_quartiles,
             SDQ_total_difficulties_quartiles, parenting_hostility_quartiles,
             parenting_consistency_quartiles, positive_conflict_quartiles,
             picture_similarities_quartiles, naming_vocabulary_quartiles,
             schoolwork_quartile, SSIS_composite_quartiles, edu_quartiles,
             reading_quartiles, school_engagement_quartiles, edu_perception_quartiles,
             school_perception_quartiles), ~ factor(., ordered = TRUE))
  )
df_wide_by_wave
str(df_wide_by_wave)


#########################################
# Columns to remove
columns_to_remove <- c("household_type", "screen_time_numeric", "SDQ_prosocial_quartiles", "positive_conflict_diff"
                       ,"breastfeeding_duration", "current_smoking", "picture_similarities_quartiles", "support_level",
                       "naming_vocabulary_quartiles", "screen_time", "SSIS_composite_quartiles")
# Remove specified columns
df_wide_by_wave <- df_wide_by_wave %>%
  select(-all_of(columns_to_remove))
#check
df_wide_by_wave

#########################################
# Columns to fill forward
columns_to_fillforward <- c("household_size", "family_structure", "family_social_class", "income_quintile", "mother_education"
                            ,"pregnancy_awareness","birth_weight_quartile","breastfeeding_status","heavy_drinking"
                            ,"ever_smoked", "smoking_in_household","alcohol_frequency", "grandparent_contact"
                            ,"fussy_quartiles" , "unadapt_quartiles" , "dull_quartiles", "unpredict_quartiles"
                            ,"school_DEIS_status", "school_size", "PT_meeting_attendance"
)


# Fill forward within each household
df_filled <- df_wide_by_wave %>%
  arrange(household_id, wave) %>%
  group_by(household_id) %>%
  fill(all_of(columns_to_fillforward), .direction = "down") %>%
  ungroup()

df_filled

#########################################
#education and stress combine

# Function to combine stress quartiles and handle wave 4
combine_stress_quartiles <- function(totstress, parental_stress, wave) {
  case_when(
    wave == "w4" ~ NA_character_,  # Set to NA for wave 4
    !is.na(totstress) ~ totstress,
    !is.na(parental_stress) ~ parental_stress,
    TRUE ~ NA_character_
  )
}

# Combine columns and handle wave 4 for stress quartiles
df_filled <- df_filled %>%
  mutate(
    stress_quartiles = combine_stress_quartiles(totstress_quartiles, parental_stress_quartiles, wave),
    edu_quartiles = coalesce(educational_quartiles, edu_quartiles)
  ) %>%
  select(-totstress_quartiles, -parental_stress_quartiles, -educational_quartiles)


#########################################
#fill in wave 4 stress quartile using 2 different methods

df_filled <- df_filled %>%
  group_by(household_id) %>%
  arrange(household_id, wave) %>%
  mutate(
    most_common_stress = if_else(
      wave == 4,
      {
        prev_stress <- stress_quartiles[wave %in% c(1, 2, 3)]
        if (length(prev_stress[!is.na(prev_stress)]) > 0) {
          tab <- table(prev_stress)
          names(which.max(tab))
        } else {
          NA_character_
        }
      },
      NA_character_
    ),
    stress_quartiles = if_else(
      wave == 4 & is.na(stress_quartiles),
      coalesce(most_common_stress, lag(stress_quartiles)),
      stress_quartiles
    )
  ) %>%
  select(-most_common_stress) %>%
  ungroup()


df_filled

#########################################
#combine comp tempermante w1 with SQD total difficulties w2-5
df_filled <- df_filled %>%
  group_by(household_id) %>%
  mutate(
    SDQ_total_difficulties_quartiles = case_when(
      wave == "1" ~ composite_temperament_quartiles,
      TRUE ~ SDQ_total_difficulties_quartiles
    )
  ) %>%
  ungroup()
# Optionally, remove the original composite_temperament_quartiles column
df_filled <- df_filled %>%
  select(-composite_temperament_quartiles)



#########################################
#imputing parent hostility and postive conflict w4 only (w1 still missing)
# Impute parenting variables for Wave 4
df_filled <- df_filled %>%
  group_by(household_id) %>%
  mutate(
    parenting_hostility_quartiles = case_when(
      wave == "4" ~ first(parenting_hostility_quartiles[wave == "3"]),
      TRUE ~ parenting_hostility_quartiles
    ),
    parenting_consistency_quartiles = case_when(
      wave == "4" ~ first(parenting_consistency_quartiles[wave == "3"]),
      TRUE ~ parenting_consistency_quartiles
    )
  ) %>%
  ungroup()


#########################################
#removing wave 4 1 value only columns
# Columns to remove
columns_to_remove <- c("educational_composite", "creative_composite", "school_willingness_score","composite_schoolwork" 
                       ,"schoolwork_quartile", "reading_quartiles", "team_sports",  "parent_teacher_meeting"
                       , "school_engagement_quartiles", "edu_perception_quartiles"
                       ,"expected_education" ,"school_perception_quartiles" ,"bullying_status")

# Remove specified columns
df_filled <- df_filled %>%
  select(-all_of(columns_to_remove))


#########################################
#mother edu + social class in correct order
df_filled <- df_filled %>%
  mutate(
    family_social_class = factor(family_social_class, ordered = TRUE, 
                                 levels = c("Never Worked", "Validly no social class", "Semi-Skilled/Unskilled",
                                            "Non-Manual/Skilled", "Professional/Managerial")),
    mother_education = factor(mother_education, ordered = TRUE, 
                              levels = c("Secondary or below", "Vocational/Non-degree", "Degree level", "Postgraduate"))
  )


#########################################
# convert to numeric for growth modelling purpose
# Function to convert ordinal factor to numeric
factor_to_numeric <- function(x) {
  if(is.factor(x) && is.ordered(x)) {
    as.numeric(x)
  } else {
    x
  }
}
# Apply this function to all columns in your dataframe
df_filled_numeric <- df_filled %>%
  mutate(across(everything(), factor_to_numeric))
#Convert 'stress_quartiles' to numeric:
df_filled_numeric <- df_filled_numeric %>%
  mutate(stress_quartiles = as.numeric(factor(stress_quartiles, levels = c("Q1", "Q2", "Q3", "Q4"), ordered = TRUE)))

str(df_filled)
str(df_filled_numeric)


#################################################################
####### GROWTH MODEL
####################################################################################

# Your existing time_varying_vars
time_varying_vars <- c("household_size", "income_quintile", "SDQ_total_difficulties_quartiles", 
                       "stress_quartiles", "creative_quartiles", "parenting_hostility_quartiles", 
                       "parenting_consistency_quartiles", "positive_conflict_quartiles", "edu_quartiles",
                       "family_social_class", "mother_education")

# Modify the growth model function to include quadratic term and random slopes
fit_quadratic_growth_model <- function(outcome, data) {
  tryCatch({
    lmer(as.formula(paste(outcome, "~ wave + I(wave^2) + (wave + I(wave^2)|household_id)")), data = data)
  }, error = function(e) {
    message(paste("Error fitting model for", outcome, ":", e$message))
    return(NULL)
  })
}

# Function to extract fixed effects, random effects, and combine them
extract_effects <- function(model) {
  fe <- fixef(model)
  re <- ranef(model)$household_id
  
  # Combine fixed and random effects
  combined_effects <- re
  combined_effects$intercept <- combined_effects$`(Intercept)` + fe[1]
  combined_effects$linear_slope <- combined_effects$wave + fe[2]
  combined_effects$quadratic_slope <- combined_effects$`I(wave^2)` + fe[3]
  
  combined_effects$household_id <- as.numeric(rownames(combined_effects))
  combined_effects <- combined_effects[, c("household_id", "intercept", "linear_slope", "quadratic_slope")]
  
  return(combined_effects)
}
# Fit models for all variables
quadratic_growth_models <- lapply(time_varying_vars, fit_quadratic_growth_model, data = df_filled_numeric)
names(quadratic_growth_models) <- time_varying_vars
# Remove any NULL models (where fitting failed)
quadratic_growth_models <- quadratic_growth_models[!sapply(quadratic_growth_models, is.null)]
# Extract combined effects
combined_effects <- lapply(quadratic_growth_models, extract_effects)
# Combine effects into a single dataframe
combined_effects_df <- combined_effects %>%
  reduce(full_join, by = "household_id") %>%
  rename_with(~paste0(rep(names(quadratic_growth_models), each = 3), 
                      "_", c("intercept", "linear_slope", "quadratic_slope")), -household_id)
# Merge with the original data
df_final <- df_filled_numeric %>%
  filter(wave == 5) %>%  # Assuming drum_score is only available in wave 5
  left_join(combined_effects_df, by = "household_id")

str(df_final)

##########################################################################

# Function to sample households and generate trajectories
sample_and_generate <- function(df, var_name, low_val, high_val) {
  df %>%
    filter(!!sym(var_name) %in% c(low_val, high_val)) %>%
    group_by(!!sym(var_name)) %>%
    slice_sample(n = 100) %>%
    ungroup() %>%
    rowwise() %>%
    mutate(
      trajectory = list(tibble(
        trajectory_wave = 1:5,
        linear_value = !!sym(paste0(var_name, "_intercept")) + 
          !!sym(paste0(var_name, "_linear_slope")) * (trajectory_wave - 1),
        quadratic_value = !!sym(paste0(var_name, "_intercept")) + 
          !!sym(paste0(var_name, "_linear_slope")) * (trajectory_wave - 1) + 
          !!sym(paste0(var_name, "_quadratic_slope")) * (trajectory_wave - 1)^2
      ))
    ) %>%
    unnest(trajectory)
}

# Generate trajectories for all variables
income_trajectories <- sample_and_generate(df_final, "income_quintile", 1, 5)
stress_trajectories <- sample_and_generate(df_final, "stress_quartiles", 1, 4)
edu_trajectories <- sample_and_generate(df_final, "edu_quartiles", 1, 4)
sdq_trajectories <- sample_and_generate(df_final, "SDQ_total_difficulties_quartiles", 1, 4)

# Function to create plots
create_plot <- function(data, var_name, low_label, high_label, y_label, trajectory_type) {
  avg_trajectories <- data %>%
    group_by(!!sym(var_name), trajectory_wave) %>%
    summarize(
      avg_value = mean(!!sym(trajectory_type)),
      .groups = "drop"
    )
  
  ggplot() +
    geom_line(data = data, 
              aes(x = trajectory_wave, y = !!sym(trajectory_type), group = household_id, color = factor(!!sym(var_name))),
              alpha = 0.2) +
    geom_line(data = avg_trajectories, 
              aes(x = trajectory_wave, y = avg_value, group = !!sym(var_name), color = factor(!!sym(var_name))),
              size = 1.5) +
    geom_point(data = avg_trajectories, 
               aes(x = trajectory_wave, y = avg_value, color = factor(!!sym(var_name))),
               size = 3) +
    scale_color_viridis_d(name = y_label, labels = c(low_label, high_label)) +
    scale_x_continuous(breaks = 1:5) +
    labs(x = "Wave",
         y = y_label) +
    theme_minimal() +
    theme(legend.position = "right")
}

# Create linear plots
linear_plots <- list(
  income = create_plot(income_trajectories, "income_quintile", "Lowest Income", "Highest Income", "Income Quintile", "linear_value"),
  stress = create_plot(stress_trajectories, "stress_quartiles", "Lowest Stress", "Highest Stress", "Parental Stress", "linear_value"),
  edu = create_plot(edu_trajectories, "edu_quartiles", "Lowest Performance", "Highest Performance", "Educational Performance", "linear_value"),
  sdq = create_plot(sdq_trajectories, "SDQ_total_difficulties_quartiles", "Lowest Difficulties", "Highest Difficulties", "Child Behavioral Issues", "linear_value")
)

# Create quadratic plots
quadratic_plots <- list(
  income = create_plot(income_trajectories, "income_quintile", "Lowest Income", "Highest Income", "Income Quintile", "quadratic_value"),
  stress = create_plot(stress_trajectories, "stress_quartiles", "Lowest Stress", "Highest Stress", "Parental Stress", "quadratic_value"),
  edu = create_plot(edu_trajectories, "edu_quartiles", "Lowest Activity", "Highest Acivity", "Educational Activity", "quadratic_value"),
  sdq = create_plot(sdq_trajectories, "SDQ_total_difficulties_quartiles", "Lowest Difficulties", "Highest Difficulties", "Child Behavioral Issues", "quadratic_value")
)

# Combine linear plots
linear_combined <- (linear_plots$income + linear_plots$stress) / (linear_plots$edu + linear_plots$sdq) +
  plot_annotation(
    title = "Linear Trajectories of Various Factors",
    subtitle = "Lowest and Highest Quartiles/Quintiles",
    theme = theme(plot.title = element_text(hjust = 0.5),
                  plot.subtitle = element_text(hjust = 0.5))
  )

# Combine quadratic plots
quadratic_combined <- (quadratic_plots$income + quadratic_plots$stress) / (quadratic_plots$edu + quadratic_plots$sdq) +
  plot_annotation(
    title = "Quadratic Trajectories of Various Factors",
    subtitle = "Lowest and Highest Quartiles/Quintiles",
    theme = theme(plot.title = element_text(hjust = 0.5),
                  plot.subtitle = element_text(hjust = 0.5))
  )

# Display the plots
print(linear_combined)
print(quadratic_combined)

# Create the directory if it doesn't exist
dir.create("thesis_plots_robust", showWarnings = FALSE)

# Save the linear plot
ggsave("thesis_plots_robust/linear_trajectories_sample_1.pdf", plot = linear_combined, width = 12, height = 8)
# Save the quadratic plot
ggsave("thesis_plots_robust/quadratic_trajectories_sample_2.pdf", plot = quadratic_combined, width = 12, height = 8)

##################################################################################
#test

# Function to extract fixed effects and random effects for quadratic models
extract_quadratic_model_info <- function(model) {
  fe <- fixef(model)
  re <- ranef(model)$household_id
  data.frame(
    intercept = fe[1],
    linear_slope = fe[2],
    quadratic_slope = fe[3],
    re_intercept_sd = sd(re[,1]),
    re_linear_slope_sd = sd(re[,2]),
    re_quadratic_slope_sd = sd(re[,3]),
    intercept_linear_slope_cor = cor(re[,1], re[,2]),
    intercept_quadratic_slope_cor = cor(re[,1], re[,3]),
    linear_quadratic_slope_cor = cor(re[,2], re[,3])
  )
}
# Extract information from all models
quadratic_model_info <- map_dfr(quadratic_growth_models, extract_quadratic_model_info, .id = "variable")
# Print model information
print(quadratic_model_info)

# Create a named vector for the new labels
intuitive_labels <- c(
  household_size = "Household Size",
  income_quintile = "Income Quintile",
  SDQ_total_difficulties_quartiles = "Child Behavioral Issues Quartile",
  stress_quartiles = "Parental Stress Quartile",
  creative_quartiles = "Creative Activities Quartile",
  parenting_hostility_quartiles = "Hostile Parenting-Style Quartile",
  parenting_consistency_quartiles = "Consistent Parenting-Style Quartile",
  positive_conflict_quartiles = "Parent-Child Closeness Quartile",
  edu_quartiles = "Educational Activity Quartile",
  family_social_class = "Family Social Class",
  mother_education = "Mother's Education Level"
)

# Prepare the data
plot_data <- quadratic_model_info %>%
  select(variable, intercept, linear_slope, quadratic_slope) %>%
  pivot_longer(cols = c(intercept, linear_slope, quadratic_slope), 
               names_to = "parameter", 
               values_to = "value") %>%
  mutate(
    parameter = factor(parameter, levels = c("intercept", "linear_slope", "quadratic_slope"),
                       labels = c("Intercept", "Linear Slope", "Quadratic Slope")),
    description = intuitive_labels[variable],
    variable = factor(variable, levels = rev(unique(variable)))  # Reverse factor levels for bottom-to-top ordering
  )

# Create the improved plot
fixed_effects <- ggplot(plot_data, aes(x = variable, y = value, fill = parameter)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9), width = 0.8) +
  coord_flip() +
  scale_fill_manual(values = c("Intercept" = "#8884d8", 
                               "Linear Slope" = "#82ca9d", 
                               "Quadratic Slope" = "#ffc658")) +
  scale_y_continuous(limits = c(-0.5, 4.5), breaks = seq(-0.5, 4.5, 0.5)) +
  scale_x_discrete(labels = intuitive_labels) +
  labs(title = "Fixed Effects: Intercepts, Linear and Quadratic Slopes",
       x = "", y = "Value", fill = "Parameter") +
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 9, face = "bold"),
    axis.text.y.left = element_text(hjust = 1),
    legend.position = "bottom",
    plot.title = element_text(hjust = 0.5, face = "bold"),
    panel.grid.major.y = element_blank()
  ) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black")

# Save the fixed effects plot
ggsave("thesis_plots_robust/fixed_effects_3.pdf", plot = fixed_effects, width = 12, height = 8)

########################################################################################

# Function to summarize combined effects
summarize_combined_effects <- function(combined_effects) {
  combined_effects %>%
    summarize(
      across(c(intercept, linear_slope, quadratic_slope),
             list(
               mean = mean,
               sd = sd,
               min = min,
               max = max
             ), .names = "{.col}_{.fn}")
    )
}

# Apply the summary function to all variables
combined_effects_summary <- map_dfr(combined_effects, summarize_combined_effects, .id = "variable")

# Print the summary
print(combined_effects_summary)

# Visualize the distribution of combined effects
combined_effects_long <- combined_effects_summary %>%
  pivot_longer(cols = -variable, 
               names_to = c("parameter", "statistic"), 
               names_sep = "_", 
               values_to = "value")
combined_effects_long


# Create the plot
combined_effects_intercepts <- ggplot(combined_effects_long %>% filter(statistic %in% c("mean", "sd"), parameter == "intercept"), 
       aes(x = variable, y = value, fill = statistic)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9), width = 0.8) +
  coord_flip() +
  scale_fill_manual(values = c("mean" = "#8884d8", "sd" = "#82ca9d"),
                    labels = c("Mean", "S.D")) +
  scale_x_discrete(labels = intuitive_labels) +
  labs(title = "Combined Effects: Means and Standard Deviations",
       subtitle = "Intercepts",
       x = "", y = "Value", fill = "Statistic") +
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 9, face = "bold"),
    axis.text.y.left = element_text(hjust = 1),
    legend.position = "bottom",
    plot.title = element_text(hjust = 0.5, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, face = "bold", size = 11),
    panel.grid.major.y = element_blank()
  ) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black")

# Save the plot
ggsave("thesis_plots_robust/combined_effects_intercepts_4.pdf", plot = combined_effects_intercepts, width = 12, height = 8)



##################################################################################################
# Function to generate linear trajectory points
generate_linear_trajectory <- function(intercept, slope, start_wave = 1, end_wave = 5) {
  tibble(
    wave = start_wave:end_wave,
    value = intercept + slope * (wave - start_wave)
  )
}

# Function to generate quadratic trajectory points
generate_quadratic_trajectory <- function(intercept, linear_slope, quadratic_slope, start_wave = 1, end_wave = 5) {
  tibble(
    wave = start_wave:end_wave,
    value = intercept + linear_slope * (wave - start_wave) + quadratic_slope * (wave - start_wave)^2
  )
}

# Generate trajectory data for linear models
linear_trajectory_data <- quadratic_model_info %>%
  rowwise() %>%
  mutate(
    trajectory = list(generate_linear_trajectory(intercept, linear_slope, 
                                                 start_wave = if_else(variable %in% c("creative_quartiles", "parenting_hostility_quartiles", 
                                                                                      "parenting_consistency_quartiles", "positive_conflict_quartiles", 
                                                                                      "edu_quartiles"), 2, 1))),
    variable = factor(variable, levels = variable),  # Preserve original order
    model = "Linear"
  ) %>%
  unnest(trajectory)

# Generate trajectory data for quadratic models
quadratic_trajectory_data <- quadratic_model_info %>%
  rowwise() %>%
  mutate(
    trajectory = list(generate_quadratic_trajectory(intercept, linear_slope, quadratic_slope, 
                                                    start_wave = if_else(variable %in% c("creative_quartiles", "parenting_hostility_quartiles", 
                                                                                         "parenting_consistency_quartiles", "positive_conflict_quartiles", 
                                                                                         "edu_quartiles"), 2, 1))),
    variable = factor(variable, levels = variable),  # Preserve original order
    model = "Quadratic"
  ) %>%
  unnest(trajectory)

# Combine linear and quadratic data
combined_trajectory_data <- bind_rows(linear_trajectory_data, quadratic_trajectory_data)


# Create the raw trajectory plots
plot_linear_raw <- ggplot(filter(combined_trajectory_data, model == "Linear"), 
                          aes(x = wave, y = value, color = variable, group = variable)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1)) +
  scale_color_viridis_d(labels = intuitive_labels) +
  labs(title = "Linear Model",
       x = "Wave",
       y = "Value",
       color = "Variable") +
  theme_minimal() +
  theme(legend.position = "none")

plot_quadratic_raw <- ggplot(filter(combined_trajectory_data, model == "Quadratic"), 
                             aes(x = wave, y = value, color = variable, group = variable)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1)) +
  scale_color_viridis_d(labels = intuitive_labels) +
  labs(title = "Quadratic Model",
       x = "Wave",
       y = "Value",
       color = "Variable") +
  theme_minimal() +
  theme(legend.position = "right")

# Combine the raw trajectory plots
combined_raw_plot <- plot_linear_raw + plot_quadratic_raw +
  plot_layout(guides = "collect") +
  plot_annotation(title = "Raw Trajectories: Linear vs Quadratic Models")

# Print the combined raw trajectory plot
print(combined_raw_plot)

# Save the plot
ggsave("thesis_plots_robust/combined_raw_trajectories_plot_5.pdf", plot = combined_raw_plot, width = 12, height = 8)


######################

# Function to generate normalized linear trajectory points
generate_normalized_linear_trajectory <- function(intercept, slope, start_wave = 1, end_wave = 5) {
  trajectory <- tibble(
    wave = start_wave:end_wave,
    value = intercept + slope * (wave - start_wave)
  )
  trajectory %>%
    mutate(normalized_value = (value - first(value)) / first(value) * 100)
}

# Function to generate normalized quadratic trajectory points
generate_normalized_quadratic_trajectory <- function(intercept, linear_slope, quadratic_slope, start_wave = 1, end_wave = 5) {
  trajectory <- tibble(
    wave = start_wave:end_wave,
    value = intercept + linear_slope * (wave - start_wave) + quadratic_slope * (wave - start_wave)^2
  )
  trajectory %>%
    mutate(normalized_value = (value - first(value)) / first(value) * 100)
}

# Generate normalized trajectory data for linear models
normalized_linear_trajectory_data <- quadratic_model_info %>%
  rowwise() %>%
  mutate(
    trajectory = list(generate_normalized_linear_trajectory(intercept, linear_slope, 
                                                            start_wave = if_else(variable %in% c("creative_quartiles", "parenting_hostility_quartiles", 
                                                                                                 "parenting_consistency_quartiles", "positive_conflict_quartiles", 
                                                                                                 "edu_quartiles"), 2, 1))),
    variable = factor(variable, levels = variable),  # Preserve original order
    model = "Linear"
  ) %>%
  unnest(trajectory)

# Generate normalized trajectory data for quadratic models
normalized_quadratic_trajectory_data <- quadratic_model_info %>%
  rowwise() %>%
  mutate(
    trajectory = list(generate_normalized_quadratic_trajectory(intercept, linear_slope, quadratic_slope, 
                                                               start_wave = if_else(variable %in% c("creative_quartiles", "parenting_hostility_quartiles", 
                                                                                                    "parenting_consistency_quartiles", "positive_conflict_quartiles", 
                                                                                                    "edu_quartiles"), 2, 1))),
    variable = factor(variable, levels = variable),  # Preserve original order
    model = "Quadratic"
  ) %>%
  unnest(trajectory)

# Combine normalized linear and quadratic data
combined_normalized_trajectory_data <- bind_rows(normalized_linear_trajectory_data, normalized_quadratic_trajectory_data)

# Create the normalized trajectory plots
plot_linear_normalized <- ggplot(filter(combined_normalized_trajectory_data, model == "Linear"), 
                                 aes(x = wave, y = normalized_value, color = variable, group = variable)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  scale_y_continuous(labels = scales::percent_format(scale = 1)) +
  scale_color_viridis_d(labels = intuitive_labels) +
  labs(title = "Linear Model",
       x = "Wave",
       y = "Percent Change from Initial Value",
       color = "Variable") +
  theme_minimal() +
  theme(legend.position = "none")

plot_quadratic_normalized <- ggplot(filter(combined_normalized_trajectory_data, model == "Quadratic"), 
                                    aes(x = wave, y = normalized_value, color = variable, group = variable)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  scale_y_continuous(labels = scales::percent_format(scale = 1)) +
  scale_color_viridis_d(labels = intuitive_labels) +
  labs(title = "Quadratic Model",
       x = "Wave",
       y = "Percent Change from Initial Value",
       color = "Variable") +
  theme_minimal() +
  theme(legend.position = "right")

# Combine the normalized trajectory plots
combined_normalized_plot <- plot_linear_normalized + plot_quadratic_normalized +
  plot_layout(guides = "collect") +
  plot_annotation(title = "Normalised Trajectories: Linear vs Quadratic Models",
                  subtitle = "Percent change from initial value")

# Print the combined normalized trajectory plot
print(combined_normalized_plot)


# Save the plot
ggsave("thesis_plots_robust/combined_normalized_plot_6.pdf",plot = combined_normalized_plot , width = 12, height = 8)



#########################################################################
# addint "pct correct" to use aswell besides the logit scores

#wave5


df_final <- df_final %>%
  left_join(wave5 %>% select(id, b5_readpct), by = c("household_id" = "id"))
# Rename the column to pct_correct (no NA)
df_final <- df_final %>%
  rename(pct_correct = b5_readpct)
# Remove any labels from the column
var_label(df_final$pct_correct) <- NULL
# Convert the column to numeric
df_final$pct_correct <- as.numeric(df_final$pct_correct)
str(df_final)


####################################################################
#using logit

time_invariant_vars <- c("pregnancy_awareness", "birth_weight_quartile", "breastfeeding_status", 
                         "ever_smoked", "smoking_in_household", "alcohol_frequency", 
                         "heavy_drinking", "grandparent_contact", "fussy_quartiles", 
                         "unadapt_quartiles", "dull_quartiles", "unpredict_quartiles",
                         "school_DEIS_status", "school_size", "PT_meeting_attendance")


# Prepare the data (only time_invariant + drumscore + the time varying growth models) #excluding has_partner and family_social_class
model_data <- df_final %>%
  select(drum_score, 
         all_of(c(time_invariant_vars)),
         ends_with("_intercept"), 
         ends_with("_slope")) %>%
  na.omit()

# Convert factor variables to numeric or dummy variables
model_data <- model_data %>%
  mutate(
    # Binary factors to numeric (0/1)
    pregnancy_awareness = as.numeric(pregnancy_awareness == "planned"),
    # 1 = planned, 0 = unplanned
    
    breastfeeding_status = as.numeric(breastfeeding_status == "Ever breastfed"),
    # 1 = Ever breastfed, 0 = Never breastfed
    
    ever_smoked = as.numeric(ever_smoked == "Yes"),
    # 0 = No, 1 = Yes
    
    smoking_in_household = as.numeric(smoking_in_household) - 1,
    # 0 = No, 1 = Yes
    
    heavy_drinking = as.numeric(heavy_drinking == "Yes"),
    # 0 = No, 1 = Yes
    
    grandparent_contact = as.numeric(grandparent_contact == "Yes"),
    # 0 = No, 1 = Yes
    
    PT_meeting_attendance = as.numeric(PT_meeting_attendance == "High"),
    # 1 = High, 0 = Low
    
    # Factors with more than two levels to dummy variables
    school_DEIS_status = as.factor(school_DEIS_status),
    school_size = as.factor(school_size)
  )

#########################################
# Create dummy variables for factors with more than two levels
# For school_DEIS_status, use 'Non-DEIS' as the reference category
# For school_size, use 'Medium' as the reference category
dummy_vars <- dummyVars(" ~ school_DEIS_status + school_size", 
                        data = model_data, 
                        levelsOnly = TRUE,
                        fullRank = TRUE)

dummy_data <- predict(dummy_vars, newdata = model_data)
# Rename columns to be more descriptive
colnames(dummy_data) <- c(
  "school_DEIS_status_DEIS",     # 1 if DEIS, 0 otherwise (compared to Non-DEIS)
  "school_DEIS_status_Unknown",  # 1 if Unknown, 0 otherwise (compared to Non-DEIS)
  "school_size_Large",           # 1 if Large, 0 otherwise (compared to Medium)
  "school_size_Small"            # 1 if Small, 0 otherwise (compared to Medium)
)
# Combine the original data with the dummy variables
model_data <- cbind(model_data, dummy_data)
# Remove the original factor columns
model_data <- model_data %>%
  select(-school_DEIS_status, -school_size)
str(model_data)



#################################
#model test

# Function to create dataset with only specified slope type and non-slope variables
create_slope_dataset <- function(data, slope_type) {
  # Ensure input data is a data frame
  data <- as.data.frame(data)
  
  # Select columns that don't contain "linear" or "quadratic", plus the outcome variable
  non_slope_cols <- c("drum_score", names(data)[!grepl("linear|quadratic", names(data))])
  
  # Select columns that contain the specified slope type
  slope_cols <- names(data)[grepl(slope_type, names(data))]
  
  # Combine columns and create a new data frame
  result_data <- data[, unique(c(non_slope_cols, slope_cols))]
  
  # Remove any columns with all NA values
  result_data <- result_data[, colSums(is.na(result_data)) < nrow(result_data)]
  
  # Ensure all columns are numeric or factor
  result_data <- as.data.frame(lapply(result_data, function(x) {
    if(is.character(x)) as.factor(x) else x
  }))
  
  return(result_data)
}


# Create separate datasets for linear and quadratic slopes
linear_data <- create_slope_dataset(model_data, "linear")
quadratic_data <- create_slope_dataset(model_data, "quadratic")

# Create the formula for all models
linear_formula <- as.formula(paste("drum_score ~", paste(names(linear_data)[-1], collapse = " + ")))

# 1. Initial Linear Model
linear_initial_model <- lm(linear_formula, data = linear_data)
print(summary(linear_initial_model))

# 2. Stepwise Regression
linear_stepwise_model <- step(linear_initial_model, direction = "both", trace = 0)
print(summary(linear_stepwise_model))

# Prepare matrix for glmnet models
linear_x <- model.matrix(linear_formula, linear_data)[,-1]
linear_y <- linear_data$drum_score

# 3. Ridge Regression
linear_cv_ridge <- cv.glmnet(linear_x, linear_y, alpha = 0)
linear_ridge_model <- glmnet(linear_x, linear_y, alpha = 0, lambda = linear_cv_ridge$lambda.min)
print(coef(linear_ridge_model))

# 4. LASSO Regression
linear_cv_lasso <- cv.glmnet(linear_x, linear_y, alpha = 1)
linear_lasso_model <- glmnet(linear_x, linear_y, alpha = 1, lambda = linear_cv_lasso$lambda.min)
print(coef(linear_lasso_model))

# 5. Elastic Net
linear_cv_elastic <- cv.glmnet(linear_x, linear_y, alpha = 0.5)
linear_elastic_model <- glmnet(linear_x, linear_y, alpha = 0.5, lambda = linear_cv_elastic$lambda.min)
print(coef(linear_elastic_model))

# 6. Generalized Additive Model (GAM)
linear_gam_model <- gam(drum_score ~ s(household_size_intercept) + s(income_quintile_intercept) + 
                          s(SDQ_total_difficulties_quartiles_intercept) + s(creative_quartiles_intercept) + 
                          s(parenting_consistency_quartiles_intercept) + s(edu_quartiles_intercept) + 
                          s(family_social_class_intercept) + s(mother_education_intercept) + 
                          s(household_size_linear_slope) + s(SDQ_total_difficulties_quartiles_linear_slope) + 
                          s(parenting_consistency_quartiles_linear_slope) + s(edu_quartiles_linear_slope) + 
                          s(family_social_class_linear_slope) + 
                          breastfeeding_status + alcohol_frequency + heavy_drinking + unpredict_quartiles,
                        data = linear_data)
print(summary(linear_gam_model))

# 7. Cross-validated Linear Regression
linear_ctrl <- trainControl(method = "cv", number = 5)
linear_cv_lm <- train(linear_formula, data = linear_data, method = "lm", trControl = linear_ctrl)
print(linear_cv_lm)

# Extract importances
linear_initial_importance <- abs(summary(linear_initial_model)$coefficients[, "t value"])[-1]
linear_stepwise_importance <- abs(summary(linear_stepwise_model)$coefficients[, "t value"])[-1]
linear_ridge_importance <- abs(as.vector(coef(linear_ridge_model)))[-1]
names(linear_ridge_importance) <- rownames(coef(linear_ridge_model))[-1]
linear_lasso_importance <- abs(as.vector(coef(linear_lasso_model)))[-1]
names(linear_lasso_importance) <- rownames(coef(linear_lasso_model))[-1]
linear_elastic_importance <- abs(as.vector(coef(linear_elastic_model)))[-1]
names(linear_elastic_importance) <- rownames(coef(linear_elastic_model))[-1]
linear_gam_importance <- summary(linear_gam_model)$s.table[, "F"]
linear_cv_lm_importance <- varImp(linear_cv_lm)$importance[, 1]

# Assign names to CV_LM importance values
linear_cv_lm_names <- names(linear_data)[-which(names(linear_data) == "drum_score")]
names(linear_cv_lm_importance) <- linear_cv_lm_names

# Combine all importances
linear_all_importances <- list(
  Initial = linear_initial_importance,
  Stepwise = linear_stepwise_importance,
  Ridge = linear_ridge_importance,
  LASSO = linear_lasso_importance,
  ElasticNet = linear_elastic_importance,
  GAM = linear_gam_importance,
  CV_LM = linear_cv_lm_importance
)

# Print all importances to verify
print("Variable Importances for all linear models:")
print(linear_all_importances)

# Function to get top N variables
get_top_n_vars <- function(importance_vector, n = 10, top = TRUE) {
  if(top) {
    sorted_importance <- sort(importance_vector, decreasing = TRUE)
  } else {
    sorted_importance <- sort(importance_vector, decreasing = FALSE)
  }
  result <- names(sorted_importance)[1:min(n, length(sorted_importance))]
  if(length(result) < n) {
    result <- c(result, rep(NA, n - length(result)))
  }
  return(result)
}

# Get top 10 variables for each model
linear_top_vars_list <- lapply(linear_all_importances, get_top_n_vars, n = 10)
linear_top_vars_df <- do.call(cbind, lapply(linear_top_vars_list, function(x) {
  data.frame(x = x, stringsAsFactors = FALSE)
}))
colnames(linear_top_vars_df) <- names(linear_all_importances)
print("Top 10 variables for each linear model:")
print(linear_top_vars_df)

# Get bottom 10 variables for each model
linear_bottom_vars_list <- lapply(linear_all_importances, get_top_n_vars, n = 10, top = FALSE)
linear_bottom_vars_df <- do.call(cbind, lapply(linear_bottom_vars_list, function(x) {
  data.frame(x = x, stringsAsFactors = FALSE)
}))
colnames(linear_bottom_vars_df) <- names(linear_all_importances)
print("Bottom 10 variables for each linear model:")
print(linear_bottom_vars_df)

# Calculate performance metrics
calculate_mse <- function(model, data) {
  residuals <- residuals(model)
  mean(residuals^2)
}

calculate_rmse <- function(model, data) {
  sqrt(calculate_mse(model, data))
}

linear_performance_df <- data.frame(
  Model = c("Initial Linear", "Stepwise", "Ridge", "LASSO", "Elastic Net", "GAM", "CV Linear Regression"),
  R_squared = c(
    summary(linear_initial_model)$r.squared,
    summary(linear_stepwise_model)$r.squared,
    NA,  # Ridge
    NA,  # LASSO
    NA,  # Elastic Net
    summary(linear_gam_model)$r.sq,
    max(linear_cv_lm$results$Rsquared)
  ),
  Adj_R_squared = c(
    summary(linear_initial_model)$adj.r.squared,
    summary(linear_stepwise_model)$adj.r.squared,
    NA, NA, NA,  # Not applicable for regularized models
    NA,  # GAM doesn't provide adjusted R-squared
    NA  # Not applicable for cross-validated model
  ),
  MSE = c(
    calculate_mse(linear_initial_model, linear_data),
    calculate_mse(linear_stepwise_model, linear_data),
    min(linear_cv_ridge$cvm),
    min(linear_cv_lasso$cvm),
    min(linear_cv_elastic$cvm),
    calculate_mse(linear_gam_model, linear_data),
    min(linear_cv_lm$results$RMSE^2)
  ),
  RMSE = NA,  # We'll calculate this from MSE
  AIC = c(
    AIC(linear_initial_model),
    AIC(linear_stepwise_model),
    NA, NA, NA,  # Not applicable for regularized models
    AIC(linear_gam_model),
    NA  # Not applicable for cross-validated model
  ),
  BIC = c(
    BIC(linear_initial_model),
    BIC(linear_stepwise_model),
    NA, NA, NA,  # Not applicable for regularized models
    NA,  # GAM doesn't provide BIC
    NA  # Not applicable for cross-validated model
  ),
  stringsAsFactors = FALSE
)

# Calculate RMSE from MSE
linear_performance_df$RMSE <- sqrt(linear_performance_df$MSE)

# Add number of predictors
linear_performance_df$Num_Predictors <- c(
  length(coef(linear_initial_model)) - 1,
  length(coef(linear_stepwise_model)) - 1,
  sum(coef(linear_ridge_model) != 0) - 1,
  sum(coef(linear_lasso_model) != 0) - 1,
  sum(coef(linear_elastic_model) != 0) - 1,
  length(summary(linear_gam_model)$p.table) + length(summary(linear_gam_model)$s.table),
  length(coef(linear_cv_lm$finalModel)) - 1
)

# Calculate R-squared for regularized models
linear_y_pred_ridge <- predict(linear_ridge_model, newx = linear_x)
linear_y_pred_lasso <- predict(linear_lasso_model, newx = linear_x)
linear_y_pred_elastic <- predict(linear_elastic_model, newx = linear_x)

linear_SST <- sum((linear_y - mean(linear_y))^2)
linear_SSE_ridge <- sum((linear_y - linear_y_pred_ridge)^2)
linear_SSE_lasso <- sum((linear_y - linear_y_pred_lasso)^2)
linear_SSE_elastic <- sum((linear_y - linear_y_pred_elastic)^2)

linear_performance_df$R_squared[linear_performance_df$Model == "Ridge"] <- 1 - linear_SSE_ridge/linear_SST
linear_performance_df$R_squared[linear_performance_df$Model == "LASSO"] <- 1 - linear_SSE_lasso/linear_SST
linear_performance_df$R_squared[linear_performance_df$Model == "Elastic Net"] <- 1 - linear_SSE_elastic/linear_SST

# Print the performance dataframe
print("Performance metrics for all linear models:")
print(linear_performance_df)




# =============================
# Analysis for Quadratic Slopes
# =============================

# Create the formula for all models
quadratic_formula <- as.formula(paste("drum_score ~", paste(names(quadratic_data)[-1], collapse = " + ")))

# 1. Initial Linear Model
quadratic_initial_model <- lm(quadratic_formula, data = quadratic_data)
print(summary(quadratic_initial_model))

# 2. Stepwise Regression
quadratic_stepwise_model <- step(quadratic_initial_model, direction = "both", trace = 0)
print(summary(quadratic_stepwise_model))

# Prepare matrix for glmnet models
quadratic_x <- model.matrix(quadratic_formula, quadratic_data)[,-1]
quadratic_y <- quadratic_data$drum_score

# 3. Ridge Regression
quadratic_cv_ridge <- cv.glmnet(quadratic_x, quadratic_y, alpha = 0)
quadratic_ridge_model <- glmnet(quadratic_x, quadratic_y, alpha = 0, lambda = quadratic_cv_ridge$lambda.min)
print(coef(quadratic_ridge_model))

# 4. LASSO Regression
quadratic_cv_lasso <- cv.glmnet(quadratic_x, quadratic_y, alpha = 1)
quadratic_lasso_model <- glmnet(quadratic_x, quadratic_y, alpha = 1, lambda = quadratic_cv_lasso$lambda.min)
print(coef(quadratic_lasso_model))

# 5. Elastic Net
quadratic_cv_elastic <- cv.glmnet(quadratic_x, quadratic_y, alpha = 0.5)
quadratic_elastic_model <- glmnet(quadratic_x, quadratic_y, alpha = 0.5, lambda = quadratic_cv_elastic$lambda.min)
print(coef(quadratic_elastic_model))

# 6. Generalized Additive Model (GAM)
quadratic_gam_model <- gam(drum_score ~ s(household_size_intercept) + s(income_quintile_intercept) + 
                             s(SDQ_total_difficulties_quartiles_intercept) + s(creative_quartiles_intercept) + 
                             s(parenting_consistency_quartiles_intercept) + s(edu_quartiles_intercept) + 
                             s(family_social_class_intercept) + s(mother_education_intercept) + 
                             s(household_size_quadratic_slope) + s(SDQ_total_difficulties_quartiles_quadratic_slope) + 
                             s(parenting_consistency_quartiles_quadratic_slope) + s(edu_quartiles_quadratic_slope) + 
                             s(family_social_class_quadratic_slope) + 
                             breastfeeding_status + alcohol_frequency + heavy_drinking + unpredict_quartiles,
                           data = quadratic_data)
print(summary(quadratic_gam_model))

# 7. Cross-validated Linear Regression
quadratic_ctrl <- trainControl(method = "cv", number = 5)
quadratic_cv_lm <- train(quadratic_formula, data = quadratic_data, method = "lm", trControl = quadratic_ctrl)
print(quadratic_cv_lm)

# Extract importances
quadratic_initial_importance <- abs(summary(quadratic_initial_model)$coefficients[, "t value"])[-1]
quadratic_stepwise_importance <- abs(summary(quadratic_stepwise_model)$coefficients[, "t value"])[-1]
quadratic_ridge_importance <- abs(as.vector(coef(quadratic_ridge_model)))[-1]
names(quadratic_ridge_importance) <- rownames(coef(quadratic_ridge_model))[-1]
quadratic_lasso_importance <- abs(as.vector(coef(quadratic_lasso_model)))[-1]
names(quadratic_lasso_importance) <- rownames(coef(quadratic_lasso_model))[-1]
quadratic_elastic_importance <- abs(as.vector(coef(quadratic_elastic_model)))[-1]
names(quadratic_elastic_importance) <- rownames(coef(quadratic_elastic_model))[-1]
quadratic_gam_importance <- summary(quadratic_gam_model)$s.table[, "F"]
quadratic_cv_lm_importance <- varImp(quadratic_cv_lm)$importance[, 1]

# Assign names to CV_LM importance
# Assign names to CV_LM importance values
quadratic_cv_lm_names <- names(quadratic_data)[-which(names(quadratic_data) == "drum_score")]
names(quadratic_cv_lm_importance) <- quadratic_cv_lm_names

# Combine all importances
quadratic_all_importances <- list(
  Initial = quadratic_initial_importance,
  Stepwise = quadratic_stepwise_importance,
  Ridge = quadratic_ridge_importance,
  LASSO = quadratic_lasso_importance,
  ElasticNet = quadratic_elastic_importance,
  GAM = quadratic_gam_importance,
  CV_LM = quadratic_cv_lm_importance
)

# Print all importances to verify
print("Variable Importances for all quadratic models:")
print(quadratic_all_importances)

# Get top 10 variables for each model
quadratic_top_vars_list <- lapply(quadratic_all_importances, get_top_n_vars, n = 10)
quadratic_top_vars_df <- do.call(cbind, lapply(quadratic_top_vars_list, function(x) {
  data.frame(x = x, stringsAsFactors = FALSE)
}))
colnames(quadratic_top_vars_df) <- names(quadratic_all_importances)
print("Top 10 variables for each quadratic model:")
print(quadratic_top_vars_df)

# Get bottom 10 variables for each model
quadratic_bottom_vars_list <- lapply(quadratic_all_importances, get_top_n_vars, n = 10, top = FALSE)
quadratic_bottom_vars_df <- do.call(cbind, lapply(quadratic_bottom_vars_list, function(x) {
  data.frame(x = x, stringsAsFactors = FALSE)
}))
colnames(quadratic_bottom_vars_df) <- names(quadratic_all_importances)
print("Bottom 10 variables for each quadratic model:")
print(quadratic_bottom_vars_df)

# Calculate performance metrics
quadratic_performance_df <- data.frame(
  Model = c("Initial Linear", "Stepwise", "Ridge", "LASSO", "Elastic Net", "GAM", "CV Linear Regression"),
  R_squared = c(
    summary(quadratic_initial_model)$r.squared,
    summary(quadratic_stepwise_model)$r.squared,
    NA,  # Ridge
    NA,  # LASSO
    NA,  # Elastic Net
    summary(quadratic_gam_model)$r.sq,
    max(quadratic_cv_lm$results$Rsquared)
  ),
  Adj_R_squared = c(
    summary(quadratic_initial_model)$adj.r.squared,
    summary(quadratic_stepwise_model)$adj.r.squared,
    NA, NA, NA,  # Not applicable for regularized models
    NA,  # GAM doesn't provide adjusted R-squared
    NA  # Not applicable for cross-validated model
  ),
  MSE = c(
    calculate_mse(quadratic_initial_model, quadratic_data),
    calculate_mse(quadratic_stepwise_model, quadratic_data),
    min(quadratic_cv_ridge$cvm),
    min(quadratic_cv_lasso$cvm),
    min(quadratic_cv_elastic$cvm),
    calculate_mse(quadratic_gam_model, quadratic_data),
    min(quadratic_cv_lm$results$RMSE^2)
  ),
  RMSE = NA,  # We'll calculate this from MSE
  AIC = c(
    AIC(quadratic_initial_model),
    AIC(quadratic_stepwise_model),
    NA, NA, NA,  # Not applicable for regularized models
    AIC(quadratic_gam_model),
    NA  # Not applicable for cross-validated model
  ),
  BIC = c(
    BIC(quadratic_initial_model),
    BIC(quadratic_stepwise_model),
    NA, NA, NA,  # Not applicable for regularized models
    NA,  # GAM doesn't provide BIC
    NA  # Not applicable for cross-validated model
  ),
  stringsAsFactors = FALSE
)

# Calculate RMSE from MSE
quadratic_performance_df$RMSE <- sqrt(quadratic_performance_df$MSE)

# Add number of predictors
quadratic_performance_df$Num_Predictors <- c(
  length(coef(quadratic_initial_model)) - 1,
  length(coef(quadratic_stepwise_model)) - 1,
  sum(coef(quadratic_ridge_model) != 0) - 1,
  sum(coef(quadratic_lasso_model) != 0) - 1,
  sum(coef(quadratic_elastic_model) != 0) - 1,
  length(summary(quadratic_gam_model)$p.table) + length(summary(quadratic_gam_model)$s.table),
  length(coef(quadratic_cv_lm$finalModel)) - 1
)

# Calculate R-squared for regularized models
quadratic_y_pred_ridge <- predict(quadratic_ridge_model, newx = quadratic_x)
quadratic_y_pred_lasso <- predict(quadratic_lasso_model, newx = quadratic_x)
quadratic_y_pred_elastic <- predict(quadratic_elastic_model, newx = quadratic_x)

quadratic_SST <- sum((quadratic_y - mean(quadratic_y))^2)
quadratic_SSE_ridge <- sum((quadratic_y - quadratic_y_pred_ridge)^2)
quadratic_SSE_lasso <- sum((quadratic_y - quadratic_y_pred_lasso)^2)
quadratic_SSE_elastic <- sum((quadratic_y - quadratic_y_pred_elastic)^2)

quadratic_performance_df$R_squared[quadratic_performance_df$Model == "Ridge"] <- 1 - quadratic_SSE_ridge/quadratic_SST
quadratic_performance_df$R_squared[quadratic_performance_df$Model == "LASSO"] <- 1 - quadratic_SSE_lasso/quadratic_SST
quadratic_performance_df$R_squared[quadratic_performance_df$Model == "Elastic Net"] <- 1 - quadratic_SSE_elastic/quadratic_SST

# Print the performance dataframe
print("Performance metrics for all quadratic models:")
print(quadratic_performance_df)

# Combine results from linear and quadratic analyses
combined_performance_df <- rbind(
  transform(linear_performance_df, Data_Type = "Linear"),
  transform(quadratic_performance_df, Data_Type = "Quadratic")
)

# Reorder columns for better readability
combined_performance_df <- combined_performance_df[, c("Data_Type", "Model", "R_squared", "Adj_R_squared", "MSE", "RMSE", "AIC", "BIC", "Num_Predictors")]

# Print the combined results
print("Combined performance metrics for linear and quadratic models:")
print(combined_performance_df)




#################################################################################




##############################################################
##############################################################
#################using pct_correct instead####################
##############################################################
##############################################################
##############################################################
# Prepare the data
model_data_pct <- df_final %>%
  select(pct_correct, 
         all_of(c(time_invariant_vars)),
         ends_with("_intercept"), 
         ends_with("_slope")) %>%
  na.omit()

str(model_data_pct)

# Convert factor variables to numeric or dummy variables
model_data_pct <- model_data_pct %>%
  mutate(
    # Binary factors to numeric (0/1)
    pregnancy_awareness = as.numeric(pregnancy_awareness == "planned"),
    # 1 = planned, 0 = unplanned
    
    breastfeeding_status = as.numeric(breastfeeding_status == "Ever breastfed"),
    # 1 = Ever breastfed, 0 = Never breastfed
    
    ever_smoked = as.numeric(ever_smoked == "Yes"),
    # 0 = No, 1 = Yes
    
    smoking_in_household = as.numeric(smoking_in_household) - 1,
    # 0 = No, 1 = Yes
    
    heavy_drinking = as.numeric(heavy_drinking == "Yes"),
    # 0 = No, 1 = Yes
    
    grandparent_contact = as.numeric(grandparent_contact == "Yes"),
    # 0 = No, 1 = Yes
    
    PT_meeting_attendance = as.numeric(PT_meeting_attendance == "High"),
    # 1 = High, 0 = Low
    
    # Factors with more than two levels to dummy variables
    school_DEIS_status = as.factor(school_DEIS_status),
    school_size = as.factor(school_size)
  )
# Create dummy variables for factors with more than two levels
# For school_DEIS_status, use 'Non-DEIS' as the reference category
# For school_size, use 'Medium' as the reference category
dummy_vars <- dummyVars(" ~ school_DEIS_status + school_size", 
                        data = model_data_pct, 
                        levelsOnly = TRUE,
                        fullRank = TRUE)

dummy_data_pct <- predict(dummy_vars, newdata = model_data_pct)
# Rename columns to be more descriptive
colnames(dummy_data_pct) <- c(
  "school_DEIS_status_DEIS",     # 1 if DEIS, 0 otherwise (compared to Non-DEIS)
  "school_DEIS_status_Unknown",  # 1 if Unknown, 0 otherwise (compared to Non-DEIS)
  "school_size_Large",           # 1 if Large, 0 otherwise (compared to Medium)
  "school_size_Small"            # 1 if Small, 0 otherwise (compared to Medium)
)
# Combine the original data with the dummy variables
model_data_pct <- cbind(model_data_pct, dummy_data_pct)
# Remove the original factor columns
model_data_pct <- model_data_pct %>%
  select(-school_DEIS_status, -school_size)
str(model_data_pct)

##################################################################
#binary outcome (> q2 = pass)
# Create binary outcome
q2 <- quantile(model_data_pct$pct_correct, 0.5)
model_data_pct$pass_fail <- ifelse(model_data_pct$pct_correct > q2, 1, 0)
table(model_data_pct$pass_fail)
# Create a new dataset without pct_correct
model_data_binary <- model_data_pct[, !(names(model_data_pct) %in% c("pct_correct"))]
##################################################################
# Convert pass_fail to factor if it's not already
model_data_binary$pass_fail <- as.factor(model_data_binary$pass_fail)
# Ensure the levels are correctly set
levels(model_data_binary$pass_fail) <- c("Fail", "Pass")

str(model_data_binary)

########################################
########### train/test split models########
########################################
# Function to create dataset with only specified slope type and non-slope variables
create_slope_dataset <- function(data, slope_type) {
  # Ensure input data is a data frame
  data <- as.data.frame(data)
  
  # Select columns that don't contain "linear" or "quadratic", plus the outcome variable
  non_slope_cols <- c("pass_fail", names(data)[!grepl("linear|quadratic", names(data))])
  
  # Select columns that contain the specified slope type
  slope_cols <- names(data)[grepl(slope_type, names(data))]
  
  # Combine columns and create a new data frame
  result_data <- data[, unique(c(non_slope_cols, slope_cols))]
  
  # Remove any columns with all NA values
  result_data <- result_data[, colSums(is.na(result_data)) < nrow(result_data)]
  
  # Ensure all columns are numeric or factor
  result_data <- as.data.frame(lapply(result_data, function(x) {
    if(is.character(x)) as.factor(x) else x
  }))
  
  return(result_data)
}


linear_data <- create_slope_dataset(model_data_binary, "linear")
quadratic_data <- create_slope_dataset(model_data_binary, "quadratic")

str(linear_data)


####################################################################################
# LINEAR
####################################################################################


# Data preparation
linear_data <- create_slope_dataset(model_data_binary, "linear")
set.seed(42)
X <- linear_data %>% select(-pass_fail)
y <- factor(linear_data$pass_fail, levels = c("Fail", "Pass"))

# Create train+validation and test sets
train_val_index <- createDataPartition(y, p = 0.8, list = FALSE)
X_train_val <- X[train_val_index, ]
y_train_val <- y[train_val_index]
X_test <- X[-train_val_index, ]
y_test <- y[-train_val_index]

# Function to calculate evaluation metrics
calculate_metrics <- function(predictions, actual, probs) {
  cm <- confusionMatrix(predictions, actual)
  auc <- roc(actual, probs)$auc
  c(cm$overall["Accuracy"], cm$byClass[c("Precision", "Recall", "F1")], AUC = auc)
}

# Train and evaluate models
train_and_evaluate <- function(method, X_train, y_train, X_test, y_test, tuneGrid = NULL) {
  set.seed(42)
  
  model <- train(x = X_train, y = y_train, 
                 method = method,
                 trControl = trainControl(method = "cv", number = 5),
                 tuneGrid = tuneGrid)
  
  train_pred <- predict(model, X_train)
  train_probs <- predict(model, X_train, type = "prob")$Pass
  train_metrics <- calculate_metrics(train_pred, y_train, train_probs)
  
  test_pred <- predict(model, X_test)
  test_probs <- predict(model, X_test, type = "prob")$Pass
  test_metrics <- calculate_metrics(test_pred, y_test, test_probs)
  
  list(model = model, 
       train = list(metrics = train_metrics, predictions = train_pred, probabilities = train_probs),
       test = list(metrics = test_metrics, predictions = test_pred, probabilities = test_probs))
}

# Define models and their parameters
models <- list(
  "Logistic Regression" = list(
    method = "glmnet",
    tuneGrid = expand.grid(
      alpha = c(0, 0.5, 1),
      lambda = 10^seq(-2, 0, length = 3)
    )
  ),
  "Random Forest" = list(
    method = "rf",
    tuneGrid = expand.grid(
      mtry = c(5, 10, 15)
    )
  ),
  "XGBoost" = list(
    method = "xgbTree", 
    tuneGrid = expand.grid(
      nrounds = c(50, 100),
      max_depth = c(3, 6),
      eta = c(0.1, 0.3),
      gamma = c(0, 0.1),
      colsample_bytree = c(0.8, 1),
      min_child_weight = c(1, 3),
      subsample = c(0.8, 1)
    )
  ),
  "Neural Network" = list(
    method = "nnet", 
    tuneGrid = expand.grid(
      size = c(3, 5, 7),
      decay = c(0.01, 0.1)
    )
  )
)

# Train and evaluate models
results <- lapply(names(models), function(model_name) {
  cat("Training", model_name, "...\n")
  result <- train_and_evaluate(models[[model_name]]$method, 
                               X_train_val, y_train_val, 
                               X_test, y_test, 
                               models[[model_name]]$tuneGrid)
  cat("Finished training", model_name, "\n")
  result
})
names(results) <- names(models)

# Create metrics dataframe
metrics_df <- do.call(rbind, lapply(names(results), function(model_name) {
  train <- results[[model_name]]$train$metrics
  test <- results[[model_name]]$test$metrics
  data.frame(Model = model_name, 
             Dataset = rep(c("Train", "Test"), each = 5),
             Metric = c("Accuracy", "Precision", "Recall", "F1", "AUC"),
             Value = c(train, test),
             row.names = NULL)
}))

# Format metrics dataframe
metrics_df <- metrics_df %>%
  mutate(Value = round(Value, 3),
         Model = factor(Model, levels = unique(Model)),
         Dataset = factor(Dataset, levels = c("Train", "Test")),
         Metric = factor(Metric, levels = c("Accuracy", "Precision", "Recall", "F1", "AUC"))) %>%
  pivot_wider(names_from = c(Dataset, Metric), values_from = Value)

# Display results
print(metrics_df)

# Create ensemble
create_ensemble <- function(results, X_test, y_test) {
  probs_list <- lapply(results, function(r) r$test$probabilities)
  aucs <- sapply(probs_list, function(p) auc(roc(y_test, p)))
  weights <- aucs / sum(aucs)
  ensemble_probs <- Reduce("+", mapply("*", probs_list, weights, SIMPLIFY = FALSE))
  ensemble_preds <- factor(ifelse(ensemble_probs > 0.5, "Pass", "Fail"), levels = c("Fail", "Pass"))
  ensemble_metrics <- calculate_metrics(ensemble_preds, y_test, ensemble_probs)
  list(
    probabilities = ensemble_probs,
    predictions = ensemble_preds,
    metrics = ensemble_metrics,
    weights = weights
  )
}

ensemble_results <- create_ensemble(results, X_test, y_test)

# Add ensemble results to metrics_df
ensemble_row <- tibble(
  Model = "Ensemble",
  Train_Accuracy = NA_real_,
  Train_Precision = NA_real_,
  Train_Recall = NA_real_,
  Train_F1 = NA_real_,
  Train_AUC = NA_real_,
  Test_Accuracy = ensemble_results$metrics["Accuracy"],
  Test_Precision = ensemble_results$metrics["Precision"],
  Test_Recall = ensemble_results$metrics["Recall"],
  Test_F1 = ensemble_results$metrics["F1"],
  Test_AUC = ensemble_results$metrics["AUC"]
)
metrics_df <- bind_rows(metrics_df, ensemble_row)

# Print updated metrics_df
print(metrics_df)


########################################
############# Plotting section #############
########################################
library(cowplot)
library(grid)
library(gridExtra)


# Function to create a single ROC plot
create_roc_plot <- function(actual, predicted_list, title, show_legend = FALSE, show_y_label = TRUE) {
  roc_list <- lapply(names(predicted_list), function(name) {
    roc_obj <- roc(actual, predicted_list[[name]])
    data.frame(
      specificity = 1 - roc_obj$specificities,
      sensitivity = roc_obj$sensitivities,
      model = name
    )
  })
  
  roc_data <- do.call(rbind, roc_list)
  
  ggplot(roc_data, aes(x = specificity, y = sensitivity, color = model)) +
    geom_line(size = 1) +
    geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "gray50") +
    labs(title = title, x = "1 - Specificity", y = if(show_y_label) "Sensitivity" else "") +
    theme_minimal() +
    theme(
      legend.position = if(show_legend) "bottom" else "none",
      legend.title = element_blank(),
      plot.title = element_text(hjust = 0.5, face = "bold"),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, size = 1),
      axis.title = element_text(face = "bold"),  # This line makes x and y labels bold
      axis.title.y = element_text(angle = 90)
    ) +
    coord_equal() +
    scale_color_brewer(palette = "Set1")
}

# Extract train probabilities
train_probs <- lapply(results, function(r) r$train$probabilities)
# Extract test probabilities
test_probs <- lapply(results, function(r) r$test$probabilities)


# Create individual plots
train_plot <- create_roc_plot(y_train_val, train_probs, "Train ROC Curves", show_y_label = TRUE)
test_plot <- create_roc_plot(y_test, test_probs, "Test ROC Curves", show_y_label = FALSE)

# Create a plot for legend
legend_plot <- create_roc_plot(y_test, test_probs, "", show_legend = TRUE) +
  theme(legend.position = "bottom")

# Extract legend
legend <- ggplotGrob(legend_plot)$grobs[[which(sapply(ggplotGrob(legend_plot)$grobs, function(x) x$name) == "guide-box")]]

# Combine plots with shared legend
combined_plot <- arrangeGrob(
  arrangeGrob(train_plot, test_plot, ncol = 2),
  legend,
  nrow = 2,
  heights = c(10, 1)
)

# Add title to the combined plot
final_plot <- arrangeGrob(
  combined_plot,
  top = textGrob("ROC Curves for Different Models Across Train and Test Sets",
                 gp = gpar(fontface = "bold", fontsize = 14))
)

grid.newpage()
grid.draw(final_plot)

# Save the plot
ggsave("thesis_plots_robust/roc_curves_linear_models_7.pdf", plot = final_plot, width = 12, height = 7)

######################################
# feature imp



# Variable mapping function (without Trajectory/Mean Household suffixes)
map_variable_names <- function(variable) {
  mapping <- c(
    "SDQ_total_difficulties_quartiles" = "Child Behavioral Issues Quartile",
    "family_social_class" = "Family Social Class",
    "mother_education" = "Mother's Education Level",
    "edu_quartiles" = "Educational Activity Quartile",
    "income_quintile" = "Income Quintile",
    "household_size" = "Household Size",
    "breastfeeding_status" = "Breastfeeding Status",
    "stress_quartiles" = "Parental Stress Quartile",
    "positive_conflict_quartiles" = "Parent-Child Closeness Quartile",
    "creative_quartiles" = "Creative Activities Quartile",
    "parenting_consistency_quartiles" = "Consistent Parenting-Style Quartile",
    "smoking_in_household" = "Pre-natal Smoking Household",
    "alcohol_frequency" = "Alcohol Frequency",
    "parenting_hostility_quartiles" = "Hostile Parenting-Style Quartile",
    "birth_weight_quartile" = "Birth Weight Quartile",
    "school_size_Small" = "Small School Size",
    "unadapt_quartiles" = "Unadaptable Infant Quartile",
    "dull_quartiles" = "Dull Infant Quartile",
    "unpredict_quartiles" = "Unpredictable Infant Quartile",
    "fussy_quartiles" = "Fussy Infant Quartile",
    "heavy_drinking" = "Pre-natal Heavy Drinking",
    "PT_meeting_attendance" = "Parent-Teacher Meeting Attendance",
    "school_size_Large" = "Large School",
    "ever_smoked" = "Mother Smoking Status",
    "school_DEIS_status_DEIS" = "Disadvantage School"
  )
  
  for (key in names(mapping)) {
    if (grepl(key, variable)) {
      return(mapping[key])
    }
  }
  return(variable)
}

# Function to categorize variables
categorize_variable <- function(variable) {
  if (grepl("_slope", variable)) {
    return("Time-Varying (Slope)")
  } else if (grepl("_intercept", variable)) {
    return("Time-Varying (Intercept)")
  } else {
    return("Fixed Factors")
  }
}

# Modified plot function
plot_var_importance <- function(importance_df, title, percentage = TRUE) {
  importance_df <- importance_df %>%
    mutate(
      mapped_variable = sapply(variable, map_variable_names),
      category = sapply(variable, categorize_variable)
    )
  
  if (percentage) {
    importance_df$importance <- importance_df$importance / sum(importance_df$importance) * 100
    y_label <- "Importance (%)"
  } else {
    y_label <- "Importance"
  }
  
  ggplot(importance_df, aes(x = reorder(mapped_variable, importance), y = importance, fill = category)) +
    geom_bar(stat = "identity") +
    scale_fill_manual(values = c("Time-Varying (Slope)" = "blue", "Time-Varying (Intercept)" = "red", "Fixed Factors" = "gray")) +
    coord_flip() +
    labs(title = paste(title),
         x = "Variable", y = y_label,
         fill = "Variable Type") +
    theme_minimal() +
    theme(
      axis.text.y = element_text(size = 8),
      plot.title = element_text(hjust = 0.5, face = "bold"),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, size = 0.5),
      legend.position = "bottom",
      axis.title = element_text(face = "bold"),  # This line makes x and y labels bold
      legend.title = element_text(face = "bold")  # This line makes the legend title bold
    )
}

# XGBoost Variable Importance Plot
if ("XGBoost" %in% names(results)) {
  xgb_importance <- xgb.importance(model = results[["XGBoost"]]$model$finalModel)
  xgb_importance_df <- data.frame(
    variable = xgb_importance$Feature,
    importance = xgb_importance$Gain
  )
  xgb_plot <- plot_var_importance(xgb_importance_df, "XGBoost Variable Importance", percentage = TRUE)
  print(xgb_plot)
  
  # Save the plot
  ggsave("thesis_plots_robust/xgboost_variable_importance_8.pdf", plot = xgb_plot, width = 12, height = 10)
}



##############################################################
# Confusion Matrices
create_cm_df <- function(actual, predicted, model_name) {
  cm <- confusionMatrix(predicted, actual)
  cm_d <- as.data.frame(cm$table)
  cm_d$Prediction <- factor(cm_d$Prediction, levels = rev(levels(cm_d$Prediction)))
  cm_d$Model <- model_name
  return(cm_d)
}

all_cm_df <- do.call(rbind, lapply(names(results), function(model_name) {
  create_cm_df(y_test, results[[model_name]]$test$predictions, model_name)
}))

confusion_mat <- ggplot(all_cm_df, aes(x = Reference, y = Prediction, fill = Freq)) +
  geom_tile() +
  geom_text(aes(label = Freq), color = "white", size = 3) +
  scale_fill_gradient(low = "lightblue", high = "darkblue") +
  facet_wrap(~ Model, ncol = 2) +
  labs(title = "Confusion Matrices Comparison", 
       x = "Actual", y = "Predicted") +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 45, hjust = 1),
        strip.background = element_rect(fill = "lightgray"),
        strip.text = element_text(face = "bold"),
        axis.title = element_text(face = "bold"))  # This line makes x and y labels bold

plot(confusion_mat)


# Save the plot
ggsave("thesis_plots_robust/confusion_mat_9.pdf", plot = confusion_mat, width = 12, height = 10)



###############################################################
library(RColorBrewer)


# Prepare the data
plot_data <- metrics_df %>%
  pivot_longer(cols = -Model, 
               names_to = c("Set", "Metric"),
               names_pattern = "(.+)_(.+)",
               values_to = "Value") %>%
  mutate(Set = factor(Set, levels = c("Train", "Test")),
         Metric = factor(Metric, levels = c("Accuracy", "Precision", "Recall", "F1", "AUC")))

# Create the plot
professional_plot <- ggplot(plot_data, aes(x = Model, y = Value, fill = Set)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  facet_wrap(~ Metric, scales = "free_y", nrow = 1) +
  scale_fill_brewer(palette = "Paired") +
  labs(title = "Model Performance Comparison",
       subtitle = "Train vs Test Set",
       y = "Metric Value",
       x = "Model") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 8),
    axis.title = element_text(face = "bold"),
    legend.position = "bottom",
    legend.title = element_blank(),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    plot.subtitle = element_text(hjust = 0.5, size = 14),
    strip.text = element_text(size = 12, face = "bold"),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey", fill = NA, size = 0.5),
    panel.spacing = unit(1, "lines")
  ) +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.2)) +
  coord_cartesian(clip = "off")

# Print the plot
print(professional_plot)

# Save the plot
ggsave("thesis_plots_robust/model_performance_comparison_10.pdf", plot = professional_plot, width = 15, height = 6, dpi = 300)

###############################################################









#########################################################################################
##################Interactions - working with LINEAR data tracjectories######################
#########################################################################################
str(linear_data)

# Select top 10 features from XGBoost importance
top_features <- c(
  "SDQ_total_difficulties_quartiles_linear_slope",
  "family_social_class_intercept",
  "edu_quartiles_linear_slope",
  "mother_education_intercept",
  "income_quintile_intercept",
  "income_quintile_linear_slope",
  "SDQ_total_difficulties_quartiles_intercept",
  "stress_quartiles_linear_slope",
  "edu_quartiles_intercept",
  "positive_conflict_quartiles_linear_slope",
  "creative_quartiles_linear_slope",
  "creative_quartiles_intercept",
  "stress_quartiles_intercept",
  "breastfeeding_status"
)
# Create all possible 2-way interactions
interactions <- combn(top_features, 2, FUN = function(x) paste(x, collapse = ":"), simplify = FALSE)
# Create the formula
formula <- as.formula(paste("pass_fail ~", 
                            paste(c(top_features, unlist(interactions)), collapse = " + ")))

# Print the formula to check
print(formula)
# Create model matrix
X <- model.matrix(formula, data = linear_data)[,-1]  # Remove intercept
y <- as.numeric(linear_data$pass_fail == "Pass")
# Fit LASSO model
set.seed(123)  # for reproducibility
cv_fit <- cv.glmnet(X, y, family = "binomial", alpha = 1)
# Get the best lambda
best_lambda <- cv_fit$lambda.min
# Fit final model with best lambda
final_model <- glmnet(X, y, family = "binomial", alpha = 1, lambda = best_lambda)
# Get non-zero coefficients
coef_matrix <- coef(final_model)
non_zero_coefs <- coef_matrix[which(coef_matrix != 0),]
# Print non-zero coefficients
non_zero_coefs

################################################################################

# Significant interactions
column_names1 <- list(
  "SDQ_total_difficulties_quartiles_linear_slope",
  "family_social_class_intercept",
  "edu_quartiles_linear_slope",
  "mother_education_intercept",
  "income_quintile_intercept",
  "income_quintile_linear_slope",
  "SDQ_total_difficulties_quartiles_intercept",
  "stress_quartiles_linear_slope",
  "positive_conflict_quartiles_linear_slope",
  "breastfeeding_status",
  "SDQ_total_difficulties_quartiles_linear_slope:edu_quartiles_linear_slope",
  "SDQ_total_difficulties_quartiles_linear_slope:income_quintile_intercept",
  "SDQ_total_difficulties_quartiles_linear_slope:edu_quartiles_intercept",
  "SDQ_total_difficulties_quartiles_linear_slope:stress_quartiles_intercept",
  "family_social_class_intercept:edu_quartiles_intercept",
  "family_social_class_intercept:creative_quartiles_linear_slope",
  "family_social_class_intercept:breastfeeding_status",
  "edu_quartiles_linear_slope:mother_education_intercept",
  "edu_quartiles_linear_slope:income_quintile_intercept",
  "edu_quartiles_linear_slope:stress_quartiles_linear_slope",
  "edu_quartiles_linear_slope:positive_conflict_quartiles_linear_slope",
  "edu_quartiles_linear_slope:creative_quartiles_intercept",
  "edu_quartiles_linear_slope:breastfeeding_status",
  "mother_education_intercept:stress_quartiles_linear_slope",
  "mother_education_intercept:creative_quartiles_linear_slope",
  "income_quintile_intercept:stress_quartiles_linear_slope",
  "income_quintile_intercept:edu_quartiles_intercept",
  "income_quintile_intercept:creative_quartiles_intercept",
  "income_quintile_intercept:breastfeeding_status",
  "income_quintile_linear_slope:SDQ_total_difficulties_quartiles_intercept",
  "income_quintile_linear_slope:stress_quartiles_linear_slope",
  "income_quintile_linear_slope:positive_conflict_quartiles_linear_slope",
  "income_quintile_linear_slope:creative_quartiles_linear_slope",
  "SDQ_total_difficulties_quartiles_intercept:edu_quartiles_intercept",
  "SDQ_total_difficulties_quartiles_intercept:positive_conflict_quartiles_linear_slope",
  "SDQ_total_difficulties_quartiles_intercept:creative_quartiles_linear_slope",
  "stress_quartiles_linear_slope:edu_quartiles_intercept",
  "stress_quartiles_linear_slope:creative_quartiles_linear_slope",
  "stress_quartiles_linear_slope:stress_quartiles_intercept",
  "edu_quartiles_intercept:positive_conflict_quartiles_linear_slope",
  "edu_quartiles_intercept:creative_quartiles_intercept",
  "positive_conflict_quartiles_linear_slope:creative_quartiles_linear_slope",
  "positive_conflict_quartiles_linear_slope:stress_quartiles_intercept",
  "creative_quartiles_linear_slope:breastfeeding_status"
)

# New list with the additional column names
column_names2 <- list(
  "pregnancy_awareness",
  "birth_weight_quartile",
  "breastfeeding_status",
  "ever_smoked",
  "smoking_in_household",
  "alcohol_frequency",
  "heavy_drinking",
  "grandparent_contact",
  "fussy_quartiles",
  "unadapt_quartiles",
  "dull_quartiles",
  "unpredict_quartiles",
  "PT_meeting_attendance",
  "household_size_intercept",
  "income_quintile_intercept",
  "SDQ_total_difficulties_quartiles_intercept",
  "stress_quartiles_intercept",
  "creative_quartiles_intercept",
  "parenting_hostility_quartiles_intercept",
  "parenting_consistency_quartiles_intercept",
  "positive_conflict_quartiles_intercept",
  "edu_quartiles_intercept",
  "family_social_class_intercept",
  "mother_education_intercept",
  "household_size_linear_slope",
  "income_quintile_linear_slope",
  "SDQ_total_difficulties_quartiles_linear_slope",
  "stress_quartiles_linear_slope",
  "creative_quartiles_linear_slope",
  "parenting_hostility_quartiles_linear_slope",
  "parenting_consistency_quartiles_linear_slope",
  "positive_conflict_quartiles_linear_slope",
  "edu_quartiles_linear_slope",
  "family_social_class_linear_slope",
  "mother_education_linear_slope",
  "school_DEIS_status_DEIS",
  "school_DEIS_status_Unknown",
  "school_size_Large",
  "school_size_Small"
)
column_names <- c(column_names1, column_names2)
# First, let's create the formula for our logistic regression
formula_terms <- paste(unlist(column_names), collapse = " + ")
formula <- as.formula(paste("pass_fail ~", formula_terms))
# Now, let's fit the logistic regression model
logistic_model <- glm(formula, data = linear_data, family = binomial())
# Summary of the model
summary(logistic_model)

##########################################################################################

#####VIF
calculate_vif <- function(model) {
  # Get model matrix
  X <- model.matrix(model)
  
  # Remove the intercept column if it exists
  if("(Intercept)" %in% colnames(X)) {
    X <- X[, -which(colnames(X) == "(Intercept)")]
  }
  
  # Calculate VIF for each variable
  vif_values <- numeric(ncol(X))
  names(vif_values) <- colnames(X)
  
  for (i in 1:ncol(X)) {
    # Create a data frame with only complete cases
    df <- na.omit(data.frame(y = X[,i], X[,-i]))
    
    # Check if there's enough variation in the dependent variable
    if (var(df$y) > 0) {
      form <- as.formula(paste("y ~", paste(names(df)[-1], collapse = "+")))
      fit <- try(lm(form, data = df), silent = TRUE)
      if (!inherits(fit, "try-error")) {
        r_squared <- summary(fit)$r.squared
        vif_values[i] <- 1 / (1 - r_squared)
      } else {
        vif_values[i] <- NA
      }
    } else {
      vif_values[i] <- NA
    }
  }
  
  return(vif_values)
}
# Now let's use this improved function
vif_results <- calculate_vif(logistic_model)
# Identify variables with high VIF (e.g., > 10), excluding NAs
high_vif <- vif_results[!is.na(vif_results) & vif_results > 10]
print(high_vif)


##########################################################################################

# List of variables with high VIF to remove
high_vif_vars <- c(
  "SDQ_total_difficulties_quartiles_intercept",
  "parenting_hostility_quartiles_intercept",
  "parenting_consistency_quartiles_intercept",
  "parenting_hostility_quartiles_linear_slope",
  "parenting_consistency_quartiles_linear_slope"
)

# Function to remove high VIF variables and their interactions
remove_high_vif_terms <- function(term) {
  for (var in high_vif_vars) {
    if (grepl(var, term)) {
      return(FALSE)
    }
  }
  return(TRUE)
}

# Filter out high VIF variables and their interactions
updated_column_names <- column_names[sapply(column_names, remove_high_vif_terms)]
# Create updated formula terms
updated_formula_terms <- paste(unlist(updated_column_names), collapse = " + ")
# Create updated formula
updated_formula <- as.formula(paste("pass_fail ~", updated_formula_terms))
# Fit updated logistic regression model
updated_logistic_model <- glm(updated_formula, data = model_data_binary, family = binomial())
# Summary of the updated model
summary_updated <- summary(updated_logistic_model)
print(summary_updated)
# Calculate VIF for the updated model
updated_vif <- calculate_vif(updated_logistic_model)
# Identify variables with high VIF in the updated model (e.g., > 5)
updated_high_vif <- updated_vif[updated_vif > 5]
print(updated_high_vif)


###############################################################################
# Create updated formula terms
updated_formula_terms <- paste(unlist(updated_column_names), collapse = " + ")
# Create updated formula
updated_formula <- as.formula(paste("pass_fail ~", updated_formula_terms))
###############################################################################




# Data preparation
set.seed(42)
y <- factor(linear_data$pass_fail, levels = c("Fail", "Pass"))
# Create train+validation and test sets
train_val_index <- createDataPartition(y, p = 0.8, list = FALSE)
train_val_data <- model_data_binary[train_val_index, ]
test_data <- model_data_binary[-train_val_index, ]

# Function to calculate evaluation metrics
calculate_metrics <- function(predictions, actual, probs) {
  cm <- confusionMatrix(predictions, actual)
  auc <- roc(actual, probs)$auc
  c(cm$overall["Accuracy"], cm$byClass[c("Precision", "Recall", "F1")], AUC = auc)
}

# Train and evaluate function
train_and_evaluate <- function(train_data, test_data, formula, method, tuneGrid) {
  set.seed(42)
  
  # Train the model
  model <- train(formula, 
                 data = train_data,
                 method = method,
                 trControl = trainControl(method = "cv", number = 5),
                 tuneGrid = tuneGrid)
  
  # Evaluate on training data
  train_pred <- predict(model, train_data)
  train_probs <- predict(model, train_data, type = "prob")$Pass
  train_metrics <- calculate_metrics(train_pred, train_data$pass_fail, train_probs)
  
  # Evaluate on test data
  test_pred <- predict(model, test_data)
  test_probs <- predict(model, test_data, type = "prob")$Pass
  test_metrics <- calculate_metrics(test_pred, test_data$pass_fail, test_probs)
  
  list(model = model, 
       train = list(metrics = train_metrics, predictions = train_pred, probabilities = train_probs),
       test = list(metrics = test_metrics, predictions = test_pred, probabilities = test_probs))
}

# Define new models with interactions
new_models <- list(
  "LR w/ Interactions" = list(
    method = "glmnet",
    tuneGrid = expand.grid(
      alpha = c(0, 0.5, 1),
      lambda = 10^seq(-2, 0, length = 3)
    )
  ),
  "XGBoost w/ Interactions" = list(
    method = "xgbTree", 
    tuneGrid = expand.grid(
      nrounds = c(50, 100),
      max_depth = c(3, 6),
      eta = c(0.1, 0.3),
      gamma = c(0, 0.1),
      colsample_bytree = c(0.8, 1),
      min_child_weight = c(1, 3),
      subsample = c(0.8, 1)
    )
  )
)

# Train and evaluate new models
new_results <- lapply(names(new_models), function(model_name) {
  cat("Training", model_name, "...\n")
  result <- train_and_evaluate(train_val_data, test_data, updated_formula,
                               new_models[[model_name]]$method, 
                               new_models[[model_name]]$tuneGrid)
  cat("Finished training", model_name, "\n")
  result
})
names(new_results) <- names(new_models)

# Create metrics dataframe for new models
new_metrics_df <- do.call(rbind, lapply(names(new_results), function(model_name) {
  train <- new_results[[model_name]]$train$metrics
  test <- new_results[[model_name]]$test$metrics
  data.frame(Model = model_name, 
             Dataset = rep(c("Train", "Test"), each = 5),
             Metric = c("Accuracy", "Precision", "Recall", "F1", "AUC"),
             Value = c(train, test),
             row.names = NULL)
}))

# Format new metrics dataframe
new_metrics_df <- new_metrics_df %>%
  mutate(Value = round(Value, 3),
         Model = factor(Model, levels = unique(Model)),
         Dataset = factor(Dataset, levels = c("Train", "Test")),
         Metric = factor(Metric, levels = c("Accuracy", "Precision", "Recall", "F1", "AUC"))) %>%
  pivot_wider(names_from = c(Dataset, Metric), values_from = Value)

# Combine existing metrics_df with new_metrics_df
metrics_df <- bind_rows(metrics_df, new_metrics_df)

# Display updated results
print(metrics_df)



##########################################################


# Extract feature importances from the XGBoost model
xgb_model <- new_results[["XGBoost w/ Interactions"]]$model$finalModel
importance_matrix <- xgb.importance(model = xgb_model)

# Create a dataframe for plotting
importance_df <- data.frame(
  feature = importance_matrix$Feature,
  importance = importance_matrix$Gain
)

# Updated variable mapping function
map_variable_names <- function(variable) {
  mapping <- c(
    "SDQ_total_difficulties_quartiles" = "Child Behavioral Issues Quartile",
    "family_social_class" = "Family Social Class",
    "mother_education" = "Mother's Education Level",
    "edu_quartiles" = "Educational Activity Quartile",
    "income_quintile" = "Income Quintile",
    "household_size" = "Household Size",
    "breastfeeding_status" = "Breastfeeding Status",
    "stress_quartiles" = "Parental Stress Quartile",
    "positive_conflict_quartiles" = "Parent-Child Closeness Quartile",
    "creative_quartiles" = "Creative Activities Quartile"
  )
  
  terms <- strsplit(variable, ":")[[1]]
  mapped_terms <- sapply(terms, function(term) {
    base_term <- term
    for (key in names(mapping)) {
      if (grepl(key, term)) {
        base_term <- mapping[key]
        break
      }
    }
    if (grepl("_slope", term)) {
      return(paste(base_term, "(Slope)"))
    } else if (grepl("_intercept", term)) {
      return(paste(base_term, "(Intercept)"))
    } else {
      return(base_term)
    }
  })
  
  paste(mapped_terms, collapse = " × ")
}

# Updated function to categorize variables
categorize_variable <- function(variable) {
  terms <- strsplit(variable, ":")[[1]]
  categories <- sapply(terms, function(term) {
    if (grepl("_slope", term)) {
      return("Slope")
    } else if (grepl("_intercept", term)) {
      return("Intercept")
    } else {
      return("Time-Invariant")
    }
  })
  
  unique_categories <- unique(categories)
  if (length(unique_categories) == 1) {
    return(unique_categories)
  } else {
    return(paste(sort(unique_categories), collapse = " × "))
  }
}

# Apply mapping and categorization
importance_df <- importance_df %>%
  mutate(
    mapped_feature = sapply(feature, map_variable_names),
    category = sapply(feature, categorize_variable),
    importance = importance / sum(importance) * 100
  )

# Sort the dataframe by importance
importance_df <- importance_df[order(importance_df$importance, decreasing = TRUE), ]

# Select top 20 features
importance_df <- head(importance_df, 20)

# Create grouped dataframe
importance_df_grouped <- importance_df %>%
  mutate(is_interaction = ifelse(grepl("×", mapped_feature), "Interaction", "Single Variable"))

# Define an expanded color palette for the left plot
left_palette <- c(
  "Slope" = "#4E79A7",
  "Intercept" = "#F28E2B",
  "Time-Invariant" = "#E15759",
  "Slope × Intercept" = "#76B7B2",
  "Slope × Time-Invariant" = "#59A14F",
  "Intercept × Time-Invariant" = "#EDC948",
  "Slope × Slope" = "#B07AA1",
  "Intercept × Intercept" = "#FF9DA7",
  "Time-Invariant × Time-Invariant" = "#9C755F"
)

# Check for any uncategorized variables
uncategorized <- importance_df$category[!importance_df$category %in% names(left_palette)]
if (length(uncategorized) > 0) {
  print("Uncategorized variables:")
  print(unique(uncategorized))
}

# Ensure all categories have a color
for (category in unique(importance_df$category)) {
  if (!category %in% names(left_palette)) {
    left_palette[category] <- "#CCCCCC"  # Assign a default color if missing
  }
}

library(ggplot2)
library(gridExtra)

# Modify the left plot (p1)
p1 <- ggplot(importance_df, aes(x = reorder(mapped_feature, importance), y = importance, fill = category)) +
  geom_bar(stat = "identity", color = "black", size = 0.2) +
  scale_fill_manual(values = left_palette, name = "Variable Type") +
  coord_flip() +
  labs(title = "XGBoost Feature Importance W/ Interactions",
       x = NULL,
       y = "Importance (%)") +
  theme_minimal() +
  theme(
    axis.text.y = element_text(size = 8),
    axis.text.x = element_text(size = 8),
    plot.title = element_text(hjust = 0.5, face = "bold"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, size = 0.5),
    legend.position = "bottom",
    axis.title = element_text(face = "bold"),
    legend.title = element_text(face = "bold"),
    plot.margin = unit(c(5.5, 10, 5.5, 5.5), "points")  # Adjust right margin
  )

# Modify the right plot (p2)
p2 <- ggplot(importance_df_grouped, aes(x = reorder(mapped_feature, importance), y = importance, fill = is_interaction)) +
  geom_bar(stat = "identity", color = "black", size = 0.2) +
  scale_fill_manual(values = c("Interaction" = "#1f77b4", "Single Variable" = "#ff7f0e"), 
                    name = "Variable Type") +
  coord_flip() +
  labs(title = "Feature Importance: Interactions vs Single Variables",
       x = NULL,
       y = "Importance (%)") +
  theme_minimal() +
  theme(
    axis.text.y = element_blank(),  # Remove y-axis text
    axis.text.x = element_text(size = 8),
    plot.title = element_text(hjust = 0.5, face = "bold"),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, size = 0.5),
    legend.position = "bottom",
    axis.title = element_text(face = "bold"),
    legend.title = element_text(face = "bold"),
    plot.margin = unit(c(5.5, 5.5, 5.5, 0), "points")  # Adjust left margin
  )

# Arrange plots side by side with equal widths
combined_plot <- grid.arrange(p1, p2, ncol = 2, widths = c(1, 1))

# Print the combined plot
print(combined_plot)
# save
ggsave("thesis_plots_robust/xgboost_interactions_11.pdf", combined_plot, width = 20, height = 10, units = "in")













###################################################################################
###################################################################################
###################################################################################
###################################################################################
###################################################################################
###################################################################################
###################################################################################
###################################################################################
###################################################################################
###################################################################################

################################################################################
################################################################################
################################################################################
################################################################################
################################################################################
################################################################################
################################################################################
################################################################################

#drop out
# Step 1: Identify households present in all waves (already done)
# consistent_households is already defined
#consistent_households

# Step 1: Identify households present only in wave 1 and no more further involvement
dropout_households <- w1_sub %>%
  anti_join(w2_sub, by = "household_id") %>%
  anti_join(w3_sub, by = "household_id") %>%
  anti_join(w4_sub, by = "household_id") %>%
  anti_join(w5_sub, by = "household_id") %>%
  pull(household_id)

#dropout_households


# Step 1: Prepare each wave's data without filtering for consistent households
prepare_wave <- function(data, wave_num) {
  data %>%
    rename_with(~paste0("w", wave_num, "_", .), -household_id)
}

w1_prepared <- prepare_wave(w1_sub, 1)
w2_prepared <- prepare_wave(w2_sub, 2)
w3_prepared <- prepare_wave(w3_sub, 3)
w4_prepared <- prepare_wave(w4_sub, 4)
w5_prepared <- prepare_wave(w5_sub, 5)

# Step 2: Combine all waves
long_data_all <- w1_prepared %>%
  full_join(w2_prepared, by = "household_id") %>%
  full_join(w3_prepared, by = "household_id") %>%
  full_join(w4_prepared, by = "household_id") %>%
  full_join(w5_prepared, by = "household_id")

# Step 3: Select the columns we need
long_data_selected_all <- long_data_all %>%
  select(all_of(c("household_id", columns_to_keep)))

# Step 4: Create datasets for analysis
# Dataset for households present in all waves
long_data_selected_consistent <- long_data_selected_all %>%
  filter(household_id %in% consistent_households) %>%
  mutate(group = "Consistent")
# Dataset for dropout households
long_data_selected_dropout <- long_data_selected_all %>%
  filter(household_id %in% dropout_households) %>%
  mutate(group = "Dropout")


# Combine consistent and dropout datasets
long_data_combined <- bind_rows(
  long_data_selected_consistent,
  long_data_selected_dropout
)
# Convert to tibble and rearrange columns
long_data_combined <- long_data_combined %>%
  as_tibble() %>%  # Convert to tibble
  relocate(group, .before = 1)  # Move "group" column to the first position
# Convert group to factor
long_data_combined$group <- as.factor(long_data_combined$group)
# View the result
long_data_combined


#################################################################################
# 1. Prepare Wave 1 data
library(effsize)
wave1_data <- long_data_combined %>%
  select(group, starts_with("w1_"))

improved_perform_test <- function(data, var) {
  if (is.numeric(data[[var]])) {
    # For numeric variables, perform t-test
    t_test <- t.test(data[[var]] ~ data$group)
    cohens_d <- effsize::cohen.d(data[[var]] ~ data$group)$estimate
    result <- tidy(t_test) %>% 
      mutate(test_type = "t-test",
             effect_size = cohens_d,
             effect_size_type = "Cohen's d")
  } else if (is.factor(data[[var]]) && !is.ordered(data[[var]])) {
    # For non-ordinal categorical variables, perform Fisher's exact test
    fisher_test <- fisher.test(table(data$group, data[[var]]), simulate.p.value = TRUE)
    cramers_v <- sqrt(chisq.test(table(data$group, data[[var]]))$statistic / 
                        (nrow(data) * (min(nlevels(data$group), nlevels(data[[var]])) - 1)))
    result <- tidy(fisher_test) %>% 
      mutate(test_type = "Fisher's exact test",
             effect_size = cramers_v,
             effect_size_type = "Cramer's V")
  } else if (is.ordered(data[[var]])) {
    # For ordinal variables, perform Kruskal-Wallis test
    kruskal_test <- kruskal.test(data[[var]] ~ data$group)
    epsilon_squared <- kruskal_test$statistic / ((nrow(data)^2 - 1) / (nrow(data) + 1))
    result <- tidy(kruskal_test) %>% 
      mutate(test_type = "Kruskal-Wallis test",
             effect_size = epsilon_squared,
             effect_size_type = "Epsilon squared")
  } else {
    # For any other type, return NA
    result <- tibble(p.value = NA, test_type = "Unsupported variable type",
                     effect_size = NA, effect_size_type = NA)
  }
  
  result %>% 
    mutate(variable = var,
           significance = case_when(
             p.value < 0.001 ~ "***",
             p.value < 0.01 ~ "**",
             p.value < 0.05 ~ "*",
             p.value < 0.1 ~ ".",
             TRUE ~ ""
           ))
}
# Apply tests to all Wave 1 variables
test_results <- map_dfr(names(wave1_data)[-1], ~improved_perform_test(wave1_data, .x))
# Process results
test_results <- test_results %>% 
  mutate(variable_name = names(wave1_data)[-1]) %>%
  arrange(p.value) %>%
  select(variable_name, p.value, significance, test_type, effect_size, effect_size_type, everything())
# Identify significant variables
significant_vars <- test_results %>% 
  filter(p.value < 0.05) %>% 
  pull(variable_name)

print(test_results, n= 100) # wave 1

###############################################################################

#############################################################################
# Assuming wave1_data and significant_vars are already defined
# Filter for significant variables
significant_data <- wave1_data %>% select(group, all_of(significant_vars))

# Separate numeric and categorical variables
numeric_vars <- significant_data %>% select_if(is.numeric) %>% names()
categorical_vars <- significant_data %>% select_if(function(x) !is.numeric(x)) %>% names()
categorical_vars <- categorical_vars[categorical_vars != "group"]

#############################################################################
# Get the top 5 most significant variables
top_5_vars <- test_results %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 5) %>%
  pull(variable_name)
# Filter significant_data for these top 5 variables and 'group'
top_5_data <- significant_data %>%
  select(group, all_of(top_5_vars))
str(top_5_data)



# Function to recode binary variables, adding NA as a level
recode_binary <- function(x, yes_label = "Yes", no_label = "No") {
  fct_explicit_na(
    factor(x, levels = c("0", "1"), labels = c(no_label, yes_label)),
    na_level = "NA"
  )
}

# Recode variables
top_5_data_recoded <- top_5_data %>%
  mutate(
    # Recode binary variables
    w1_has_partner = recode_binary(w1_has_partner),
    w1_smoking_in_household = recode_binary(as.character(w1_smoking_in_household)),
    w1_pregnancy_awareness = recode_binary(w1_pregnancy_awareness),
    
    # Ensure w1_grandparent_contact includes NA
    w1_grandparent_contact = fct_explicit_na(factor(w1_grandparent_contact, levels = c("Yes", "No")), na_level = "NA"),
    
    # Corrected recoding for w1_income_quintile
    w1_income_quintile = fct_explicit_na(
      factor(w1_income_quintile, 
             levels = c("1", "2", "3", "4", "5"), 
             labels = c("Q1", "Q2", "Q3", "Q4", "Q5"), 
             ordered = TRUE),
      na_level = "NA"
    )
  )

# View the structure of the recoded dataset
str(top_5_data_recoded)

# Check levels of each variable
lapply(top_5_data_recoded, levels)
table(top_5_data_recoded$w1_income_quintile)

library(ggplot2)
library(dplyr)
library(scales)
library(patchwork)

# Assuming top_5_data_recoded is your dataset

# Function to create improved summary
create_improved_summary <- function(data, var) {
  data %>%
    group_by(group, !!sym(var)) %>%
    summarise(count = n(), .groups = 'drop') %>%
    group_by(group) %>%
    mutate(proportion = count / sum(count),
           percentage = ifelse(proportion >= 0.02, sprintf("%.1f%%", proportion * 100), ""))
}

# Improved color palette
improved_color_palette <- c(
  "Yes" = "#1f77b4", "No" = "#ff7f0e",
  "Q1" = "#1f77b4", "Q2" = "#ff7f0e", "Q3" = "#2ca02c", 
  "Q4" = "#d62728", "Q5" = "#9467bd", "NA" = "#8c564b"
)

# Function to create improved stacked bar plot
create_improved_stacked_plot <- function(summary_data, var) {
  var_name <- switch(var,
                     "w1_income_quintile" = "Income Quintile",
                     "w1_has_partner" = "Has Partner",
                     "w1_smoking_in_household" = "Smoking in Household",
                     "w1_pregnancy_awareness" = "Pregnancy Awareness"
  )
  
  ggplot(summary_data, aes(x = group, y = proportion, fill = !!sym(var))) +
    geom_bar(stat = "identity", position = "stack") +
    geom_text(aes(label = percentage), 
              position = position_stack(vjust = 0.5), 
              size = 3, color = "white") +
    scale_fill_manual(values = improved_color_palette, name = var_name) +
    labs(x = "Group", y = "Proportion", 
         title = paste("Distribution of", var_name, "by Group")) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0),
          plot.title = element_text(hjust = 0.5, face = "bold"),
          legend.position = "bottom",
          axis.title = element_text(face = "bold"),
          panel.border = element_rect(color = "black", fill = NA, size = 1))
}

# Create and display improved plots
variables_to_plot <- c("w1_income_quintile", "w1_has_partner", 
                       "w1_smoking_in_household", "w1_pregnancy_awareness")

improved_plots <- lapply(variables_to_plot, function(var) {
  summary_data <- create_improved_summary(top_5_data_recoded, var)
  create_improved_stacked_plot(summary_data, var)
})

# Combine plots using patchwork
w1_dropout <- (improved_plots[[1]] + improved_plots[[2]]) / 
  (improved_plots[[3]] + improved_plots[[4]]) +
  plot_annotation(
    title = "End of Wave 1 Dropout Analysis: Key Variable Distributions",
    theme = theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 16))
  )

# Display the combined plot
print(w1_dropout)

# save
ggsave("thesis_plots_robust/w1_dropout_12.pdf", w1_dropout, width = 20, height = 10, units = "in")






##############################################################################
#wave 1 + 2 but not further and difference from wave 1

# Step 1: Identify households present in waves 1 and 2 but not in further waves
consistent_households # already defined

# Step 2: Identify households present in waves 1 and 2 but not in further waves
dropout_wave2 <- w1_sub %>%
  inner_join(w2_sub, by = "household_id") %>%
  anti_join(w3_sub, by = "household_id") %>%
  anti_join(w4_sub, by = "household_id") %>%
  anti_join(w5_sub, by = "household_id") %>%
  pull(household_id)
# Step 2: Calculate the overlap between dropout_wave2 and dropout_households
overlap <- intersect(dropout_wave2, dropout_households)
# Step 3: Calculate percentages
percent_overlap <- length(overlap) / length(dropout_households) * 100
percent_of_wave2_dropouts <- length(overlap) / length(dropout_wave2) * 100
# Total households in wave 1
total_wave1 <- nrow(w1_sub)
# Percentages
percent_dropout_wave1 <- length(dropout_households) / total_wave1 * 100
percent_dropout_wave2 <- length(dropout_wave2) / total_wave1 * 100

# Print results
cat("Total households in wave 1:", total_wave1, "\n")
cat("Number of households only in wave 1:", length(dropout_households), "\n")
cat("Percentage dropped out after wave 1:", percent_dropout_wave1, "%\n")
cat("Number of households in waves 1 and 2 only:", length(dropout_wave2), "\n")
cat("Percentage dropped out after wave 2:", percent_dropout_wave2, "%\n")


# Step 1: Identify households present in waves 1 and 2 but not in further waves
consistent_households # already defined

# Step 2: Identify households present in waves 1 and 2 but not in further waves
dropout_wave2 <- w1_sub %>%
  inner_join(w2_sub, by = "household_id") %>%
  anti_join(w3_sub, by = "household_id") %>%
  anti_join(w4_sub, by = "household_id") %>%
  anti_join(w5_sub, by = "household_id") %>%
  pull(household_id)


#prepare data
prepare_wave <- function(data, wave_num) {
  data %>%
    rename_with(~paste0("w", wave_num, "_", .), -household_id)
}

w1_prepared <- prepare_wave(w1_sub, 1)
w2_prepared <- prepare_wave(w2_sub, 2)
w3_prepared <- prepare_wave(w3_sub, 3)
w4_prepared <- prepare_wave(w4_sub, 4)
w5_prepared <- prepare_wave(w5_sub, 5)

# Step 4: Combine all waves
long_data_all <- w1_prepared %>%
  full_join(w2_prepared, by = "household_id") %>%
  full_join(w3_prepared, by = "household_id") %>%
  full_join(w4_prepared, by = "household_id") %>%
  full_join(w5_prepared, by = "household_id")

# Step 5: Select the columns we need
long_data_selected_all <- long_data_all %>%
  select(all_of(c("household_id", columns_to_keep)))

# Step 6: Create datasets for analysis
# Dataset for households present in all waves
long_data_selected_consistent <- long_data_selected_all %>%
  filter(household_id %in% consistent_households) %>%
  mutate(group = "Consistent")

# Dataset for wave 2 dropout households
long_data_selected_dropout_wave2 <- long_data_selected_all %>%
  filter(household_id %in% dropout_wave2) %>%
  mutate(group = "Dropout Wave 2")

# Combine consistent and dropout datasets
long_data_combined_2 <- bind_rows(
  long_data_selected_consistent,
  long_data_selected_dropout_wave2
)

# Convert to tibble and rearrange columns
long_data_combined_2 <- long_data_combined_2 %>%
  as_tibble() %>%
  relocate(group, .before = 1)

# Convert group to factor
long_data_combined_2$group <- as.factor(long_data_combined_2$group)

# Create a dataset with only wave 2 variables
wave2_data <- long_data_combined_2 %>%
  select(group, household_id, starts_with("w2_"))

################################################################
# Apply tests to all Wave 2 variables
test_results_2 <- map_dfr(names(wave2_data)[-1], ~improved_perform_test(wave2_data, .x))
# Process results
test_results_2 <- test_results_2 %>% 
  mutate(variable_name = names(wave2_data)[-1]) %>%
  arrange(p.value) %>%
  select(variable_name, p.value, significance, test_type, effect_size, effect_size_type, everything())
# Identify significant variables
significant_vars_2 <- test_results_2 %>% 
  filter(p.value < 0.05) %>% 
  pull(variable_name)




# Get the top 5 most significant variables
top_5_vars_2 <- test_results_2 %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 5) %>%
  pull(variable_name)
# Filter significant_data for these top 5 variables and 'group'
top_5_data_2 <- wave2_data %>%
  select(group, all_of(top_5_vars_2))
str(top_5_data_2)



# Recode variables
top_5_data_recoded_2 <- top_5_data_2 %>%
  mutate(
    # Recode binary variable
    w2_has_partner = recode_binary(w2_has_partner),
    
    # Recode w2_income_quintile
    w2_income_quintile = fct_explicit_na(
      factor(w2_income_quintile, 
             levels = c("1", "2", "3", "4", "5"), 
             labels = c("Q1", "Q2", "Q3", "Q4", "Q5"), 
             ordered = TRUE),
      na_level = "NA"
    ),
    
    # Ensure w2_family_structure includes NA
    w2_family_structure = fct_explicit_na(w2_family_structure, na_level = "NA"),
    
    # Convert w2_positive_conflict_diff to factor (you may want to adjust this based on your needs)
    w2_positive_conflict_diff = cut(w2_positive_conflict_diff, 
                                    breaks = c(-Inf, 0, 10, 20, Inf), 
                                    labels = c("Negative", "Low", "Medium", "High"),
                                    include.lowest = TRUE)
  )

# View the structure of the recoded dataset
str(top_5_data_recoded_2)
# Check levels of each variable
lapply(top_5_data_recoded_2, levels)
# Check the distribution of each variable
lapply(top_5_data_recoded_2, table)




# Function to create an improved summary table for a given variable
create_improved_summary <- function(data, var) {
  data %>%
    group_by(group, !!sym(var)) %>%
    summarise(count = n(), .groups = 'drop') %>%
    group_by(group) %>%
    mutate(proportion = count / sum(count),
           percentage = ifelse(proportion >= 0.02, sprintf("%.1f%%", proportion * 100), ""))
}

# Define an improved color palette
improved_color_palette <- c(
  "Yes" = "#1f77b4", "No" = "#ff7f0e",
  "Q1" = "#1f77b4", "Q2" = "#ff7f0e", "Q3" = "#2ca02c", "Q4" = "#d62728", "Q5" = "#9467bd",
  "NA" = "#8c564b",
  "Negative" = "#d73027", "Low" = "#fee08b", "Medium" = "#d9ef8b", "High" = "#1a9850",
  "One parent, 1 child" = "#66c2a5", "One parent, 2+ children" = "#fc8d62",
  "Two parents, 1 child" = "#8da0cb", "Two parents, 2+ children" = "#e78ac3"
)

# Function to create an improved stacked bar plot for a given variable
create_improved_stacked_plot <- function(summary_data, var) {
  var_name <- switch(var,
                     "w2_income_quintile" = "Income Quintile",
                     "w2_has_partner" = "Has Partner",
                     "w2_positive_conflict_diff" = "Positive Conflict Difference",
                     "w2_family_structure" = "Family Structure"
  )
  
  all_levels <- levels(droplevels(summary_data[[var]]))
  var_colors <- improved_color_palette[all_levels]
  
  # Relabel the group factor
  summary_data$group <- factor(summary_data$group, 
                               levels = c("Consistent", "Dropout Wave 2"),
                               labels = c("Consistent", "Dropout"))
  
  p <- ggplot(summary_data, aes(x = group, y = proportion, fill = !!sym(var))) +
    geom_bar(stat = "identity", position = "stack") +
    geom_text(aes(label = percentage), 
              position = position_stack(vjust = 0.5), 
              size = 3, color = "white") +
    scale_fill_manual(values = var_colors, 
                      name = var_name,
                      breaks = all_levels,
                      labels = all_levels) +
    labs(x = "Group", y = "Proportion", 
         title = paste("Distribution of", var_name, "by Group")) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0),
          plot.title = element_text(hjust = 0.5, face = "bold"),
          legend.position = "bottom",
          axis.title = element_text(face = "bold"),
          panel.border = element_rect(color = "black", fill = NA, size = 1))
  
  # Adjust legend for family structure
  if (var == "w2_family_structure") {
    p <- p + guides(fill = guide_legend(nrow = 2))
  }
  
  return(p)
}

# Create plots for categorical variables
categorical_vars <- c("w2_income_quintile", "w2_has_partner", "w2_positive_conflict_diff", "w2_family_structure")
improved_plot_list <- map(categorical_vars, function(var) {
  summary_data <- create_improved_summary(top_5_data_recoded_2, var)
  create_improved_stacked_plot(summary_data, var)
})

# Arrange all plots in a grid with an overall title
combined_plot <- arrangeGrob(grobs = improved_plot_list, ncol = 2,
                             top = textGrob("End of Wave 2 Dropout Analysis: Key Variable Distributions",
                                            gp = gpar(fontface = "bold", fontsize = 16)))

# Display the combined plot
w2_dropout <- grid.arrange(combined_plot)

#save 
ggsave("thesis_plots_robust/w2_dropout_13.pdf", w2_dropout, width = 20, height = 10, units = "in")


####################################################################################




##############################################################################
# hh in all waves
consistent_households # already defined

# Step 2: Identify households present in waves 1, 2, and 3 but not in further waves
dropout_wave3 <- w1_sub %>%
  inner_join(w2_sub, by = "household_id") %>%
  inner_join(w3_sub, by = "household_id") %>%
  anti_join(w4_sub, by = "household_id") %>%
  anti_join(w5_sub, by = "household_id") %>%
  pull(household_id)


# Count the number of dropouts for each wave
n_dropout_wave2 <- length(dropout_wave2)
n_dropout_wave3 <- length(dropout_wave3)

# Print the results
cat("Number of households that dropped out after Wave 2:", n_dropout_wave2, "\n")
cat("Number of households that dropped out after Wave 3:", n_dropout_wave3, "\n")




#prepare data
prepare_wave <- function(data, wave_num) {
  data %>%
    rename_with(~paste0("w", wave_num, "_", .), -household_id)
}
w1_prepared <- prepare_wave(w1_sub, 1)
w2_prepared <- prepare_wave(w2_sub, 2)
w3_prepared <- prepare_wave(w3_sub, 3)
w4_prepared <- prepare_wave(w4_sub, 4)
w5_prepared <- prepare_wave(w5_sub, 5)
# Step 4: Combine all waves
long_data_all <- w1_prepared %>%
  full_join(w2_prepared, by = "household_id") %>%
  full_join(w3_prepared, by = "household_id") %>%
  full_join(w4_prepared, by = "household_id") %>%
  full_join(w5_prepared, by = "household_id")
# Step 5: Select the columns we need
long_data_selected_all <- long_data_all %>%
  select(all_of(c("household_id", columns_to_keep)))
# Step 6: Create datasets for analysis
# Dataset for households present in all waves
long_data_selected_consistent <- long_data_selected_all %>%
  filter(household_id %in% consistent_households) %>%
  mutate(group = "Consistent")
# Dataset for wave 2 dropout households
long_data_selected_dropout_wave3 <- long_data_selected_all %>%
  filter(household_id %in% dropout_wave3) %>%
  mutate(group = "Dropout Wave 3")
# Combine consistent and dropout datasets
long_data_combined_3 <- bind_rows(
  long_data_selected_consistent,
  long_data_selected_dropout_wave3
)
# Convert to tibble and rearrange columns
long_data_combined_3 <- long_data_combined_3 %>%
  as_tibble() %>%
  relocate(group, .before = 1)
# Convert group to factor
long_data_combined_3$group <- as.factor(long_data_combined_3$group)

######################################################################
# Create a dataset with only wave 2 variables
wave3_data <- long_data_combined_3 %>%
  select(group, household_id, starts_with("w3_"))
str(wave3_data )
######################################################################
# Apply tests to all Wave 3 variables
test_results_3 <- map_dfr(names(wave3_data)[-1], ~improved_perform_test(wave3_data, .x))
# Process results
test_results_3 <- test_results_3 %>% 
  mutate(variable_name = names(wave3_data)[-1]) %>%
  arrange(p.value) %>%
  select(variable_name, p.value, significance, test_type, effect_size, effect_size_type, everything())
# Identify significant variables
significant_vars_3 <- test_results_3 %>% 
  filter(p.value < 0.05) %>% 
  pull(variable_name)





# Get the top 5 most significant variables
top_5_vars_3 <- test_results_3 %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 6) %>%
  pull(variable_name)
# Filter significant_data for these top 5 variables and 'group'
top_5_data_3 <- wave3_data %>%
  select(group, all_of(top_5_vars_3))
str(top_5_data_3)




#####################################

# Function to recode binary variables, adding NA as a level
recode_binary <- function(x, yes_label = "Yes", no_label = "No") {
  fct_explicit_na(
    factor(x, levels = c("0", "1"), labels = c(no_label, yes_label)),
    na_level = "NA"
  )
}

# Recode variables
top_5_data_recoded_3 <- top_5_data_3 %>%
  select(-household_id) %>%  # Remove household_id
  mutate(
    # Recode binary variable
    w3_has_partner = recode_binary(w3_has_partner),
    
    # Recode w3_income_quintile
    w3_income_quintile = fct_explicit_na(
      factor(w3_income_quintile, 
             levels = c("1", "2", "3", "4", "5"), 
             labels = c("Q1", "Q2", "Q3", "Q4", "Q5"), 
             ordered = TRUE),
      na_level = "NA"
    ),
    
    # Ensure w3_PT_meeting_attendance includes NA
    w3_PT_meeting_attendance = fct_explicit_na(w3_PT_meeting_attendance, na_level = "NA"),
    
    # Convert w3_educational_composite to factor 
    w3_educational_composite = cut(w3_educational_composite, 
                                   breaks = c(-Inf, 1, 2, 3, Inf), 
                                   labels = c("Low", "Medium", "High", "Very High"),
                                   include.lowest = TRUE),
    
    # Convert w3_household_size to factor
    w3_household_size = cut(w3_household_size,
                            breaks = c(0, 2, 4, 6, Inf),
                            labels = c("1-2", "3-4", "5-6", "7+"),
                            include.lowest = TRUE)
  )

# View the structure of the recoded dataset
str(top_5_data_recoded_3)

# Check levels of each variable
lapply(top_5_data_recoded_3, levels)

# Check the distribution of each variable
lapply(top_5_data_recoded_3, table)



# Function to create an improved summary table for a given variable
create_improved_summary <- function(data, var) {
  data %>%
    group_by(group, !!sym(var)) %>%
    summarise(count = n(), .groups = 'drop') %>%
    group_by(group) %>%
    mutate(proportion = count / sum(count),
           percentage = ifelse(proportion >= 0.02, sprintf("%.1f%%", proportion * 100), ""))
}

# Define an improved color palette
improved_color_palette <- c(
  "Yes" = "#1f77b4", "No" = "#ff7f0e",
  "Q1" = "#1f77b4", "Q2" = "#ff7f0e", "Q3" = "#2ca02c", "Q4" = "#d62728", "Q5" = "#9467bd",
  "NA" = "#8c564b",
  "Low" = "#fee08b", "Medium" = "#d9ef8b", "High" = "#1a9850", "Very High" = "#006837",
  "1-2" = "#66c2a5", "3-4" = "#fc8d62", "5-6" = "#8da0cb", "7+" = "#e78ac3"
)

# Function to create an improved stacked bar plot for a given variable
create_improved_stacked_plot <- function(summary_data, var) {
  var_name <- switch(var,
                     "w3_income_quintile" = "Income Quintile",
                     "w3_has_partner" = "Has Partner",
                     "w3_PT_meeting_attendance" = "PT Meeting Attendance",
                     "w3_household_size" = "Household Size"
  )
  
  all_levels <- levels(droplevels(summary_data[[var]]))
  var_colors <- improved_color_palette[all_levels]
  
  # Relabel the group factor
  summary_data$group <- factor(summary_data$group, 
                               levels = c("Consistent", "Dropout Wave 3"),
                               labels = c("Consistent", "Dropout"))
  
  p <- ggplot(summary_data, aes(x = group, y = proportion, fill = !!sym(var))) +
    geom_bar(stat = "identity", position = "stack") +
    geom_text(aes(label = percentage), 
              position = position_stack(vjust = 0.5), 
              size = 3, color = "white") +
    scale_fill_manual(values = var_colors, 
                      name = var_name,
                      breaks = all_levels,
                      labels = all_levels) +
    labs(x = "Group", y = "Proportion", 
         title = paste("Distribution of", var_name, "by Group")) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0),
          plot.title = element_text(hjust = 0.5, face = "bold"),
          legend.position = "bottom",
          axis.title = element_text(face = "bold"),
          panel.border = element_rect(color = "black", fill = NA, size = 1))
  
  # Adjust legend for household size
  if (var == "w3_household_size") {
    p <- p + guides(fill = guide_legend(nrow = 2))
  }
  
  return(p)
}

# Create plots for categorical variables
categorical_vars <- c("w3_income_quintile", "w3_has_partner", "w3_PT_meeting_attendance", "w3_household_size")
improved_plot_list <- map(categorical_vars, function(var) {
  summary_data <- create_improved_summary(top_5_data_recoded_3, var)
  create_improved_stacked_plot(summary_data, var)
})

# Arrange all plots in a grid with an overall title
combined_plot <- arrangeGrob(grobs = improved_plot_list, ncol = 2,
                             top = textGrob("End of Wave 3 Dropout Analysis: Key Variable Distributions",
                                            gp = gpar(fontface = "bold", fontsize = 16)))

# Display the combined plot
w3_dropout <- grid.arrange(combined_plot)

# Save the plot
ggsave("thesis_plots_robust/w3_dropout_14.pdf", w3_dropout, width = 20, height = 10, units = "in")






##############################################################################
# hh in all waves
consistent_households # already defined

# Step 2: Identify households present in waves 1, 2, 3, and 4 but not in final wave
dropout_wave4 <- w1_sub %>%
  inner_join(w2_sub, by = "household_id") %>%
  inner_join(w3_sub, by = "household_id") %>%
  inner_join(w4_sub, by = "household_id") %>%
  anti_join(w5_sub, by = "household_id") %>%
  pull(household_id)


# Count the number of dropouts for each wave
n_dropout_wave1 <- length(dropout_households)
n_dropout_wave2 <- length(dropout_wave2)
n_dropout_wave3 <- length(dropout_wave3)
n_dropout_wave4 <- length(dropout_wave4)


print(test_results, n= 100) # wave 1
print(test_results_2, n= 100) # wave 2
print(test_results_3, n= 100) # wave 3
# Print the results
cat("Number of households that dropped out after Wave 1:", n_dropout_wave1, "\n")
cat("Number of households that dropped out after Wave 2:", n_dropout_wave2, "\n")
cat("Number of households that dropped out after Wave 3:", n_dropout_wave3, "\n")
cat("Number of households that dropped out after Wave 4:", n_dropout_wave4, "\n")




#prepare data
prepare_wave <- function(data, wave_num) {
  data %>%
    rename_with(~paste0("w", wave_num, "_", .), -household_id)
}
w1_prepared <- prepare_wave(w1_sub, 1)
w2_prepared <- prepare_wave(w2_sub, 2)
w3_prepared <- prepare_wave(w3_sub, 3)
w4_prepared <- prepare_wave(w4_sub, 4)
w5_prepared <- prepare_wave(w5_sub, 5)
# Step 4: Combine all waves
long_data_all <- w1_prepared %>%
  full_join(w2_prepared, by = "household_id") %>%
  full_join(w3_prepared, by = "household_id") %>%
  full_join(w4_prepared, by = "household_id") %>%
  full_join(w5_prepared, by = "household_id")
# Step 5: Select the columns we need
long_data_selected_all <- long_data_all %>%
  select(all_of(c("household_id", columns_to_keep)))
# Step 6: Create datasets for analysis
# Dataset for households present in all waves
long_data_selected_consistent <- long_data_selected_all %>%
  filter(household_id %in% consistent_households) %>%
  mutate(group = "Consistent")
# Dataset for wave 4 dropout households
long_data_selected_dropout_wave4 <- long_data_selected_all %>%
  filter(household_id %in% dropout_wave4) %>%
  mutate(group = "Dropout Wave 4")
# Combine consistent and dropout datasets
long_data_combined_4 <- bind_rows(
  long_data_selected_consistent,
  long_data_selected_dropout_wave4
)
# Convert to tibble and rearrange columns
long_data_combined_4 <- long_data_combined_4 %>%
  as_tibble() %>%
  relocate(group, .before = 1)
# Convert group to factor
long_data_combined_4$group <- as.factor(long_data_combined_4$group)

######################################################################
# Create a dataset with only wave 4 variables
wave4_data <- long_data_combined_4 %>%
  select(group, household_id, starts_with("w4_"))
str(wave4_data )
######################################################################
# Apply tests to all Wave 4 variables
test_results_4 <- map_dfr(names(wave4_data)[-1], ~improved_perform_test(wave4_data, .x))
# Process results
test_results_4 <- test_results_4 %>% 
  mutate(variable_name = names(wave4_data)[-1]) %>%
  arrange(p.value) %>%
  select(variable_name, p.value, significance, test_type, effect_size, effect_size_type, everything())
# Identify significant variables
significant_vars_4 <- test_results_4 %>% 
  filter(p.value < 0.05) %>% 
  pull(variable_name)


# Get the top 5 most significant variables
top_5_vars_4 <- test_results_4 %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 6) %>%
  pull(variable_name)
# Filter significant_data for these top 5 variables and 'group'
top_5_data_4 <- wave4_data %>%
  select(group, all_of(top_5_vars_4))
str(top_5_data_4)


















































##########################################################
#QUADRATIC
##########################################################
quadratic_data <- create_slope_dataset(model_data_binary, "quadratic")
str(quadratic_data)

# Data preparation
set.seed(42)
X <- quadratic_data %>% select(-pass_fail)
y <- factor(quadratic_data$pass_fail, levels = c("Fail", "Pass"))
# Create train+validation and test sets
train_val_index <- createDataPartition(y, p = 0.8, list = FALSE)
X_train_val <- X[train_val_index, ]
y_train_val <- y[train_val_index]
X_test <- X[-train_val_index, ]
y_test <- y[-train_val_index]

# Function to calculate evaluation metrics
calculate_metrics <- function(predictions, actual, probs) {
  cm <- confusionMatrix(predictions, actual)
  auc <- roc(actual, probs)$auc
  c(cm$overall["Accuracy"], cm$byClass[c("Precision", "Recall", "F1")], AUC = auc)
}

# Train and evaluate models
train_and_evaluate <- function(method, X_train, y_train, X_test, y_test, tuneGrid = NULL) {
  set.seed(42)
  
  model <- train(x = X_train, y = y_train, 
                 method = method,
                 trControl = trainControl(method = "cv", number = 5),
                 tuneGrid = tuneGrid)
  
  train_pred <- predict(model, X_train)
  train_probs <- predict(model, X_train, type = "prob")$Pass
  train_metrics <- calculate_metrics(train_pred, y_train, train_probs)
  
  test_pred <- predict(model, X_test)
  test_probs <- predict(model, X_test, type = "prob")$Pass
  test_metrics <- calculate_metrics(test_pred, y_test, test_probs)
  
  list(model = model, 
       train = list(metrics = train_metrics, predictions = train_pred, probabilities = train_probs),
       test = list(metrics = test_metrics, predictions = test_pred, probabilities = test_probs))
}

# Define models and their parameters
models <- list(
  "Logistic Regression" = list(
    method = "glmnet",
    tuneGrid = expand.grid(
      alpha = c(0, 0.5, 1),
      lambda = 10^seq(-2, 0, length = 3)
    )
  ),
  "Random Forest" = list(
    method = "rf",
    tuneGrid = expand.grid(
      mtry = c(5, 10, 15)
    )
  ),
  "XGBoost" = list(
    method = "xgbTree", 
    tuneGrid = expand.grid(
      nrounds = c(50, 100),
      max_depth = c(3, 6),
      eta = c(0.1, 0.3),
      gamma = c(0, 0.1),
      colsample_bytree = c(0.8, 1),
      min_child_weight = c(1, 3),
      subsample = c(0.8, 1)
    )
  ),
  "Neural Network" = list(
    method = "nnet", 
    tuneGrid = expand.grid(
      size = c(3, 5, 7),
      decay = c(0.01, 0.1)
    )
  )
)

# Train and evaluate models
results <- lapply(names(models), function(model_name) {
  cat("Training", model_name, "...\n")
  result <- train_and_evaluate(models[[model_name]]$method, 
                               X_train_val, y_train_val, 
                               X_test, y_test, 
                               models[[model_name]]$tuneGrid)
  cat("Finished training", model_name, "\n")
  result
})
names(results) <- names(models)

# Create metrics dataframe
metrics_df_quad <- do.call(rbind, lapply(names(results), function(model_name) {
  train <- results[[model_name]]$train$metrics
  test <- results[[model_name]]$test$metrics
  data.frame(Model = model_name, 
             Dataset = rep(c("Train", "Test"), each = 5),
             Metric = c("Accuracy", "Precision", "Recall", "F1", "AUC"),
             Value = c(train, test),
             row.names = NULL)
}))

# Format metrics dataframe
metrics_df_quad <- metrics_df_quad %>%
  mutate(Value = round(Value, 3),
         Model = factor(Model, levels = unique(Model)),
         Dataset = factor(Dataset, levels = c("Train", "Test")),
         Metric = factor(Metric, levels = c("Accuracy", "Precision", "Recall", "F1", "AUC"))) %>%
  pivot_wider(names_from = c(Dataset, Metric), values_from = Value)

# Display results
print(metrics_df_quad)








###############################################################
###############################################################
###############################################################
###############################################################
###############################################################
###############################################################
# Plotting section for Quadratic Data Analysis
# Set a global theme for all plots
theme_set(theme_minimal() + 
            theme(plot.title = element_text(face = "bold", hjust = 0.5),
                  plot.subtitle = element_text(hjust = 0.5)))

# Function to plot ROC curve with improved legend
plot_roc <- function(actual, predicted_list, main) {
  colors <- rainbow(length(predicted_list))
  plot(roc(actual, predicted_list[[1]]), 
       main = main, col = colors[1], lwd = 2,
       legacy.axes = TRUE)
  for (i in 2:length(predicted_list)) {
    lines(roc(actual, predicted_list[[i]]), col = colors[i], lwd = 2)
  }
  abline(a = 0, b = 1, lty = 2, col = "gray")
  legend("bottomright", 
         legend = names(predicted_list), 
         col = colors,
         lwd = 2,
         bty = "n",
         cex = 0.7)
}

# ROC Curves
par(mfrow = c(1, 2), mar = c(4, 4, 4, 1), oma = c(0, 0, 2, 0))

train_probs <- lapply(results, function(x) x$train$probabilities)
plot_roc(y_train_val, train_probs, main = "Train ROC Curves (Quadratic Data)")

test_probs <- lapply(results, function(x) x$test$probabilities)
plot_roc(y_test, test_probs, main = "Test ROC Curves (Quadratic Data)")

title("ROC Curves for Different Models Across Train and Test Sets (Quadratic Data)", outer = TRUE)

# Variable Importance Plots
plot_var_importance <- function(importance_df, title, percentage = FALSE) {
  if (percentage) {
    importance_df$importance <- importance_df$importance / sum(importance_df$importance) * 100
    y_label <- "Importance (%)"
  } else {
    y_label <- "Importance"
  }
  
  ggplot(importance_df, aes(x = reorder(variable, importance), y = importance)) +
    geom_bar(stat = "identity", fill = "steelblue") +
    coord_flip() +
    labs(title = paste(title, "(Quadratic Data)"),
         subtitle = "Based on quadratic relationship between features",
         x = "Variable", y = y_label) +
    theme(axis.text.y = element_text(size = 8))
}

if ("Random Forest" %in% names(results)) {
  rf_importance <- varImp(results[["Random Forest"]]$model)
  rf_importance_df <- data.frame(
    variable = rownames(rf_importance$importance),
    importance = rf_importance$importance$Overall
  )
  print(plot_var_importance(rf_importance_df, "Random Forest Variable Importance"))
  print(plot_var_importance(rf_importance_df, "Random Forest Variable Importance (%)", percentage = TRUE))
}

if ("XGBoost" %in% names(results)) {
  xgb_importance <- xgb.importance(model = results[["XGBoost"]]$model$finalModel)
  xgb_importance_df <- data.frame(
    variable = xgb_importance$Feature,
    importance = xgb_importance$Gain
  )
  print(plot_var_importance(xgb_importance_df, "XGBoost Variable Importance"))
  print(plot_var_importance(xgb_importance_df, "XGBoost Variable Importance (%)", percentage = TRUE))
}

# Confusion Matrices
create_cm_df <- function(actual, predicted, model_name) {
  cm <- confusionMatrix(predicted, actual)
  cm_d <- as.data.frame(cm$table)
  cm_d$Prediction <- factor(cm_d$Prediction, levels = rev(levels(cm_d$Prediction)))
  cm_d$Model <- model_name
  return(cm_d)
}

all_cm_df <- do.call(rbind, lapply(names(results), function(model_name) {
  create_cm_df(y_test, results[[model_name]]$test$predictions, model_name)
}))

ggplot(all_cm_df, aes(x = Reference, y = Prediction, fill = Freq)) +
  geom_tile() +
  geom_text(aes(label = Freq), color = "white", size = 3) +
  scale_fill_gradient(low = "lightblue", high = "darkblue") +
  facet_wrap(~ Model, ncol = 2) +
  labs(title = "Confusion Matrices Comparison (Quadratic Data)", 
       subtitle = "Based on quadratic relationship between features",
       x = "Actual", y = "Predicted") +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 45, hjust = 1),
        strip.background = element_rect(fill = "lightgray"),
        strip.text = element_text(face = "bold"))

# Model Performance Comparison
plot_data <- data.frame()
for (model_name in names(results)) {
  for (dataset in c("train", "test")) {
    metrics <- results[[model_name]][[dataset]]$metrics
    plot_data <- rbind(plot_data, data.frame(
      Model = model_name,
      Dataset = dataset,
      Accuracy = metrics["Accuracy"],
      Precision = metrics["Precision"],
      Recall = metrics["Recall"],
      F1_Score = metrics["F1"],
      AUC = metrics["AUC"]
    ))
  }
}

plot_data_melted <- melt(plot_data, id.vars = c("Model", "Dataset"))
plot_data_melted$Dataset <- factor(tools::toTitleCase(plot_data_melted$Dataset), levels = c("Train", "Test"))

ggplot(plot_data_melted, aes(x = Model, y = value, fill = Dataset)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  facet_wrap(~ variable, scales = "free_y", ncol = 2) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "bottom",
        legend.title = element_blank()) +
  labs(title = "Model Performance Comparison (Quadratic Data)",
       subtitle = "Based on quadratic relationship between features",
       y = "Metric Value",
       x = "Model") +
  scale_fill_manual(values = c("Train" = "#66B2FF", "Test" = "#FF9999"))

# Feature Importance Comparison
combined_importance <- data.frame()

if ("Random Forest" %in% names(results)) {
  rf_importance <- varImp(results[["Random Forest"]]$model)$importance
  rf_importance$Feature <- rownames(rf_importance)
  rf_importance$Model <- "Random Forest"
  rf_importance$Overall <- rf_importance$Overall / sum(rf_importance$Overall) * 100
  combined_importance <- rbind(combined_importance, rf_importance)
}

if ("XGBoost" %in% names(results)) {
  xgb_importance <- xgb.importance(feature_names = colnames(X_train_val), model = results[["XGBoost"]]$model$finalModel)
  xgb_importance$Feature <- xgb_importance$Feature
  xgb_importance$Overall <- xgb_importance$Gain / sum(xgb_importance$Gain) * 100
  xgb_importance$Model <- "XGBoost"
  combined_importance <- rbind(combined_importance, xgb_importance[, c("Feature", "Overall", "Model")])
}

if (nrow(combined_importance) > 0) {
  top_features <- combined_importance %>%
    group_by(Model) %>%
    top_n(10, Overall) %>%
    ungroup() %>%
    pull(Feature) %>%
    unique()
  
  filtered_importance <- combined_importance %>%
    filter(Feature %in% top_features)
  
  ggplot(filtered_importance, aes(x = reorder(Feature, Overall), y = Overall, fill = Model)) +
    geom_bar(stat = "identity", position = "dodge") +
    coord_flip() +
    facet_wrap(~ Model, scales = "free_y") +
    labs(title = "Top 10 Feature Importance Comparison (Quadratic Data)",
         subtitle = "Based on quadratic relationship between features",
         x = "Features",
         y = "Importance (%)") +
    scale_fill_manual(values = c("Random Forest" = "#FF9999", "XGBoost" = "#66B2FF")) +
    theme(legend.position = "bottom",
          axis.text.y = element_text(size = 8))
}
# Ensemble Performance Visualization
metrics_long <- metrics_df %>%
  select(Model, starts_with("Test_")) %>%
  pivot_longer(cols = starts_with("Test_"), 
               names_to = "Metric", 
               values_to = "Value",
               names_prefix = "Test_")
# Create and assign the plot to a variable
model_performance_plot <- ggplot(metrics_long, aes(x = Model, y = Value, fill = Metric)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(title = "Model Performance Comparison (Quadratic Data)",
       subtitle = "Test Set - Based on quadratic relationship between features",
       y = "Metric Value") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
plot(model_performance_plot)

# Save as PDF for better quality
ggsave("thesis_plots/model_performance_comparison.pdf", plot = model_performance_plot, width = 10, height = 8)



